package com.erke.erke_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
