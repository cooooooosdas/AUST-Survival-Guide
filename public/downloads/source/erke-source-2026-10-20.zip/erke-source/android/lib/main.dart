/// 二课提醒 · 移动版（Android / Flutter）
///
/// 结构：
///   core/  纯逻辑（接口、模型、打分、存储、通知、同步、后台任务）
///   ui/    页面（首页活动流 / 提醒 / 设置 / 向导 / 详情）
library;

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/background.dart';
import 'core/notifier.dart';
import 'core/state.dart';
import 'ui/home_page.dart';
import 'ui/onboarding_page.dart';
import 'ui/reco_page.dart';
import 'ui/settings_page.dart';
import 'ui/theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ErkeApp());
}

class ErkeApp extends StatefulWidget {
  const ErkeApp({super.key});

  @override
  State<ErkeApp> createState() => _ErkeAppState();
}

class _ErkeAppState extends State<ErkeApp> {
  final AppState state = AppState();

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    // 通知初始化失败（极少数机型渠道创建异常）不该拖垮整个启动
    try {
      await Notifier.init();
    } catch (_) {}
    try {
      await state.init();
    } catch (e) {
      state.failBoot('$e');
      return;
    }
    // 已登录才登记后台周期任务
    BackgroundSync.ensure();
  }

  @override
  void dispose() {
    state.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '二课提醒',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      locale: const Locale('zh', 'CN'),
      supportedLocales: const [Locale('zh', 'CN'), Locale('en', 'US')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: RootPage(state: state),
    );
  }
}

class RootPage extends StatefulWidget {
  const RootPage({super.key, required this.state});

  final AppState state;

  @override
  State<RootPage> createState() => _RootPageState();
}

class _RootPageState extends State<RootPage> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final s = widget.state;
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) {
        if (!s.initialized) return const _Splash();
        if (s.bootError.isNotEmpty) return _BootError(state: s);
        if (!s.settings.onboarded) return OnboardingPage(state: s);
        return Scaffold(
          body: IndexedStack(
            index: _tab,
            children: [
              HomePage(state: s),
              RecoPage(state: s),
              SettingsPage(state: s),
            ],
          ),
          bottomNavigationBar: NavigationBar(
            height: 62,
            selectedIndex: _tab,
            onDestinationSelected: (i) => setState(() => _tab = i),
            labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.dashboard_outlined),
                selectedIcon: Icon(Icons.dashboard_rounded),
                label: '活动',
              ),
              NavigationDestination(
                icon: Icon(Icons.notifications_none_rounded),
                selectedIcon: Icon(Icons.notifications_rounded),
                label: '提醒',
              ),
              NavigationDestination(
                icon: Icon(Icons.settings_outlined),
                selectedIcon: Icon(Icons.settings_rounded),
                label: '设置',
              ),
            ],
          ),
        );
      },
    );
  }
}

class _Splash extends StatelessWidget {
  const _Splash();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.school_rounded, size: 44, color: kBrand),
            SizedBox(height: 16),
            Text('二课提醒',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            SizedBox(height: 14),
            SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(strokeWidth: 2.2),
            ),
          ],
        ),
      ),
    );
  }
}

/// 启动阶段就挂了（读本地库 / Keystore 出错）时的兜底页。
/// 之前这里只会一直转圈，用户既不知道发生了什么也没法自救。
class _BootError extends StatelessWidget {
  const _BootError({required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline_rounded, size: 40, color: kBrand),
              const SizedBox(height: 14),
              const Text('启动没成功',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              Text(
                state.bootError,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 12.5,
                  height: 1.5,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 20),
              FilledButton.icon(
                onPressed: state.retryBoot,
                icon: const Icon(Icons.refresh_rounded, size: 18),
                label: const Text('重试'),
              ),
              const SizedBox(height: 12),
              Text(
                '还是不行就卸载重装一次（数据都在服务器上，不会丢活动）',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 11.5,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
