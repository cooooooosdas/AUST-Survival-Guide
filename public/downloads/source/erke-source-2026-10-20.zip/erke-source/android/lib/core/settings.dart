/// 本地设置（画像 / 检索策略 / 提醒），用 shared_preferences 存 JSON。
library;

import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

class AppSettings {
  AppSettings({
    this.schoolId = '',
    this.schoolName = '',
    this.accountMasked = '',
    Profile? profile,
    this.intervalMinutes = 30,
    this.quietStart = '23:30',
    this.quietEnd = '07:00',
    this.limit = 3,
    this.minScore = 35,
    this.notifyEnabled = true,
    this.enrichLimit = 20,
    this.lastSyncAt = '',
    this.onboarded = false,
  }) : profile = profile ?? Profile();

  String schoolId;
  String schoolName;
  String accountMasked;
  Profile profile;

  /// 后台轮询尝试间隔（分钟）。Android 系统实际最短约 15 分钟。
  int intervalMinutes;
  String quietStart;
  String quietEnd;

  /// 推荐条数与阈值
  int limit;
  double minScore;

  bool notifyEnabled;
  int enrichLimit;
  String lastSyncAt;

  /// 是否已走完首次向导（走完 / 跳过都算 true）
  bool onboarded;

  static Profile _profileFrom(Object? raw) =>
      Profile.fromMap(raw is Map<String, dynamic> ? raw : null);

  Map<String, dynamic> toJson() => {
        'schoolId': schoolId,
        'schoolName': schoolName,
        'accountMasked': accountMasked,
        'profile': profile.toMap(),
        'intervalMinutes': intervalMinutes,
        'quietStart': quietStart,
        'quietEnd': quietEnd,
        'limit': limit,
        'minScore': minScore,
        'notifyEnabled': notifyEnabled,
        'enrichLimit': enrichLimit,
        'lastSyncAt': lastSyncAt,
        'onboarded': onboarded,
      };

  static AppSettings fromJson(Map<String, dynamic> m) => AppSettings(
        schoolId: '${m['schoolId'] ?? ''}',
        schoolName: '${m['schoolName'] ?? ''}',
        accountMasked: '${m['accountMasked'] ?? ''}',
        profile: _profileFrom(m['profile']),
        intervalMinutes: toInt(m['intervalMinutes'], 30),
        quietStart: '${m['quietStart'] ?? '23:30'}',
        quietEnd: '${m['quietEnd'] ?? '07:00'}',
        limit: toInt(m['limit'], 3),
        minScore: toDouble(m['minScore'], 35),
        notifyEnabled: m['notifyEnabled'] != false,
        enrichLimit: toInt(m['enrichLimit'], 20),
        lastSyncAt: '${m['lastSyncAt'] ?? ''}',
        onboarded: m['onboarded'] == true,
      );

  AppSettings copy() => AppSettings.fromJson(jsonDecode(jsonEncode(toJson())));
}

class SettingsStore {
  static const _key = 'erke.settings.v1';

  Future<AppSettings> load() async {
    final sp = await SharedPreferences.getInstance();
    final raw = sp.getString(_key);
    if (raw == null || raw.isEmpty) return AppSettings();
    try {
      return AppSettings.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return AppSettings();
    }
  }

  Future<void> save(AppSettings settings) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(_key, jsonEncode(settings.toJson()));
  }
}

/// 免打扰判断：支持跨零点区间（如 23:30-07:00）。
bool inQuietHours(AppSettings s, [DateTime? now]) {
  int minutes(String hhmm) {
    final parts = hhmm.split(':');
    if (parts.length != 2) return -1;
    final h = int.tryParse(parts[0]);
    final m = int.tryParse(parts[1]);
    if (h == null || m == null) return -1;
    return h * 60 + m;
  }

  final start = minutes(s.quietStart);
  final end = minutes(s.quietEnd);
  if (start < 0 || end < 0 || start == end) return false;
  final n = now ?? DateTime.now();
  final cur = n.hour * 60 + n.minute;
  if (start < end) return cur >= start && cur < end;
  return cur >= start || cur < end;
}
