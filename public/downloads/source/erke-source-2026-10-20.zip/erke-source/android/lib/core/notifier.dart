/// 本地通知：只发「精选推荐」，一条通知最多带 3 个活动。
library;

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:url_launcher/url_launcher.dart';

import 'models.dart';

class Notifier {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static const _channelId = 'erke_reco';
  static const _channelName = '二课精选推荐';

  /// 通知栏小图标：必须是「白色剪影 + 透明底」的 drawable。
  /// 不能用 @mipmap/ic_launcher —— 那个是自适应图标，系统只取 alpha 通道，
  /// 在真机上会渲染成一块纯白方块。图标由 tools/make_notify_icon.py 生成。
  static const _icon = 'ic_notify';

  static Future<void> init() async {
    if (_ready) return;
    const android = AndroidInitializationSettings(_icon);
    await _plugin.initialize(
      const InitializationSettings(android: android),
      // 点通知 → 直接打开这条活动的报名页
      onDidReceiveNotificationResponse: (resp) async {
        final url = (resp.payload ?? '').trim();
        if (url.isEmpty) return;
        final uri = Uri.tryParse(url);
        if (uri == null) return;
        try {
          await launchUrl(uri, mode: LaunchMode.externalApplication);
        } catch (_) {
          // 没有浏览器就静默失败，用户还能从 App 里点
        }
      },
    );
    final impl = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await impl?.createNotificationChannel(const AndroidNotificationChannel(
      _channelId,
      _channelName,
      description: '有新活动符合你的画像时提醒',
      importance: Importance.high,
    ));
    _ready = true;
  }

  static Future<bool> requestPermission() async {
    final impl = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    final granted = await impl?.requestNotificationsPermission();
    return granted ?? false;
  }

  static Future<void> showRecommendations(List<Activity> items) async {
    if (items.isEmpty) return;
    await init();
    final first = items.first;
    final title = items.length == 1
        ? '发现 1 个值得报的活动'
        : '发现 ${items.length} 个值得报的活动';
    final body = StringBuffer()
      ..write(first.title)
      ..write('  ·  ')
      ..write(first.hours > 0
          ? '${first.hours == first.hours.roundToDouble() ? first.hours.toInt() : first.hours} 学时'
          : first.creditType);
    if (first.capacity > 0 && first.seatsLeft > 0 && first.seatsLeft <= 5) {
      body.write(' · 只剩 ${first.seatsLeft} 个名额');
    }
    for (final a in items.skip(1)) {
      body.write('\n${a.title}');
    }

    await _plugin.show(
      1001,
      title,
      body.toString(),
      NotificationDetails(
        android: AndroidNotificationDetails(
          _channelId,
          _channelName,
          icon: _icon,
          channelDescription: '有新活动符合你的画像时提醒',
          importance: Importance.high,
          priority: Priority.high,
          // 展开后显示完整列表；传空串会让展开视图一片空白
          styleInformation: BigTextStyleInformation(
            body.toString(),
            contentTitle: title,
          ),
          autoCancel: true,
        ),
      ),
      payload: first.signupUrl,
    );
  }

  static Future<void> showSimple(String title, String body) async {
    await init();
    await _plugin.show(
      1002,
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails(_channelId, _channelName,
            icon: _icon,
            importance: Importance.defaultImportance,
            priority: Priority.defaultPriority),
      ),
    );
  }
}
