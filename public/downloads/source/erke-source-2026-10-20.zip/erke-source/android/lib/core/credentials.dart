/// 凭据：账号密码与 token 存 Android Keystore（flutter_secure_storage）。
///
/// 桌面版用 Windows DPAPI；手机上等价物是 Keystore/Keychain，
/// 同样绑定本机，拷给别人也解不开。界面上只显示掩码。
library;

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class Credentials {
  Credentials({this.account = '', this.password = '', this.token = ''});

  String account;
  String password;
  String token;

  bool get hasPassword => account.isNotEmpty && password.isNotEmpty;
  bool get hasSession => token.isNotEmpty;

  String get maskedAccount {
    if (account.isEmpty) return '';
    if (account.length <= 4) return '${account[0]}***';
    return '${account.substring(0, 2)}****${account.substring(account.length - 2)}';
  }
}

class CredentialVault {
  static const _kAccount = 'erke.account';
  static const _kPassword = 'erke.password';
  static const _kToken = 'erke.token';

  final FlutterSecureStorage _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  Future<Credentials> load() async {
    try {
      final values = await _storage.readAll();
      return Credentials(
        account: values[_kAccount] ?? '',
        password: values[_kPassword] ?? '',
        token: values[_kToken] ?? '',
      );
    } catch (_) {
      return Credentials();
    }
  }

  Future<void> save(Credentials c) async {
    await _storage.write(key: _kAccount, value: c.account);
    await _storage.write(key: _kPassword, value: c.password);
    await _storage.write(key: _kToken, value: c.token);
  }

  Future<void> saveToken(String token) async {
    await _storage.write(key: _kToken, value: token);
  }

  Future<void> clear() async {
    try {
      await _storage.delete(key: _kPassword);
      await _storage.delete(key: _kToken);
      await _storage.delete(key: _kAccount);
    } catch (_) {}
  }
}
