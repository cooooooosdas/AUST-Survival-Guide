/// 一次完整同步：登录 → 拉活动 → 匹配打分 → 入库 → 挑推荐 → 发本地通知。
library;

import 'api.dart';
import 'credentials.dart';
import 'curator.dart';
import 'models.dart';
import 'notifier.dart';
import 'settings.dart';
import 'store.dart';

class SyncOutcome {
  SyncOutcome({
    required this.ok,
    this.message = '',
    this.total = 0,
    this.newCount = 0,
    this.recommended = const [],
    this.notified = false,
    this.demo = false,
  });

  final bool ok;
  final String message;
  final int total;
  final int newCount;
  final List<Activity> recommended;
  final bool notified;
  final bool demo;
}

class SyncService {
  SyncService({
    required this.api,
    required this.store,
    required this.vault,
  });

  final XueqiApi api;
  final ActivityStore store;
  final CredentialVault vault;

  /// 返回 true 表示已登录（token 有效或刚刚登录成功）。
  Future<bool> ensureLogin(AppSettings settings) async {
    if (api.loggedIn) {
      if (await api.keepalive()) return true;
    }
    final creds = await vault.load();
    if (creds.token.isNotEmpty) {
      api.setToken(creds.token);
      if (await api.keepalive()) return true;
    }
    if (!creds.hasPassword || settings.schoolId.isEmpty) return false;

    final result = await api.login(
      schoolId: settings.schoolId,
      account: creds.account,
      password: creds.password,
    );
    if (!result.ok) return false;
    await vault.saveToken(api.token);
    settings.accountMasked = creds.maskedAccount;
    // 首次登录把学校/学院/专业/年级补进画像，省得用户手填
    final hint = result.hint;
    if (settings.schoolName.isEmpty && '${hint['schoolName'] ?? ''}'.isNotEmpty) {
      settings.schoolName = '${hint['schoolName']}';
    }
    if (settings.profile.grade.isEmpty && '${hint['grade'] ?? ''}'.isNotEmpty) {
      settings.profile.grade = '${hint['grade']}';
    }
    if (settings.profile.college.isEmpty && '${hint['college'] ?? ''}'.isNotEmpty) {
      settings.profile.college = '${hint['college']}';
    }
    if (settings.profile.major.isEmpty && '${hint['major'] ?? ''}'.isNotEmpty) {
      settings.profile.major = '${hint['major']}';
    }
    // 班级：活动详情的 organizationList（参与组织）就是按这个维度限制报名的
    if (settings.profile.clazz.isEmpty && '${hint['clazz'] ?? ''}'.isNotEmpty) {
      settings.profile.clazz = '${hint['clazz']}';
    }
    return true;
  }

  Future<SyncOutcome> run(
    AppSettings settings, {
    bool allowNotify = true,
    bool fromBackground = false,
  }) async {
    final loggedIn = await ensureLogin(settings);

    if (!loggedIn) {
      final existing = await store.loadAll();
      if (existing.isEmpty) {
        final demo = demoActivities();
        final scored = applyMatching(demo, settings.profile);
        await store.upsertAll(scored);
        return SyncOutcome(
          ok: true,
          message: '未登录，先展示演示数据（登录后自动切到真实活动）',
          total: scored.length,
          demo: true,
        );
      }
      return SyncOutcome(
        ok: false,
        message: '未登录：请到「设置 → 账号」填写学号密码',
        total: existing.length,
      );
    }

    // 真实同步前把演示数据清掉，避免真假混在一起
    var existingRows = await store.loadAll();
    if (existingRows.any((a) => a.id.startsWith('demo-'))) {
      await store.clearAll();
      existingRows = const [];
    }

    // 库里已有详情的活动不再重复拉详情：预算省下来给还没补全的，
    // 这样列表尾部的活动也能在后续几轮里陆续补上并参与推荐。
    final known = existingRows
        .where((a) => a.intro.isNotEmpty || a.capacity > 0)
        .map((a) => a.id)
        .toSet();

    final fetched = await api.fetchActivities(
      pages: 5,
      pageSize: 20,
      enrichLimit: settings.enrichLimit,
      knownIds: known,
    );
    if (!fetched.ok) {
      return SyncOutcome(ok: false, message: fetched.message);
    }

    final scored = applyMatching(fetched.activities, settings.profile);
    final newCount = await store.upsertAll(scored);

    // 推荐：只用本轮「够格」的，且排除推过的
    final ledger = await store.ledger();
    final all = await store.loadAll();
    final picked = pick(
      all,
      limit: settings.limit,
      minScore: settings.minScore,
      excludeIds: ledger.keys.toSet(),
    );

    var notified = false;
    if (allowNotify && picked.isNotEmpty && settings.notifyEnabled) {
      if (!inQuietHours(settings)) {
        await Notifier.showRecommendations(picked);
        final stamp = DateTime.now().toString().substring(0, 19);
        final next = {...ledger};
        for (final a in picked) {
          next[a.id] = stamp;
        }
        // 台账只留最近 300 条
        final trimmed = next.entries.toList()
          ..sort((a, b) => b.value.compareTo(a.value));
        await store.saveLedger({for (final e in trimmed.take(300)) e.key: e.value});
        notified = true;
      }
    }

    return SyncOutcome(
      ok: true,
      message: fetched.message,
      total: all.length,
      newCount: newCount,
      recommended: picked,
      notified: notified,
    );
  }
}
