/// 趣拓（9xueqi）第二课堂接口客户端。
///
/// 契约来自桌面版实测逆向，移动端原样复用（见 erke-helper/docs/02-接口逆向记录.md）：
///   * GET 和 POST 的参数都必须**整体序列化成 JSON 串**，塞进唯一的 `params`；
///     平铺参数会被服务端判成 10002「参数必须是JSON格式」。
///   * 鉴权靠 header `Authorization: <token>`（JWT）。
///   * 业务码：0 成功 / 10001 会话失效 / 10002 参数错误。
library;

import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'models.dart';

const String kDefaultBaseUrl = 'https://win.9xueqi.com/api/app/client/v1/';
const String kDefaultWebOrigin = 'https://win.9xueqi.com';
const String kPlatformVersion = '2.0.5';
const int kPlatform = 3;
const String kDeviceId = 'FAAE6E21-013F-42D1-B722-599DE3DC340F';

const String _ua =
    'Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

class ApiException implements Exception {
  ApiException(this.message, {this.code});
  final String message;
  final int? code;
  @override
  String toString() => message;
}

class SessionExpiredException extends ApiException {
  SessionExpiredException([super.message = '登录已失效，请重新登录'])
      : super(code: 10001);
}

class LoginResult {
  LoginResult({
    required this.ok,
    this.message = '',
    this.displayName = '',
    this.hint = const {},
  });
  final bool ok;
  final String message;
  final String displayName;
  final Map<String, dynamic> hint;
}

class FetchResult {
  FetchResult({
    required this.ok,
    this.message = '',
    this.activities = const [],
    this.rawTotal = 0,
    this.enriched = 0,
  });
  final bool ok;
  final String message;
  final List<Activity> activities;
  final int rawTotal;
  final int enriched;
}

class XueqiApi {
  XueqiApi({
    this.baseUrl = kDefaultBaseUrl,
    this.webOrigin = kDefaultWebOrigin,
    this.timeout = const Duration(seconds: 20),
    this.minInterval = const Duration(milliseconds: 900),
    http.Client? client,
  }) : _client = client ?? http.Client();

  final String baseUrl;
  final String webOrigin;
  final Duration timeout;
  final Duration minInterval;
  final http.Client _client;

  String _token = '';
  String account = '';
  DateTime _lastRequestAt = DateTime.fromMillisecondsSinceEpoch(0);

  bool get loggedIn => _token.isNotEmpty;
  String get token => _token;

  void setToken(String value) {
    _token = value;
  }

  void clearToken() {
    _token = '';
  }

  Uri _uri(String path, Map<String, dynamic> params) {
    final merged = <String, dynamic>{
      ...params,
      ..._commonParams(),
    };
    final packed = jsonEncode(merged);
    return Uri.parse('${baseUrl.replaceAll(RegExp(r'/+$'), '')}/$path')
        .replace(queryParameters: {'params': packed});
  }

  Map<String, dynamic> _commonParams() => {
        'token': _token,
        'platform': kPlatform,
        'version': kPlatformVersion,
        'device': kDeviceId,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };

  Map<String, String> get _headers => {
        'User-Agent': _ua,
        'Accept': 'application/json, text/plain, */*',
        'Origin': webOrigin,
        'Referer': '$webOrigin/',
        'Content-Type': 'application/x-www-form-urlencoded',
        if (_token.isNotEmpty) 'Authorization': _token,
      };

  Future<void> _throttle() async {
    final wait = minInterval - DateTime.now().difference(_lastRequestAt);
    if (wait > Duration.zero) await Future<void>.delayed(wait);
    _lastRequestAt = DateTime.now();
  }

  Future<Map<String, dynamic>> _get(String path,
      [Map<String, dynamic> params = const {}]) async {
    await _throttle();
    final resp = await _client
        .get(_uri(path, params), headers: _headers)
        .timeout(timeout, onTimeout: () => throw ApiException('请求超时，检查网络'));
    return _decode(resp, path);
  }

  Future<Map<String, dynamic>> _post(String path, Map<String, dynamic> body) async {
    await _throttle();
    final merged = {...body, ..._commonParams()};
    final resp = await _client
        .post(
          Uri.parse('${baseUrl.replaceAll(RegExp(r'/+$'), '')}/$path'),
          headers: _headers,
          body: {'params': jsonEncode(merged)},
        )
        .timeout(timeout, onTimeout: () => throw ApiException('请求超时，检查网络'));
    return _decode(resp, path);
  }

  Map<String, dynamic> _decode(http.Response resp, String path) {
    if (resp.statusCode != 200) {
      throw ApiException('HTTP ${resp.statusCode}（$path）');
    }
    Map<String, dynamic> payload;
    try {
      payload = jsonDecode(utf8.decode(resp.bodyBytes)) as Map<String, dynamic>;
    } catch (_) {
      throw ApiException('返回内容不是合法 JSON（$path）');
    }
    final code = toInt(payload['code'], -1);
    if (code == 10001) {
      _token = '';
      throw SessionExpiredException('${payload['msg'] ?? '登录已失效'}');
    }
    if (code != 0) {
      throw ApiException('${payload['msg'] ?? '业务失败'}（code=$code）', code: code);
    }
    return payload;
  }

  // -------------------------------------------------------------------------
  // 登录
  // -------------------------------------------------------------------------

  Future<LoginResult> login({
    required String schoolId,
    required String account,
    required String password,
  }) async {
    if (schoolId.trim().isEmpty) {
      return LoginResult(ok: false, message: '请先选择学校');
    }
    if (account.trim().isEmpty || password.isEmpty) {
      return LoginResult(ok: false, message: '请填写学号和密码');
    }
    try {
      final payload = await _post('token', {
        'schoolCode': schoolId.trim(),
        'code': account.trim(),
        'password': password,
        'openId': '',
      });
      final data = payload['data'];
      final token = (data is Map ? (data['access_token'] ?? payload['token']) : payload['token'])
              ?.toString() ??
          '';
      if (token.isEmpty) {
        return LoginResult(ok: false, message: '登录成功但未取到 access_token');
      }
      _token = token;
      this.account = account.trim();
      final info = await myInfo();
      return LoginResult(
        ok: true,
        message: '登录成功',
        displayName: _pickStr(info, ['userName', 'name', 'realName', 'studentName'],
            fallback: account.trim()),
        hint: profileHint(info),
      );
    } on SessionExpiredException catch (e) {
      return LoginResult(ok: false, message: e.message);
    } on ApiException catch (e) {
      final msg = e.code == 10002
          ? '参数错误（10002）：学校编号或账号格式不对，请重新选择学校'
          : e.message;
      return LoginResult(ok: false, message: msg);
    } catch (e) {
      return LoginResult(ok: false, message: '登录请求失败：$e');
    }
  }

  Future<Map<String, dynamic>> myInfo() async {
    try {
      final payload = await _get('student/user/my-info');
      final data = payload['data'];
      return data is Map<String, dynamic> ? data : <String, dynamic>{};
    } catch (_) {
      return <String, dynamic>{};
    }
  }

  static Map<String, dynamic> profileHint(Map<String, dynamic> info) => {
        'schoolName': _pickStr(info, ['schoolName', 'schoolShortName']),
        'schoolId': _pickStr(info, ['schoolId']),
        'college': _pickStr(info, ['collegeName', 'departmentName', 'academyName']),
        'major': _pickStr(info, ['majorName', 'specialityName']),
        'grade': _pickStr(info, ['gradeName', 'grade', 'enrollYear']),
        // 学生所属班级/组织，如「软件工程25-4」——活动的参与组织就按这个维度限制报名
        'clazz': _pickStr(info, ['organizationName', 'className', 'classInfo']),
        'name': _pickStr(info, ['userName', 'name', 'realName']),
      };

  /// 轻量保活：命中一个需登录的接口
  Future<bool> keepalive() async {
    if (!loggedIn) return false;
    try {
      await _get('student/user/my-info');
      return true;
    } on SessionExpiredException {
      return false;
    } catch (_) {
      return false;
    }
  }

  // -------------------------------------------------------------------------
  // 活动
  // -------------------------------------------------------------------------

  /// 拉列表 + 按预算补详情（详情里才有报名时间/名额/学时分类）。
  ///
  /// [knownIds]：库里已经有详情的活动 id。这些不再重复请求详情 ——
  /// 之前每轮都把预算花在同一批活动上，导致列表尾部永远拿不到详情、
  /// 也就永远进不了推荐。
  Future<FetchResult> fetchActivities({
    int pages = 3,
    int pageSize = 20,
    int enrichLimit = 20,
    Set<String> knownIds = const {},
  }) async {
    if (!loggedIn) {
      return FetchResult(ok: false, message: '尚未登录');
    }
    final collected = <Activity>[];
    var rawTotal = 0;
    try {
      for (var page = 1; page <= pages; page++) {
        final payload = await _get('activity/list', {
          'pageNum': page,
          'pageSize': pageSize,
          'name': '',
          'classifyId': '',
          'sortType': 2,
        });
        final data = payload['data'];
        if (data is! Map) break;
        final rows = (data['list'] ?? data['records']) as List? ?? const [];
        rawTotal = toInt(data['total'], rawTotal);
        if (rows.isEmpty) break;
        for (final row in rows) {
          if (row is Map<String, dynamic>) collected.add(_mapRow(row));
        }
        if (rows.length < pageSize) break;
        if (rawTotal > 0 && collected.length >= rawTotal) break;
      }
    } on SessionExpiredException catch (e) {
      return FetchResult(ok: false, message: '会话失效：${e.message}');
    } on ApiException catch (e) {
      return FetchResult(ok: false, message: '拉取失败：${e.message}');
    } catch (e) {
      return FetchResult(ok: false, message: '拉取失败：$e');
    }

    // 详情补全是逐条 HTTP，串行的话 20 条 × 最坏 20s 超时 ≈ 400s，
    // 前台首轮要干等、后台还可能撞上 WorkManager 的 10 分钟上限。
    // 这里用 4 路小并发：够快，又不会把学校服务器打疼。
    var enriched = 0;
    var failed = 0;
    var reused = 0;
    final pending = <Activity>[];
    for (final act in collected) {
      if (act.intro.isNotEmpty || knownIds.contains(act.id)) {
        reused++; // 本轮自带详情，或库里已经有了，不重复请求
      } else if (pending.length < enrichLimit) {
        pending.add(act);
      }
    }
    if (pending.isNotEmpty) {
      var cursor = 0;
      Future<void> worker() async {
        while (cursor < pending.length) {
          final act = pending[cursor++];
          final detail = await fetchDetail(act.id);
          if (detail != null) {
            _applyDetail(act, detail);
            enriched++;
          } else {
            failed++;
          }
        }
      }

      final workers = pending.length < 4 ? pending.length : 4;
      await Future.wait(List.generate(workers, (_) => worker()));
    }

    return FetchResult(
      ok: true,
      message: '拉取 ${collected.length} 条'
          '${enriched > 0 ? '，补全 $enriched 条详情' : ''}'
          '${reused > 0 ? '，$reused 条已有详情' : ''}'
          '${failed > 0 ? '（$failed 条详情失败）' : ''}',
      activities: collected,
      rawTotal: rawTotal,
      enriched: enriched,
    );
  }

  Future<Map<String, dynamic>?> fetchDetail(String actId) async {
    try {
      final payload = await _get('activity/detail/non-member', {'id': actId});
      final data = payload['data'];
      return data is Map<String, dynamic> ? data : null;
    } catch (_) {
      return null;
    }
  }

  Activity _mapRow(Map<String, dynamic> row) {
    final id = '${row['id'] ?? row['activityId'] ?? ''}';
    return Activity(
      id: id.isEmpty ? 'x${row.hashCode}' : id,
      title: _pickStr(row, ['name', 'activityName', 'title'], fallback: '未命名活动'),
      organizer: _pickStr(row, ['organizationName', 'orgName']),
      activityStart: fmtDt(row['startTime'] ?? row['activityStartTime']),
      activityEnd: fmtDt(row['endTime'] ?? row['activityEndTime']),
      location: _pickStr(row, ['address', 'activityAddress', 'place']),
      logo: _pickStr(row, ['logo', 'activityLogo', 'coverUrl']),
      status: '${row['organizationStatus'] ?? row['status'] ?? ''}',
      hours: toDouble(row['hours'] ?? row['definedHours']),
      signupUrl: '$webOrigin/#/ActivityShow/$id',
    );
  }

  void _applyDetail(Activity act, Map<String, dynamic> d) {
    final rawType = _pickStr(d, ['classifyName', 'classify']);
    if (rawType.isNotEmpty) {
      act.creditTypeRaw = rawType;
      act.creditType = normalizeCreditType(rawType);
    }
    final title = _pickStr(d, ['name']);
    if (title.isNotEmpty) act.title = title;
    final intro = _pickStr(d, ['introduce', 'content']);
    if (intro.isNotEmpty) act.intro = intro;

    final manager = d['manager'];
    final managerName = manager is Map ? '${manager['name'] ?? ''}' : '';
    final org = _pickStr(d, ['organizationName']);
    if (org.isNotEmpty && managerName.isNotEmpty && !org.contains(managerName)) {
      act.organizer = '$org（$managerName）';
    } else if (managerName.isNotEmpty || org.isNotEmpty) {
      act.organizer = managerName.isNotEmpty ? managerName : org;
    }

    act.capacity = toInt(d['peopleLimit'] ?? d['maxNum']);
    act.enrolled = toInt(d['joinMemberCount'] ?? d['enrollNum']);
    act.enrollStart = fmtDt(d['enrollStartTime']);
    act.enrollEnd = fmtDt(d['enrollEndTime']);
    final s = fmtDt(d['startTime']);
    if (s.isNotEmpty) act.activityStart = s;
    final e = fmtDt(d['endTime']);
    if (e.isNotEmpty) act.activityEnd = e;
    final addr = _pickStr(d, ['address']);
    if (addr.isNotEmpty) act.location = addr;
    final logo = _pickStr(d, ['logo']);
    if (logo.isNotEmpty) act.logo = logo;
    act.gradeScope = _strList(d['gradeList']);
    act.collegeScope = _strList(d['collegeList']);
    act.majorScope = _strList(d['majorList']);
    // 参与组织（班级级限制）：[{'name':'制药25-1_2025'}]，空数组 = 不限班级
    act.orgScope = _strList(d['organizationList']);
    final hours = toDouble(d['hours'] ?? d['definedHours'], act.hours);
    if (hours > 0) act.hours = hours;
  }

  // -------------------------------------------------------------------------
  // 学校 / 字典
  // -------------------------------------------------------------------------

  Future<List<Map<String, String>>> fetchSchools() async {
    final payload = await _get('common/all-school');
    final data = payload['data'];
    final rows = data is List ? data : (data is Map ? (data['list'] as List? ?? const []) : const []);
    final out = <Map<String, String>>[];
    for (final r in rows) {
      if (r is! Map) continue;
      final id = '${r['id'] ?? r['schoolId'] ?? ''}';
      final name = '${r['name'] ?? r['schoolName'] ?? ''}';
      if (id.isNotEmpty && name.isNotEmpty) out.add({'id': id, 'name': name});
    }
    return out;
  }

  /// 学院 / 年级字典；未登录或失败时返回空列表（界面回退成手填）
  Future<List<String>> fetchDict(String path) async {
    if (!loggedIn) return const [];
    try {
      final payload = await _get(path);
      final data = payload['data'];
      final rows = data is List ? data : (data is Map ? (data['list'] as List? ?? const []) : const []);
      final out = <String>[];
      for (final r in rows) {
        if (r is Map) {
          final name = '${r['name'] ?? r['collegeName'] ?? r['gradeName'] ?? ''}';
          if (name.isNotEmpty) out.add(name);
        } else if (r != null) {
          out.add('$r');
        }
      }
      return out;
    } catch (_) {
      return const [];
    }
  }
}

String _pickStr(Map<String, dynamic> obj, List<String> names, {String fallback = ''}) {
  for (final n in names) {
    final v = obj[n];
    if (v != null && v != '' && v != 0) return '$v';
  }
  return fallback;
}

List<String> _strList(Object? value) {
  if (value == null) return const [];
  if (value is String) {
    return value
        .replaceAll('，', ',')
        .replaceAll('、', ',')
        .split(',')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
  }
  if (value is Map) {
    for (final k in ['name', 'names', 'list', 'value', 'label', 'text']) {
      if (value.containsKey(k)) return _strList(value[k]);
    }
    return const [];
  }
  if (value is Iterable) {
    final out = <String>[];
    for (final item in value) {
      out.addAll(_strList(item));
    }
    return out;
  }
  return ['$value'];
}
