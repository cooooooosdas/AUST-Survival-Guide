/// 全局状态：设置 + 活动 + 筛选 + 同步状态。
library;

import 'package:flutter/foundation.dart' show ChangeNotifier, kIsWeb;

import 'api.dart';
import 'credentials.dart';
import 'curator.dart' as curator;
import 'models.dart';
import 'notifier.dart';
import 'settings.dart';
import 'store.dart';
import 'sync.dart';

class AppState extends ChangeNotifier {
  AppState();

  final SettingsStore settingsStore = SettingsStore();
  final CredentialVault vault = CredentialVault();
  final XueqiApi api = XueqiApi();
  late final ActivityStore store =
      kIsWeb ? MemoryActivityStore() : SqliteActivityStore();
  late final SyncService sync =
      SyncService(api: api, store: store, vault: vault);

  AppSettings settings = AppSettings();
  List<Activity> all = const [];
  List<Activity> visible = const [];
  List<Activity> recommended = const [];

  bool initialized = false;
  bool syncing = false;
  String statusText = '';
  String errorText = '';
  String bootError = ''; // 启动阶段就失败（读库 / Keystore 出错），要能看到原因而不是卡在启动页
  String? pendingSignupUrl; // 点通知进来时要跳转的链接

  // 筛选
  String filterCredit = '';
  String filterState = '';
  String keyword = '';
  bool onlyNew = false;
  bool onlyMatchable = false;
  /// 默认隐藏不可报的活动；打开后能看到「为什么被排除」。
  bool showBlocked = false;

  Stats get stats => Stats.of(all, minScore: settings.minScore);

  /// 可报列表：先剔除不在报名范围的活动，再按匹配分由高到低排序。
  ///
  /// 这是所有「给用户看的东西」的唯一入口 —— 统计、首页列表、推荐推送
  /// 都基于它，避免各处口径不一（也是「匹配 9 个，刷新后变 46 个」的根因）。
  List<Activity> get eligible {
    final list = all.where(curator.isEligible).toList();
    list.sort(curator.compareByMatch);
    return list;
  }

  Future<void> init() async {
    bootError = '';
    settings = await settingsStore.load();
    final creds = await vault.load();
    api.setToken(creds.token);
    settings.accountMasked = creds.maskedAccount;
    all = await store.loadAll();
    if (all.isEmpty && !api.loggedIn) {
      final demo = applyMatching(demoActivities(), settings.profile);
      await store.upsertAll(demo);
      all = await store.loadAll();
      statusText = '当前是演示数据，登录后自动切换真实活动';
    }
    _rescore(); // 库里的分数可能是旧画像算的，先按当前画像重算
    applyFilter();
    initialized = true;
    notifyListeners();
  }

  /// 启动失败时把错误摆到界面上（而不是让用户对着启动动画干等）。
  void failBoot(String message) {
    bootError = message.trim().isEmpty ? '未知错误' : message;
    initialized = true;
    notifyListeners();
  }

  /// 启动失败后重试。有些机型是 Keystore 一时不可用，重试一次往往就好了。
  Future<void> retryBoot() async {
    bootError = '';
    initialized = false;
    notifyListeners();
    try {
      await init();
    } catch (e) {
      failBoot('$e');
    }
  }

  /// 只重读本地库（清缓存后 / 从后台任务回来时用）。
  Future<void> reload() async {
    all = await store.loadAll();
    _rescore();
    applyFilter();
  }

  void applyFilter() {
    // 起点是「可报」列表（已按匹配分降序），不是全库：
    // 报不了名的活动不进列表、不进统计，也不该出现在报名流程里。
    var list = showBlocked ? all.toList() : all.where(curator.isEligible).toList();
    if (filterCredit.isNotEmpty) {
      list = list.where((a) => a.creditType == filterCredit).toList();
    }
    if (filterState.isNotEmpty) {
      list = list.where((a) => a.enrollState == filterState).toList();
    }
    if (onlyNew) {
      list = list.where((a) => a.isNew).toList();
    }
    if (onlyMatchable) {
      // 与推送门槛同口径，避免「列表里显示匹配」和「实际推送」两套标准
      final min = settings.minScore;
      list = list.where((a) => a.matchScore >= min).toList();
    }
    if (keyword.trim().isNotEmpty) {
      final k = keyword.trim();
      list = list
          .where((a) =>
              a.title.contains(k) || a.intro.contains(k) || a.organizer.contains(k))
          .toList();
    }
    // 无论怎么筛，展示顺序始终是「匹配分由高到低」
    list.sort(curator.compareByMatch);
    visible = list;
    notifyListeners();
  }

  void setCredit(String value) {
    filterCredit = filterCredit == value ? '' : value;
    applyFilter();
  }

  void setState_(String value) {
    filterState = filterState == value ? '' : value;
    applyFilter();
  }

  void setKeyword(String value) {
    keyword = value;
    applyFilter();
  }

  void toggleOnlyNew(bool v) {
    onlyNew = v;
    applyFilter();
  }

  void toggleOnlyMatchable(bool v) {
    onlyMatchable = v;
    applyFilter();
  }

  void toggleShowBlocked(bool v) {
    showBlocked = v;
    applyFilter();
  }

  /// 用当前画像重算一遍分数（不落库）。
  ///
  /// 为什么必须：库里存的是**上一次画像**下的 match_score。
  /// 改完画像 / 换了班级之后如果直接读库，首页会显示一批旧分数 ——
  /// 表现就是「保存后匹配 9 个，刷新一下突然变 46 个」。
  void _rescore() {
    if (all.isEmpty) return;
    applyMatching(all, settings.profile);
    all.sort(curator.compareByMatch);
  }

  Future<SyncOutcome> refresh({bool allowNotify = true}) async {
    if (syncing) {
      return SyncOutcome(ok: false, message: '正在同步中');
    }
    syncing = true;
    errorText = '';
    statusText = '正在检索…';
    notifyListeners();

    SyncOutcome outcome;
    try {
      outcome = await sync.run(settings, allowNotify: allowNotify);
      all = await store.loadAll();
      _rescore(); // 新拉取的活动 + 旧数据统一按当前画像重算，统计才不会跳
      applyFilter();
      settings.lastSyncAt = DateTime.now().toString().substring(0, 16);
      await settingsStore.save(settings);
      statusText = outcome.message;
      if (!outcome.ok) errorText = outcome.message;
      recommended = outcome.recommended;
    } catch (e) {
      outcome = SyncOutcome(ok: false, message: '同步失败：$e');
      errorText = outcome.message;
      statusText = outcome.message;
    } finally {
      syncing = false;
      notifyListeners();
    }
    return outcome;
  }

  Future<void> saveSettings(AppSettings next) async {
    settings = next;
    await settingsStore.save(settings);
    // 画像变了要重算分数
    if (all.isNotEmpty) {
      final rescored = applyMatching(all, settings.profile);
      await store.upsertAll(rescored);
      all = await store.loadAll();
      applyFilter();
    }
    notifyListeners();
  }

  Future<void> saveAccount({
    required String schoolId,
    required String schoolName,
    required String account,
    required String password,
  }) async {
    settings.schoolId = schoolId;
    settings.schoolName = schoolName;
    api.clearToken();
    final creds = Credentials(account: account, password: password);
    await vault.save(creds);
    settings.accountMasked = creds.maskedAccount;
    await settingsStore.save(settings);
    notifyListeners();
  }

  Future<String> testLogin({
    required String schoolId,
    required String account,
    required String password,
  }) async {
    final probe = XueqiApi();
    final result = await probe.login(
      schoolId: schoolId,
      account: account,
      password: password,
    );
    if (!result.ok) return '登录失败：${result.message}';
    api.setToken(probe.token);
    await vault.saveToken(probe.token);
    final hint = result.hint;
    if ('${hint['college'] ?? ''}'.isNotEmpty && settings.profile.college.isEmpty) {
      settings.profile.college = '${hint['college']}';
    }
    if ('${hint['major'] ?? ''}'.isNotEmpty && settings.profile.major.isEmpty) {
      settings.profile.major = '${hint['major']}';
    }
    if ('${hint['grade'] ?? ''}'.isNotEmpty && settings.profile.grade.isEmpty) {
      settings.profile.grade = '${hint['grade']}';
    }
    if ('${hint['clazz'] ?? ''}'.isNotEmpty && settings.profile.clazz.isEmpty) {
      settings.profile.clazz = '${hint['clazz']}';
    }
    await settingsStore.save(settings);
    await Notifier.init();
    return '登录成功：${result.displayName.isEmpty ? account : result.displayName}';
  }

  Future<void> clearCredentials() async {
    await vault.clear();
    api.clearToken();
    settings.accountMasked = '';
    await settingsStore.save(settings);
    notifyListeners();
  }

  Future<void> countAsSeen(List<String> ids) async {
    final ledger = await store.ledger();
    final stamp = DateTime.now().toString().substring(0, 19);
    for (final id in ids) {
      ledger[id] = stamp;
    }
    await store.saveLedger(ledger);
  }
}
