/// 「推哪一条」：从整库里挑出此刻最值得看的一两条。
///
/// 口径与桌面版一致：
///   1. 够格：匹配分 ≥ 阈值；报名未截止；未满员；距截止 ≥ 30 分钟；详情补全过。
///   2. 去重：同名（去括号/标点）只留最优一条（选手通道 / 观众通道会重复）。
///   3. 排序：匹配分 → 学时 → 截止时间。
///   4. 限量：最多 3 条，第 1 条即首选；不够就少发，绝不凑数。
library;

import 'models.dart';

const int kMinActionableMinutes = 30;
const int kUrgentHours = 24;

const _titleNoise = r'[^\w\u4e00-\u9fa5]+';

String _normTitle(String s) =>
    s.toLowerCase().replaceAll(RegExp(_titleNoise), '');

String _baseTitle(String title) =>
    _normTitle(title.replaceAll(RegExp(r'[（(【\[][^）)】\]]*[）)】\]]'), ''));

double? minutesLeft(Activity a, DateTime now) {
  final end = parseDt(a.enrollEnd);
  if (end == null) return null;
  return end.difference(now).inSeconds / 60.0;
}

/// 不合格返回原因（便于在设置页解释「为什么没推」），合格返回空串。
String rejectReason(Activity a, {double minScore = 35, DateTime? now}) {
  final n = now ?? DateTime.now();
  // 范围硬性不符（年级/学院/专业/班级任一被拦）直接排除：
  // 报了也过不了服务端校验，推了只会浪费一次提醒。
  if (a.hardBlocked) {
    final scopeMiss = a.matchReasons.where((r) => r.startsWith('限')).toList();
    return scopeMiss.isEmpty ? '不在报名范围' : '不在报名范围：${scopeMiss.first}';
  }
  final state = a.enrollState;
  if (state == 'closed') return '报名已截止';
  if (state != 'open' && state != 'upcoming') return '报名状态未知';
  if (a.capacity > 0 && a.seatsLeft <= 0) return '名额已满';
  if (a.matchScore < minScore) {
    return '匹配分 ${a.matchScore.toStringAsFixed(0)} 低于阈值 ${minScore.toStringAsFixed(0)}';
  }
  if (a.intro.isEmpty && a.capacity == 0) return '详情未补全，无法判断';
  final left = minutesLeft(a, n);
  if (left != null && left < kMinActionableMinutes) {
    return '距截止仅剩 ${left.toInt()} 分钟';
  }
  final actEnd = parseDt(a.activityEnd) ?? parseDt(a.activityStart);
  if (actEnd != null && actEnd.isBefore(n)) return '活动已结束';
  return '';
}

bool isUrgent(Activity a, [DateTime? now]) {
  final left = minutesLeft(a, now ?? DateTime.now());
  return left != null && left >= 0 && left <= kUrgentHours * 60;
}

int _cmp(Activity a, Activity b) {
  final byScore = b.matchScore.compareTo(a.matchScore);
  if (byScore != 0) return byScore;
  final byHours = b.hours.compareTo(a.hours);
  if (byHours != 0) return byHours;
  return (parseDt(a.enrollEnd) ?? DateTime(9999))
      .compareTo(parseDt(b.enrollEnd) ?? DateTime(9999));
}

/// 对外的排序口径：先比匹配分（高在前），再比学时，最后比报名截止。
/// 首页列表与推荐列表必须用同一个比较器，否则「看到的排序」和「推送的顺序」会不一致。
int compareByMatch(Activity a, Activity b) => _cmp(a, b);

/// 用户是否真的能报这个活动：年级 / 学院 / 专业 / 班级（参与组织）
/// 任一维度被拦，服务端都会拒绝报名，不进可报基数。
bool isEligible(Activity a) => !a.hardBlocked;

List<Activity> pick(
  List<Activity> activities, {
  int limit = 3,
  double minScore = 35,
  Set<String> excludeIds = const {},
  DateTime? now,
}) {
  final n = now ?? DateTime.now();
  final pool = activities
      .where((a) => !excludeIds.contains(a.id))
      .where((a) => rejectReason(a, minScore: minScore, now: n).isEmpty)
      .toList()
    ..sort(_cmp);

  final best = <String, Activity>{};
  for (final a in pool) {
    final key = _baseTitle(a.title);
    final cur = best[key];
    if (cur == null ||
        a.matchScore > cur.matchScore ||
        (a.matchScore == cur.matchScore && a.hours > cur.hours) ||
        (a.matchScore == cur.matchScore &&
            a.hours == cur.hours &&
            a.title.length < cur.title.length)) {
      best[key] = a;
    }
  }
  final cands = best.values.toList()..sort(_cmp);
  return cands.take(limit < 1 ? 1 : limit).toList();
}

/// 一句话推荐理由（推送正文里用）。
String explain(Activity a) {
  final bits = a.matchReasons
      .where((r) => r.isNotEmpty && !RegExp(r'限|排除|已满|不在|低于').hasMatch(r))
      .take(3)
      .toList();
  if (a.hours > 0 && !bits.any((b) => b.contains('学时'))) {
    bits.add('${a.hours == a.hours.roundToDouble() ? a.hours.toInt() : a.hours} 学时');
  }
  return bits.isEmpty ? '符合你的年级/学院条件' : bits.join(' · ');
}

List<String> tags(Activity a) {
  final out = <String>[];
  if (isUrgent(a)) out.add('今天截止');
  if (a.capacity > 0 && a.seatsLeft > 0 && a.seatsLeft <= 5) {
    out.add('只剩 ${a.seatsLeft} 个名额');
  }
  if (a.hours >= 5) {
    out.add(a.hours == a.hours.roundToDouble() ? '${a.hours.toInt()} 学时' : '${a.hours} 学时');
  }
  if (a.enrollState == 'upcoming') out.add('还未开始报名');
  return out;
}
