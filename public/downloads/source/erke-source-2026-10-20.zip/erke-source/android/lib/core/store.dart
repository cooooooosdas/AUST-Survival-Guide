/// 活动库：Android 上用 sqflite；测试/预览用内存实现。
library;

import 'dart:convert';

import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import 'models.dart';

abstract class ActivityStore {
  Future<List<Activity>> loadAll();
  Future<int> upsertAll(List<Activity> items);
  Future<void> clearAll();
  Future<Map<String, String>> ledger();
  Future<void> saveLedger(Map<String, String> value);
}

/// SQLite 实现：整条活动以 JSON 存在 payload 里，另抽几个列做常用判断。
class SqliteActivityStore implements ActivityStore {
  Database? _db;

  Future<Database> _open() async {
    if (_db != null) return _db!;
    final dir = await getDatabasesPath();
    _db = await openDatabase(
      p.join(dir, 'erke.db'),
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE activities(
            id TEXT PRIMARY KEY,
            payload TEXT NOT NULL,
            first_seen TEXT NOT NULL,
            last_seen TEXT NOT NULL,
            is_new INTEGER NOT NULL DEFAULT 0
          )
        ''');
        await db.execute('CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT NOT NULL)');
      },
    );
    return _db!;
  }

  @override
  Future<List<Activity>> loadAll() async {
    final db = await _open();
    final rows = await db.query('activities');
    return rows.map((r) {
      final m = jsonDecode(r['payload'] as String) as Map<String, dynamic>;
      m['is_new'] = r['is_new'];
      m['first_seen'] = r['first_seen'];
      m['last_seen'] = r['last_seen'];
      return Activity.fromMap(m);
    }).toList();
  }

  @override
  Future<int> upsertAll(List<Activity> items) async {
    if (items.isEmpty) return 0;
    final db = await _open();
    final now = DateTime.now();
    final stamp = _fmt(now);
    var newCount = 0;
    final batch = db.batch();
    for (final a in items) {
      final existing = await db.query('activities',
          columns: ['id', 'first_seen', 'payload'], where: 'id = ?', whereArgs: [a.id], limit: 1);
      final isNew = existing.isEmpty;
      if (isNew) newCount++;
      a.isNew = isNew;
      a.firstSeen = isNew ? stamp : '${existing.first['first_seen']}';
      a.lastSeen = stamp;

      // 整条覆盖前先把旧 payload 里已有的详情合并进来：
      // 列表接口不带简介/名额/报名时间，直接覆盖会把上一轮补全的详情全部抹掉。
      if (!isNew) {
        final raw = existing.first['payload'];
        if (raw is String && raw.isNotEmpty) {
          try {
            final old = Activity.fromMap(jsonDecode(raw) as Map<String, dynamic>);
            a.mergeDetailsFrom(old);
          } catch (_) {
            // 旧记录解析不了就按新数据写，不因为一条脏数据中断整批
          }
        }
      }

      batch.insert(
        'activities',
        {
          'id': a.id,
          'payload': jsonEncode(a.toMap()),
          'first_seen': a.firstSeen,
          'last_seen': a.lastSeen,
          'is_new': isNew ? 1 : 0,
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
    await batch.commit(noResult: true);
    return newCount;
  }

  @override
  Future<void> clearAll() async {
    final db = await _open();
    await db.delete('activities');
  }

  @override
  Future<Map<String, String>> ledger() async {
    final db = await _open();
    final rows = await db.query('meta', where: 'key = ?', whereArgs: ['ledger'], limit: 1);
    if (rows.isEmpty) return {};
    final raw = jsonDecode(rows.first['value'] as String);
    if (raw is Map) return raw.map((k, v) => MapEntry('$k', '$v'));
    return {};
  }

  @override
  Future<void> saveLedger(Map<String, String> value) async {
    final db = await _open();
    await db.insert('meta', {'key': 'ledger', 'value': jsonEncode(value)},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }
}

/// 内存实现：单元测试与 Flutter Web 预览用。
class MemoryActivityStore implements ActivityStore {
  final Map<String, Map<String, dynamic>> _rows = {};
  Map<String, String> _ledger = {};

  @override
  Future<List<Activity>> loadAll() async => _rows.values
      .map((m) => Activity.fromMap(jsonDecode(jsonEncode(m)) as Map<String, dynamic>))
      .toList();

  @override
  Future<int> upsertAll(List<Activity> items) async {
    var newCount = 0;
    final stamp = _fmt(DateTime.now());
    for (final a in items) {
      final existing = _rows[a.id];
      final isNew = existing == null;
      if (isNew) newCount++;
      a.isNew = isNew;
      a.firstSeen = isNew ? stamp : '${existing['first_seen']}';
      a.lastSeen = stamp;
      // 与 SQLite 版同样先合并旧详情，保证两边行为一致
      if (existing != null) {
        a.mergeDetailsFrom(Activity.fromMap(jsonDecode(jsonEncode(existing)) as Map<String, dynamic>));
      }
      final map = a.toMap();
      map['first_seen'] = a.firstSeen;
      _rows[a.id] = map;
    }
    return newCount;
  }

  @override
  Future<void> clearAll() async => _rows.clear();

  @override
  Future<Map<String, String>> ledger() async => Map<String, String>.from(_ledger);

  @override
  Future<void> saveLedger(Map<String, String> value) async => _ledger = {...value};
}

String _fmt(DateTime t) {
  String two(int v) => v.toString().padLeft(2, '0');
  return '${t.year}-${two(t.month)}-${two(t.day)} ${two(t.hour)}:${two(t.minute)}:${two(t.second)}';
}

/// 演示数据：没登录时也能看到界面（与桌面版 demo 数据源同源）。
List<Activity> demoActivities() {
  final now = DateTime.now();
  String at(int days, int hour) {
    final t = now.add(Duration(days: days));
    String two(int v) => v.toString().padLeft(2, '0');
    return '${t.year}-${two(t.month)}-${two(t.day)} ${two(hour)}:00';
  }

  final raw = <Map<String, Object>>[
    {
      'id': 'demo-1',
      'title': '无偿献血公益活动',
      'intro': '联合市中心血站开展无偿献血。献血成功者可认定社会责任担当类学时，并获纪念礼品一份。',
      'organizer': '校红十字会',
      'credit': '社会责任担当',
      'cap': 150, 'enrolled': 42, 'hours': 3.0,
      'enroll_end': at(3, 18),
    },
    {
      'id': 'demo-2',
      'title': '「暖冬行动」社区敬老志愿服务',
      'intro': '前往结对社区开展敬老陪伴、健康科普、家电维修志愿服务。服务时长满 4 小时认定社会责任担当类学时。',
      'organizer': '青年志愿者协会',
      'credit': '社会责任担当',
      'cap': 8, 'enrolled': 3, 'hours': 4.0,
      'enroll_end': at(4, 20),
    },
    {
      'id': 'demo-3',
      'title': '大学生创新创业大赛校内选拔赛',
      'intro': '面向全校招募参赛团队，优秀项目推荐参加省级「互联网+」大赛，可认定创新创业孵化类学时。',
      'organizer': '创新创业学院',
      'credit': '创新创业孵化',
      'cap': 0, 'enrolled': 0, 'hours': 6.0,
      'enroll_end': at(9, 23),
    },
    {
      'id': 'demo-4',
      'title': '青年马克思主义者培养工程培训班（第五期）',
      'intro': '理论学习 + 实践锻炼，结业认定精英锻炼养成类学时 4 个。限大二及以上学生骨干。',
      'organizer': '校团委',
      'credit': '精英锻炼养成',
      'cap': 60, 'enrolled': 58, 'hours': 4.0,
      'enroll_end': at(5, 12),
    },
    {
      'id': 'demo-5',
      'title': '校园歌手大赛初赛',
      'intro': '一年一度的校园歌手大赛，参赛即可获得综合素质拓展类学时，进入决赛另有奖励。',
      'organizer': '校学生会文艺部',
      'credit': '综合素质拓展',
      'cap': 200, 'enrolled': 120, 'hours': 2.0,
      'enroll_end': at(6, 22),
    },
    {
      'id': 'demo-6',
      'title': '「三下乡」暑期社会实践团队招募',
      'intro': '组建实践团队赴乡村开展支教、调研、科技服务，认定实践能力培养与社会责任担当类学时。',
      'organizer': '校团委实践部',
      'credit': '实践能力培养',
      'cap': 0, 'enrolled': 0, 'hours': 8.0,
      'enroll_end': at(12, 18),
    },
    {
      'id': 'demo-7',
      'title': '形势与政策专题报告会：大国工匠进校园',
      'intro': '邀请大国工匠作专题报告，现场签到认定思想政治引领类学时 2 个。',
      'organizer': '马克思主义学院',
      'credit': '思想政治引领',
      'cap': 120, 'enrolled': 120, 'hours': 2.0,
      'enroll_end': at(1, 17),
    },
    {
      'id': 'demo-8',
      'title': '大学生职业规划与就业指导讲座',
      'intro': '简历撰写、面试技巧与行业趋势解析，认定实践能力培养类学时 2 个。',
      'organizer': '就业指导中心',
      'credit': '实践能力培养',
      'cap': 80, 'enrolled': 35, 'hours': 2.0,
      'enroll_end': at(2, 19),
    },
  ];

  return raw.map((m) {
    return Activity(
      id: m['id'] as String,
      title: m['title'] as String,
      intro: m['intro'] as String,
      organizer: m['organizer'] as String,
      creditType: m['credit'] as String,
      creditTypeRaw: m['credit'] as String,
      capacity: m['cap'] as int,
      enrolled: m['enrolled'] as int,
      hours: (m['hours'] as double),
      enrollStart: at(-5, 9),
      enrollEnd: m['enroll_end'] as String,
      activityStart: at(15, 14),
      activityEnd: at(15, 17),
      location: '大学生活动中心',
      gradeScope: const [],
      collegeScope: const [],
      majorScope: const [],
      signupUrl: 'https://win.9xueqi.com/#/ActivityShow/${m['id']}',
    );
  }).toList();
}
