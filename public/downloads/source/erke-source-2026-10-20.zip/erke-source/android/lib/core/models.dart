/// 领域模型：六类学时、活动、用户画像、匹配打分。
///
/// 移植自桌面版 `backend/models.py`，口径保持完全一致：
/// 年级 +22 / 学院 +26（全校 +10）/ 专业 +20 / 学时类型 +12 / 关键词 +4 /
/// 学时加权 0~12 / 名额紧张 +4（已满 -10）；命中硬性排除项则压到 0 以下。
library;

const List<String> kCreditTypes = [
  '思想政治引领',
  '精英锻炼养成',
  '综合素质拓展',
  '创新创业孵化',
  '社会责任担当',
  '实践能力培养',
];

const String kCreditUnknown = '未分类';

/// 各校分类名写法不一，按关键词归一化到六类。
const Map<String, List<String>> _creditKeywords = {
  '思想政治引领': [
    '思想政治', '思想引领', '思政', '党建', '党团', '红色', '理论', '理想信念',
    '道德修养', '法治', '形势政策', '青马', '团课', '主题教育',
  ],
  '精英锻炼养成': [
    // 趣拓里写作「菁英」，两个写法都要命中
    '精英', '菁英', '骨干', '养成', '领导力', '学生干部', '团学骨干', '培训班',
    '青马工程', '素质提升', '能力提升', '训练营',
  ],
  '综合素质拓展': [
    '综合素质', '文体', '文艺', '体育', '美育', '劳育', '心理', '社团', '艺术',
    '文化', '兴趣', '拓展', '健康', '道德', '人文',
  ],
  '创新创业孵化': [
    '创新创业', '创业', '创新', '孵化', '竞赛', '挑战杯', '互联网+', '创青春',
    '科研', '学术科技', '专利', '学科竞赛',
  ],
  '社会责任担当': [
    '社会责任', '志愿', '公益', '服务', '奉献', '帮扶', '支教', '无偿献血',
    '社会实践', '暑期实践', '三下乡', '社区服务', '义工',
  ],
  '实践能力培养': [
    '实践能力', '实践', '实习', '实训', '技能', '职业', '就业', '见习',
    '岗位', '调研', '劳动', '技能培训', '专业实践',
  ],
};

String normalizeCreditType(String? raw) {
  if (raw == null) return kCreditUnknown;
  final text = raw.trim();
  if (text.isEmpty) return kCreditUnknown;
  if (kCreditTypes.contains(text)) return text;
  for (final entry in _creditKeywords.entries) {
    for (final kw in entry.value) {
      if (text.contains(kw)) return entry.key;
    }
  }
  return kCreditUnknown;
}

int creditSortKey(String name) {
  final i = kCreditTypes.indexOf(name);
  return i < 0 ? kCreditTypes.length : i;
}

// ---------------------------------------------------------------------------
// 时间工具
// ---------------------------------------------------------------------------

const List<String> _dtPatterns = [
  'yyyy-MM-dd HH:mm:ss',
  'yyyy-MM-dd HH:mm',
  'yyyy/MM/dd HH:mm:ss',
  'yyyy/MM/dd HH:mm',
];

/// 兼容 "2026-10-16 23:25:00" / "2026/10/16" / 毫秒时间戳 / ISO 串。
DateTime? parseDt(Object? value) {
  if (value == null) return null;
  if (value is num) {
    var ts = value.toDouble();
    if (ts <= 0) return null;
    // 10 位（1.7e9）是秒，13 位（1.7e12）是毫秒：小于 1e11 的一律当秒处理
    if (ts < 1e11) ts *= 1000.0;
    return DateTime.fromMillisecondsSinceEpoch(ts.round());
  }
  final text = value.toString().trim();
  if (text.isEmpty || text == '0') return null;
  final asInt = int.tryParse(text);
  if (asInt != null && asInt > 1000000000) return parseDt(asInt);
  for (final p in _dtPatterns) {
    final dt = _tryFormat(text, p);
    if (dt != null) return dt;
  }
  final iso = DateTime.tryParse(text);
  if (iso != null) return iso;
  final m = RegExp(r'(\d{4})\D(\d{1,2})\D(\d{1,2})').firstMatch(text);
  if (m != null) {
    return DateTime(
      int.parse(m.group(1)!),
      int.parse(m.group(2)!),
      int.parse(m.group(3)!),
    );
  }
  return null;
}

DateTime? _tryFormat(String text, String pattern) {
  // 简单实现：只支持本文件用到的几种固定格式
  final m = RegExp(r'^(\d{4})\D(\d{1,2})\D(\d{1,2})'
          r'(?:[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?$')
      .firstMatch(text);
  if (m == null) return null;
  return DateTime(
    int.parse(m.group(1)!),
    int.parse(m.group(2)!),
    int.parse(m.group(3)!),
    int.parse(m.group(4) ?? '0'),
    int.parse(m.group(5) ?? '0'),
    int.parse(m.group(6) ?? '0'),
  );
}

String fmtDt(Object? value) {
  final dt = parseDt(value);
  if (dt == null) return value?.toString() ?? '';
  String two(int v) => v.toString().padLeft(2, '0');
  return '${dt.year}-${two(dt.month)}-${two(dt.day)} ${two(dt.hour)}:${two(dt.minute)}';
}

int toInt(Object? v, [int fallback = 0]) {
  if (v == null) return fallback;
  if (v is num) return v.toInt();
  return int.tryParse(v.toString()) ?? double.tryParse(v.toString())?.toInt() ?? fallback;
}

double toDouble(Object? v, [double fallback = 0]) {
  if (v == null) return fallback;
  if (v is num) return v.toDouble();
  return double.tryParse(v.toString()) ?? fallback;
}

// ---------------------------------------------------------------------------
// 活动
// ---------------------------------------------------------------------------

class Activity {
  Activity({
    required this.id,
    this.title = '',
    this.intro = '',
    this.organizer = '',
    this.creditType = kCreditUnknown,
    this.creditTypeRaw = '',
    this.capacity = 0,
    this.enrolled = 0,
    this.enrollStart = '',
    this.enrollEnd = '',
    this.activityStart = '',
    this.activityEnd = '',
    this.location = '',
    this.hours = 0,
    this.gradeScope = const [],
    this.collegeScope = const [],
    this.majorScope = const [],
    this.orgScope = const [],
    this.signupUrl = '',
    this.logo = '',
    this.status = '',
    this.firstSeen = '',
    this.lastSeen = '',
    this.isNew = false,
    this.matchScore = 0,
    this.matchReasons = const [],
    this.hardBlocked = false,
  });

  final String id;
  String title;
  String intro;
  String organizer;
  String creditType;
  String creditTypeRaw;
  int capacity;
  int enrolled;
  String enrollStart;
  String enrollEnd;
  String activityStart;
  String activityEnd;
  String location;
  double hours;
  List<String> gradeScope;
  List<String> collegeScope;
  List<String> majorScope;

  /// 参与组织（班级级限制）：详情接口 organizationList，形如「制药25-1_2025」。
  /// 非空 = 只允许名单里的班级/组织报名；空 = 不限。
  List<String> orgScope;
  String signupUrl;
  String logo;
  String status;
  String firstSeen;
  String lastSeen;
  bool isNew;
  double matchScore;
  List<String> matchReasons;

  /// 硬性不符（年级/学院/专业/班级任一维度被拦）。
  /// 由 matchActivity 写入，精选器据此直接排除，不依赖分数 Penalty。
  bool hardBlocked;

  /// 剩余名额；-1 表示不限人数
  int get seatsLeft {
    if (capacity <= 0) return -1;
    final left = capacity - enrolled;
    return left < 0 ? 0 : left;
  }

  /// 用库里已存的旧记录补齐本对象缺的「详情字段」。
  ///
  /// 为什么需要：列表接口只给 10 个字段，简介/名额/报名时间/学时分类只在详情里，
  /// 而入库时是整条 payload 覆盖。若不合并，每轮同步都会把上一轮花请求补全的
  /// 详情抹掉 —— 表现就是「永远只有最新那 20 个活动能被推荐」。
  ///
  /// 规则：只看新对象缺什么（空串 / 0），不覆盖已有值；
  /// 数字字段（capacity/enrolled/hours）额外用 `intro.isEmpty` 判断，
  /// 避免把「详情说 0 人上限」误当成「没补全」。
  void mergeDetailsFrom(Activity old) {
    final noDetail = intro.isEmpty;
    if (intro.isEmpty) intro = old.intro;
    if (organizer.isEmpty) organizer = old.organizer;
    if (creditTypeRaw.isEmpty) creditTypeRaw = old.creditTypeRaw;
    if (creditType == kCreditUnknown) creditType = old.creditType;
    if (noDetail && capacity <= 0) capacity = old.capacity;
    if (noDetail && enrolled <= 0) enrolled = old.enrolled;
    if (noDetail && hours <= 0) hours = old.hours;
    if (enrollStart.isEmpty) enrollStart = old.enrollStart;
    if (enrollEnd.isEmpty) enrollEnd = old.enrollEnd;
    if (activityStart.isEmpty) activityStart = old.activityStart;
    if (activityEnd.isEmpty) activityEnd = old.activityEnd;
    if (location.isEmpty) location = old.location;
    if (gradeScope.isEmpty) gradeScope = old.gradeScope;
    if (collegeScope.isEmpty) collegeScope = old.collegeScope;
    if (majorScope.isEmpty) majorScope = old.majorScope;
    if (orgScope.isEmpty) orgScope = old.orgScope;
    if (signupUrl.isEmpty) signupUrl = old.signupUrl;
    if (logo.isEmpty) logo = old.logo;
    if (title.isEmpty) title = old.title;
  }

  bool get isFull => capacity > 0 && seatsLeft == 0;

  /// open / upcoming / closed / unknown
  String get enrollState {
    final now = DateTime.now();
    final s = parseDt(enrollStart);
    final e = parseDt(enrollEnd);
    if (s != null && now.isBefore(s)) return 'upcoming';
    if (e != null && now.isAfter(e)) return 'closed';
    if (s == null && e == null) return 'unknown';
    return 'open';
  }

  String get enrollStateLabel {
    switch (enrollState) {
      case 'open':
        return '报名中';
      case 'upcoming':
        return '未开始';
      case 'closed':
        return '已截止';
      default:
        return '待确认';
    }
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'intro': intro,
        'organizer': organizer,
        'credit_type': creditType,
        'credit_type_raw': creditTypeRaw,
        'capacity': capacity,
        'enrolled': enrolled,
        'enroll_start': enrollStart,
        'enroll_end': enrollEnd,
        'activity_start': activityStart,
        'activity_end': activityEnd,
        'location': location,
        'hours': hours,
        'grade_scope': gradeScope,
        'college_scope': collegeScope,
        'major_scope': majorScope,
        'org_scope': orgScope,
        'signup_url': signupUrl,
        'logo': logo,
        'status': status,
        'first_seen': firstSeen,
        'last_seen': lastSeen,
        'is_new': isNew,
        'match_score': matchScore,
        'match_reasons': matchReasons,
        'hard_blocked': hardBlocked,
      };

  static Activity fromMap(Map<String, dynamic> m) => Activity(
        id: '${m['id']}',
        title: '${m['title'] ?? ''}',
        intro: '${m['intro'] ?? ''}',
        organizer: '${m['organizer'] ?? ''}',
        creditType: '${m['credit_type'] ?? kCreditUnknown}',
        creditTypeRaw: '${m['credit_type_raw'] ?? ''}',
        capacity: toInt(m['capacity']),
        enrolled: toInt(m['enrolled']),
        enrollStart: '${m['enroll_start'] ?? ''}',
        enrollEnd: '${m['enroll_end'] ?? ''}',
        activityStart: '${m['activity_start'] ?? ''}',
        activityEnd: '${m['activity_end'] ?? ''}',
        location: '${m['location'] ?? ''}',
        hours: toDouble(m['hours']),
        gradeScope: _strList(m['grade_scope']),
        collegeScope: _strList(m['college_scope']),
        majorScope: _strList(m['major_scope']),
        orgScope: _strList(m['org_scope']),
        signupUrl: '${m['signup_url'] ?? ''}',
        logo: '${m['logo'] ?? ''}',
        status: '${m['status'] ?? ''}',
        firstSeen: '${m['first_seen'] ?? ''}',
        lastSeen: '${m['last_seen'] ?? ''}',
        isNew: m['is_new'] == 1 || m['is_new'] == true,
        matchScore: toDouble(m['match_score']),
        matchReasons: _strList(m['match_reasons']),
        hardBlocked: m['hard_blocked'] == true,
      );

  static List<String> _strList(Object? v) {
    if (v is List) return v.map((e) => '$e').where((e) => e.isNotEmpty).toList();
    return const [];
  }
}

// ---------------------------------------------------------------------------
// 画像
// ---------------------------------------------------------------------------

class Profile {
  Profile({
    this.grade = '',
    this.college = '',
    this.major = '',
    this.clazz = '',
    this.creditTypes = const [],
    this.keywordsInclude = const [],
    this.keywordsExclude = const [],
  });

  String grade;
  String college;
  String major;

  /// 班级（对应对面系统里学生所属的「组织」，如「软件工程25-4」）。
  /// 活动的参与组织（organizationList）就是按这个维度限制报名的。
  String clazz;
  List<String> creditTypes;
  List<String> keywordsInclude;
  List<String> keywordsExclude;

  Map<String, dynamic> toMap() => {
        'grade': grade,
        'college': college,
        'major': major,
        'clazz': clazz,
        'credit_types': creditTypes,
        'keywords_include': keywordsInclude,
        'keywords_exclude': keywordsExclude,
      };

  static Profile fromMap(Map<String, dynamic>? m) {
    m ??= {};
    return Profile(
      grade: '${m['grade'] ?? ''}',
      college: '${m['college'] ?? ''}',
      major: '${m['major'] ?? ''}',
      clazz: '${m['clazz'] ?? m['className'] ?? ''}',
      creditTypes: Activity._strList(m['credit_types']),
      keywordsInclude: Activity._strList(m['keywords_include']),
      keywordsExclude: Activity._strList(m['keywords_exclude']),
    );
  }
}

// ---------------------------------------------------------------------------
// 匹配
// ---------------------------------------------------------------------------

const _allScopeTokens = ['', '全校', '不限', '所有', '全体', '全部', '全校学生'];

const double kHoursBaseline = 2.0;
const double kHoursPerUnit = 2.0;
const double kHoursMaxBonus = 12.0;

/// 学时加权：2 学时 0 分，每多 1 学时 +2 分，封顶 +12（8 学时）。
double hoursBonus(double hours) {
  if (hours <= kHoursBaseline) return 0;
  final v = (hours - kHoursBaseline) * kHoursPerUnit;
  return (v > kHoursMaxBonus ? kHoursMaxBonus : v);
}

bool _scopeHit(String userValue, List<String> scopes) {
  final list = scopes.map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
  if (list.isEmpty) return true;
  if (userValue.trim().isEmpty) return false;
  final u = userValue.trim();
  for (final s in list) {
    if (_allScopeTokens.contains(s)) return true;
    if (s == u || s.contains(u) || u.contains(s)) return true;
  }
  return false;
}

/// 班级/组织名归一化：去空白、小写、去掉末尾「_入学年」（制药25-1_2025 → 制药25-1）、
/// 去掉末尾「班」（软件工程25-4班 → 软件25-4 留待边界匹配）。
String _normClass(String s) => s
    .trim()
    .toLowerCase()
    .replaceAll(' ', '')
    .replaceAll(RegExp(r'_\d{4}$'), '')
    .replaceAll(RegExp(r'班$'), '');

// 注意：RegExp 不能用 const 声明
final RegExp _edgeChar = RegExp(r'[0-9a-z-]');

/// 边界感知包含：needle 出现在 hay 中，且前后字符都不是字母/数字/连字符。
/// 班级是精确概念，不能像院系那样宽松 contains：
/// 「制药25-1」不能命中「制药25-11」，「软件工程」不能命中「软件工程25-4」。
bool _boundaryContains(String hay, String needle) {
  if (needle.isEmpty || needle.length > hay.length) return false;
  var idx = hay.indexOf(needle);
  while (idx >= 0) {
    final beforeOk = idx == 0 || !_edgeChar.hasMatch(hay[idx - 1]);
    final after = idx + needle.length;
    final afterOk = after >= hay.length || !_edgeChar.hasMatch(hay[after]);
    if (beforeOk && afterOk) return true;
    idx = hay.indexOf(needle, idx + 1);
  }
  return false;
}

/// 参与组织（班级级限制）命中判断。
/// 返回 true = 用户班级在组织名单内（或活动不限组织）。
bool orgScopeHit(String userClass, List<String> scopes) {
  final list = scopes.map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
  if (list.isEmpty) return true;
  for (final s in list) {
    if (_allScopeTokens.contains(s)) return true; // 名单里出现「全校/不限」= 放开
  }
  if (userClass.trim().isEmpty) return false; // 没填班级 = 无法证明在名单内
  final u = _normClass(userClass);
  if (u.isEmpty) return false;
  for (final s in list) {
    final n = _normClass(s);
    if (n.isEmpty) continue;
    if (u == n) return true;
    if (_boundaryContains(u, n) || _boundaryContains(n, u)) return true;
  }
  return false;
}

String _shortScopes(List<String> scopes) =>
    (scopes.length <= 3 ? scopes : scopes.take(3).toList() + ['…']).join('/');


/// 打分并写入 `matchScore` / `matchReasons` / `hardBlocked`，返回同一个对象便于链式调用。
Activity matchActivity(Activity act, Profile profile) {
  final reasons = <String>[];
  final blocked = <String>[];
  final scopeMissed = <String>[]; // 范围硬性不符（年级/学院/专业/班级）
  var score = 0.0;

  // 年级：不限 或 命中 → +22
  if (act.gradeScope.isEmpty || _scopeHit(profile.grade, act.gradeScope)) {
    if (profile.grade.isNotEmpty) {
      score += 22;
      reasons.add('年级符合');
    }
  } else {
    blocked.add('限年级 ${act.gradeScope.join('/')}');
    scopeMissed.add('年级');
  }

  // 学院：定向 +26 / 全校 +10
  if (act.collegeScope.isEmpty || _scopeHit(profile.college, act.collegeScope)) {
    if (profile.college.isNotEmpty && act.collegeScope.isNotEmpty) {
      score += 26;
      reasons.add('学院定向');
    } else if (act.collegeScope.isEmpty) {
      score += 10;
      reasons.add('面向全校');
    }
  } else {
    blocked.add('限学院 ${act.collegeScope.join('/')}');
    scopeMissed.add('学院');
  }

  // 专业：定向 +20
  if (act.majorScope.isEmpty || _scopeHit(profile.major, act.majorScope)) {
    if (profile.major.isNotEmpty && act.majorScope.isNotEmpty) {
      score += 20;
      reasons.add('专业定向');
    }
  } else {
    blocked.add('限专业 ${act.majorScope.join('/')}');
    scopeMissed.add('专业');
  }

  // 参与组织（班级级硬限制）：详情接口 organizationList，形如「制药25-1_2025」。
  // 非空 = 只允许名单内班级报名，服务端会直接拒绝其他人 —— 这里必须硬拦。
  if (act.orgScope.isEmpty || orgScopeHit(profile.clazz, act.orgScope)) {
    if (profile.clazz.trim().isNotEmpty && act.orgScope.isNotEmpty) {
      score += 18;
      reasons.add('班级定向');
    }
  } else if (profile.clazz.trim().isEmpty) {
    blocked.add('限指定班级（${_shortScopes(act.orgScope)}），未填班级无法判断');
    scopeMissed.add('班级');
  } else {
    blocked.add('限班级 ${_shortScopes(act.orgScope)}');
    scopeMissed.add('班级');
  }

  // 学时类型
  if (profile.creditTypes.isNotEmpty) {
    if (profile.creditTypes.contains(act.creditType)) {
      score += 12;
      reasons.add('命中关注学时：${act.creditType}');
    } else {
      score -= 5;
      reasons.add('学时类型不在关注列表（${act.creditType}）');
    }
  }

  // 关键词
  final haystack = '${act.title} ${act.intro} ${act.organizer}';
  for (final kw in profile.keywordsInclude) {
    if (kw.isNotEmpty && haystack.contains(kw)) {
      score += 4;
      reasons.add('关键词命中：$kw');
      break;
    }
  }
  for (final kw in profile.keywordsExclude) {
    if (kw.isNotEmpty && haystack.contains(kw)) {
      score -= 40;
      blocked.add('命中排除词：$kw');
    }
  }

  // 学时加权
  final bonus = hoursBonus(act.hours);
  if (bonus > 0) {
    score += bonus;
    reasons.add('${_trimNum(act.hours)} 学时（+${_trimNum(bonus)}）');
  }

  if (blocked.isNotEmpty) {
    score = (score < 0 ? score : 0) - 10.0 * blocked.length;
  }

  if (act.seatsLeft == 0) {
    score -= 10;
    reasons.add('名额已满');
  } else if (act.seatsLeft > 0 && act.seatsLeft <= 5) {
    score += 4;
    reasons.add('名额紧张');
  }

  act.matchScore = double.parse(score.toStringAsFixed(1));
  act.matchReasons = [...blocked, ...reasons];
  act.hardBlocked = scopeMissed.isNotEmpty;
  return act;
}

String _trimNum(double v) {
  if (v == v.roundToDouble()) return v.toInt().toString();
  return v.toString();
}

List<Activity> applyMatching(List<Activity> list, Profile profile) {
  for (final a in list) {
    matchActivity(a, profile);
  }
  list.sort((a, b) {
    final byScore = b.matchScore.compareTo(a.matchScore);
    if (byScore != 0) return byScore;
    return (parseDt(a.enrollEnd) ?? DateTime(9999))
        .compareTo(parseDt(b.enrollEnd) ?? DateTime(9999));
  });
  return list;
}

class Stats {
  Stats({required this.total, required this.open, required this.newCount,
      required this.matched, required this.full, this.blocked = 0});

  /// 可报基数：不在报名范围（年级/学院/专业/班级不符）的活动不计入
  final int total;
  final int open;
  final int newCount;
  final int matched;
  final int full;

  /// 被排除在基数之外的条数（不符合报名范围）
  final int blocked;

  /// [minScore] 是推送门槛；不传则退化为「分数 > 0」的旧口径。
  static Stats of(List<Activity> list, {double minScore = 0}) {
    var open = 0, fresh = 0, matched = 0, full = 0, blocked = 0, total = 0;
    for (final a in list) {
      if (a.hardBlocked) {
        blocked++;
        continue; // 报不了名，不进基数，也不参与后面任何统计
      }
      total++;
      if (a.enrollState == 'open') open++;
      if (a.isNew) fresh++;
      if (a.matchScore >= minScore) matched++;
      if (a.isFull) full++;
    }
    return Stats(
      total: total,
      open: open,
      newCount: fresh,
      matched: matched,
      full: full,
      blocked: blocked,
    );
  }
}
