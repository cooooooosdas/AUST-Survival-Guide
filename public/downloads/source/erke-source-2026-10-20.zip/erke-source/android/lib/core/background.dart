/// 后台巡检：用 WorkManager 定期登录 + 抓活动 + 推送精选。
///
/// 说明：Android 的周期任务最短 15 分钟，且系统会按省电策略延后，
/// 所以「间隔」只是期望值，不是精确定时。
library;

import 'package:flutter/widgets.dart';
import 'package:workmanager/workmanager.dart';

import 'api.dart';
import 'credentials.dart';
import 'settings.dart';
import 'store.dart';
import 'sync.dart';

const String kBgTask = 'erke.sync.periodic';
const String kBgUnique = 'erke.sync.unique';

/// 必须顶层 + entry-point 注解，否则 release 包会被 tree-shake 掉。
@pragma('vm:entry-point')
void backgroundCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    WidgetsFlutterBinding.ensureInitialized();
    try {
      final settings = await SettingsStore().load();
      final vault = CredentialVault();
      final api = XueqiApi();
      final creds = await vault.load();
      if (creds.token.isNotEmpty) api.setToken(creds.token);
      final store = SqliteActivityStore();
      final sync = SyncService(api: api, store: store, vault: vault);
      final outcome = await sync.run(
        settings,
        allowNotify: settings.notifyEnabled,
        fromBackground: true,
      );
      return outcome.ok;
    } catch (_) {
      return false;
    }
  });
}

class BackgroundSync {
  static bool _inited = false;

  static Future<void> _init() async {
    if (_inited) return;
    await Workmanager().initialize(backgroundCallbackDispatcher);
    _inited = true;
  }

  /// 按当前设置登记（或改期）后台任务；没登录就不登记。
  static Future<void> apply(AppSettings settings) async {
    try {
      await _init();
      await Workmanager().cancelByUniqueName(kBgUnique);
      if (settings.accountMasked.isEmpty) return;
      var minutes = settings.intervalMinutes;
      if (minutes < 15) minutes = 15;
      await Workmanager().registerPeriodicTask(
        kBgUnique,
        kBgTask,
        frequency: Duration(minutes: minutes),
        initialDelay: const Duration(minutes: 15),
        constraints: Constraints(networkType: NetworkType.connected),
      );
    } catch (_) {
      // 后台能力不可用时不影响前台使用
    }
  }

  static Future<void> ensure() async {
    final settings = await SettingsStore().load();
    await apply(settings);
  }

  static Future<void> cancel() async {
    try {
      await _init();
      await Workmanager().cancelByUniqueName(kBgUnique);
    } catch (_) {}
  }
}
