/// 设置：账号 / 画像 / 检索与提醒 / 关于。
library;

import 'package:flutter/material.dart';

import '../core/background.dart';
import '../core/models.dart';
import '../core/notifier.dart';
import '../core/state.dart';
import 'onboarding_page.dart';
import 'school_picker.dart';
import 'theme.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key, required this.state});

  final AppState state;

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final TextEditingController _grade;
  late final TextEditingController _college;
  late final TextEditingController _major;
  late final TextEditingController _clazz;
  late final TextEditingController _kwIn;
  late final TextEditingController _kwOut;
  late Set<String> _credits;
  late int _limit;
  late double _minScore;
  late int _interval;
  late String _quietStart;
  late String _quietEnd;
  late bool _notify;
  bool _dirty = false;
  bool _saving = false;

  AppState get state => widget.state;

  @override
  void initState() {
    super.initState();
    final s = state.settings;
    _grade = TextEditingController(text: s.profile.grade);
    _college = TextEditingController(text: s.profile.college);
    _major = TextEditingController(text: s.profile.major);
    _clazz = TextEditingController(text: s.profile.clazz);
    _kwIn = TextEditingController(text: s.profile.keywordsInclude.join('，'));
    _kwOut = TextEditingController(text: s.profile.keywordsExclude.join('，'));
    _credits = {...s.profile.creditTypes};
    _limit = s.limit;
    _minScore = s.minScore;
    _interval = s.intervalMinutes;
    _quietStart = s.quietStart;
    _quietEnd = s.quietEnd;
    _notify = s.notifyEnabled;
  }

  @override
  void dispose() {
    for (final c in [_grade, _college, _major, _clazz, _kwIn, _kwOut]) {
      c.dispose();
    }
    super.dispose();
  }

  void _touch() => setState(() => _dirty = true);

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: state,
      builder: (context, _) {
        final s = state.settings;
        final school = s.schoolName.isEmpty ? '未选择' : s.schoolName;
        final account = s.accountMasked.isEmpty ? '未登录' : s.accountMasked;
        return Scaffold(
          appBar: AppBar(
            title: const Text('设置'),
            actions: [
              TextButton(
                onPressed: _dirty && !_saving ? _save : null,
                child: Text(_saving ? '保存中' : '保存'),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 26),
            children: [
              _Section(
                title: '账号',
                children: [
                  _kvTile(
                    '学校',
                    school,
                    onTap: () async {
                      final picked = await showSchoolPicker(context, state.api,
                          currentId: s.schoolId);
                      if (picked == null) return;
                      s.schoolId = picked['id'] ?? '';
                      s.schoolName = picked['name'] ?? '';
                      await state.saveSettings(s);
                      if (mounted) setState(() {});
                    },
                  ),
                  _kvTile('登录状态', account),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    title: const Text('账号与画像向导', style: TextStyle(fontSize: 13.5)),
                    trailing: const Icon(Icons.chevron_right, size: 18),
                    onTap: () async {
                      await Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => OnboardingPage(state: state, editing: true),
                      ));
                      if (mounted) setState(() {});
                    },
                  ),
                  if (account != '未登录')
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      dense: true,
                      title: const Text('退出登录（清除已保存密码）',
                          style: TextStyle(fontSize: 13.5, color: Color(0xFFE5484D))),
                      onTap: _logout,
                    ),
                ],
              ),
              const SizedBox(height: 12),
              _Section(
                title: '画像',
                subtitle: '决定哪些活动会被判定为「适合你」',
                children: [
                  Row(
                    children: [
                      Expanded(child: _field(_grade, '年级', _touch)),
                      const SizedBox(width: 10),
                      Expanded(child: _field(_college, '学院', _touch)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  _field(_major, '专业', _touch),
                  const SizedBox(height: 10),
                  _field(_clazz, '班级（如 软件工程25-4）', _touch),
                  const SizedBox(height: 4),
                  const Text(
                    '班级用于对「参与组织」做限制判断：活动指定了班级时，只有名单内的班级能报名。',
                    style: TextStyle(fontSize: 11, color: Colors.black38, height: 1.5),
                  ),
                  const SizedBox(height: 14),
                  const Text('关注的学时类型',
                      style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 7,
                    runSpacing: 7,
                    children: kCreditTypes.map((c) {
                      final on = _credits.contains(c);
                      final color = kCreditColors[c] ?? kBrand;
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            on ? _credits.remove(c) : _credits.add(c);
                            _dirty = true;
                          });
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                          decoration: BoxDecoration(
                            color: on ? color : Colors.white,
                            borderRadius: BorderRadius.circular(999),
                            border: Border.all(color: on ? color : const Color(0xFFE1E6F0)),
                          ),
                          child: Text(
                            c,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: on ? FontWeight.w700 : FontWeight.w500,
                              color: on ? Colors.white : const Color(0xFF3A4256),
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 14),
                  _field(_kwIn, '想多看的关键词（用逗号分隔）', _touch),
                  const SizedBox(height: 10),
                  _field(_kwOut, '不想看的词（命中就直接不推）', _touch),
                ],
              ),
              const SizedBox(height: 12),
              _Section(
                title: '检索与提醒',
                children: [
                  const Text('每次推几条',
                      style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  SegmentedButton<int>(
                    segments: const [
                      ButtonSegment(value: 1, label: Text('1')),
                      ButtonSegment(value: 2, label: Text('2')),
                      ButtonSegment(value: 3, label: Text('3')),
                      ButtonSegment(value: 5, label: Text('5')),
                    ],
                    selected: {_limit},
                    onSelectionChanged: (v) {
                      setState(() {
                        _limit = v.first;
                        _dirty = true;
                      });
                    },
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      const Text('推送门槛',
                          style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
                      const Spacer(),
                      Text('${_minScore.toStringAsFixed(0)} 分',
                          style: const TextStyle(
                              fontSize: 12.5, fontWeight: FontWeight.w700, color: kBrand)),
                    ],
                  ),
                  Slider(
                    value: _minScore,
                    min: 10,
                    max: 70,
                    divisions: 60,
                    label: _minScore.toStringAsFixed(0),
                    onChanged: (v) {
                      setState(() {
                        _minScore = v;
                        _dirty = true;
                      });
                    },
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Text('后台检查间隔',
                          style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
                      const Spacer(),
                      DropdownButton<int>(
                        value: _interval,
                        underline: const SizedBox.shrink(),
                        items: const [
                          DropdownMenuItem(value: 15, child: Text('15 分钟')),
                          DropdownMenuItem(value: 30, child: Text('30 分钟')),
                          DropdownMenuItem(value: 60, child: Text('1 小时')),
                          DropdownMenuItem(value: 120, child: Text('2 小时')),
                          DropdownMenuItem(value: 360, child: Text('6 小时')),
                        ],
                        onChanged: (v) {
                          if (v == null) return;
                          setState(() {
                            _interval = v;
                            _dirty = true;
                          });
                        },
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      const Text('免打扰',
                          style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
                      const Spacer(),
                      TextButton(
                        onPressed: () => _pickTime(true),
                        child: Text(_quietStart),
                      ),
                      const Text('至', style: TextStyle(fontSize: 12, color: Color(0xFF8A94A6))),
                      TextButton(
                        onPressed: () => _pickTime(false),
                        child: Text(_quietEnd),
                      ),
                    ],
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    value: _notify,
                    title: const Text('开通知提醒', style: TextStyle(fontSize: 13.5)),
                    subtitle: const Text('关掉后只更新数据，不弹通知',
                        style: TextStyle(fontSize: 11.5, color: Color(0xFF8A94A6))),
                    onChanged: (v) async {
                      setState(() {
                        _notify = v;
                        _dirty = true;
                      });
                      if (v) {
                        await Notifier.init();
                        await Notifier.requestPermission();
                      }
                    },
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () async {
                            await Notifier.init();
                            await Notifier.showSimple(
                              '通知是通的',
                              '收到这条说明通知权限没问题，有新的适配活动会这样提醒你。',
                            );
                          },
                          child: const Text('发一条测试通知'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: FilledButton.tonal(
                          onPressed: state.syncing ? null : () => state.refresh(),
                          child: Text(state.syncing ? '同步中…' : '立即同步'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _Section(
                title: '数据与关于',
                children: [
                  _kvTile('本地活动', '${state.all.length} 条'),
                  _kvTile('上次同步', s.lastSyncAt.isEmpty ? '还没同步过' : s.lastSyncAt),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    title: const Text('清空本地活动缓存', style: TextStyle(fontSize: 13.5)),
                    trailing: const Icon(Icons.chevron_right, size: 18),
                    onTap: _clearCache,
                  ),
                  const Divider(height: 20),
                  const Text(
                    '版本 1.0.0 · 数据来自学校在趣拓（9xueqi）上的公开活动信息，仅供个人查看，'
                    '报名请以学校系统为准。本应用不代报名、不修改任何数据。',
                    style: TextStyle(fontSize: 11.5, height: 1.7, color: Color(0xFF8A94A6)),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _field(TextEditingController c, String hint, VoidCallback onEdit) {
    return TextField(
      controller: c,
      onChanged: (_) => onEdit(),
      style: const TextStyle(fontSize: 13.5),
      decoration: InputDecoration(hintText: hint),
    );
  }

  Widget _kvTile(String k, String v, {VoidCallback? onTap}) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      dense: true,
      title: Text(k, style: const TextStyle(fontSize: 13.5)),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 190),
            child: Text(
              v,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12.5, color: Color(0xFF8A94A6)),
            ),
          ),
          if (onTap != null) const Icon(Icons.chevron_right, size: 18),
        ],
      ),
      onTap: onTap,
    );
  }

  Future<void> _pickTime(bool start) async {
    final raw = start ? _quietStart : _quietEnd;
    final parts = raw.split(':');
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(
        hour: int.tryParse(parts.first) ?? 23,
        minute: parts.length > 1 ? (int.tryParse(parts[1]) ?? 0) : 0,
      ),
    );
    if (picked == null) return;
    final text =
        '${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}';
    setState(() {
      if (start) {
        _quietStart = text;
      } else {
        _quietEnd = text;
      }
      _dirty = true;
    });
  }

  List<String> _split(String raw) => raw
      .split(RegExp(r'[,，;；\s]+'))
      .map((e) => e.trim())
      .where((e) => e.isNotEmpty)
      .toList();

  Future<void> _save() async {
    setState(() => _saving = true);
    final next = state.settings.copy();
    next.profile.grade = _grade.text.trim();
    next.profile.college = _college.text.trim();
    next.profile.major = _major.text.trim();
    next.profile.clazz = _clazz.text.trim();
    next.profile.creditTypes = _credits.toList();
    next.profile.keywordsInclude = _split(_kwIn.text);
    next.profile.keywordsExclude = _split(_kwOut.text);
    next.limit = _limit;
    next.minScore = _minScore;
    next.intervalMinutes = _interval;
    next.quietStart = _quietStart;
    next.quietEnd = _quietEnd;
    next.notifyEnabled = _notify;
    await state.saveSettings(next);
    await BackgroundSync.apply(next);
    if (!mounted) return;
    setState(() {
      _saving = false;
      _dirty = false;
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('已保存，画像变了会立刻重算分数')));
  }

  Future<void> _logout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('退出登录'),
        content: const Text('会清掉本机保存的学号和密码，活动数据仍保留。'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('退出')),
        ],
      ),
    );
    if (ok != true) return;
    await state.clearCredentials();
    await BackgroundSync.cancel();
    if (mounted) setState(() {});
  }

  Future<void> _clearCache() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('清空本地活动'),
        content: const Text('下次同步会重新抓一遍。画像和账号不受影响。'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('清空')),
        ],
      ),
    );
    if (ok != true) return;
    await state.store.clearAll();
    await state.reload();
    if (mounted) setState(() {});
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title, required this.children, this.subtitle});

  final String title;
  final String? subtitle;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE6EAF2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
                fontSize: 13.5, fontWeight: FontWeight.w700, color: Color(0xFF111827)),
          ),
          if (subtitle != null) ...[
            const SizedBox(height: 3),
            Text(subtitle!,
                style: const TextStyle(fontSize: 11.5, color: Color(0xFF9AA3B2))),
          ],
          const SizedBox(height: 6),
          ...children,
        ],
      ),
    );
  }
}
