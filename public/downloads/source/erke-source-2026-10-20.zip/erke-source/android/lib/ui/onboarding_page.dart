/// 首次启动向导：选学校 → 登录 → 填画像。三步走完就开始抓活动。
library;

import 'package:flutter/material.dart';

import '../core/models.dart';
import '../core/notifier.dart';
import '../core/state.dart';
import 'school_picker.dart';
import 'theme.dart';

class OnboardingPage extends StatefulWidget {
  const OnboardingPage({super.key, required this.state, this.editing = false});

  final AppState state;
  final bool editing;

  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  int _step = 0;
  bool _busy = false;
  String _msg = '';
  bool _msgOk = false;

  late String _schoolId = widget.state.settings.schoolId;
  late String _schoolName = widget.state.settings.schoolName;

  final TextEditingController _account = TextEditingController();
  final TextEditingController _password = TextEditingController();
  late final TextEditingController _grade =
      TextEditingController(text: widget.state.settings.profile.grade);
  late final TextEditingController _college =
      TextEditingController(text: widget.state.settings.profile.college);
  late final TextEditingController _major =
      TextEditingController(text: widget.state.settings.profile.major);
  late final TextEditingController _clazz =
      TextEditingController(text: widget.state.settings.profile.clazz);
  late final Set<String> _credits = {...widget.state.settings.profile.creditTypes};

  @override
  void dispose() {
    _account.dispose();
    _password.dispose();
    _grade.dispose();
    _college.dispose();
    _major.dispose();
    _clazz.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final steps = widget.editing ? ['账号', '画像'] : ['学校', '登录', '画像'];
    final idx = _step;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.editing ? '账号与画像' : '开始使用'),
        leading: widget.editing ? const BackButton() : null,
        automaticallyImplyLeading: widget.editing,
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 4, 18, 10),
              child: Row(
                children: [
                  for (var i = 0; i < steps.length; i++) ...[
                    _dot(i, i <= idx, steps[i]),
                    if (i < steps.length - 1)
                      Expanded(
                        child: Container(
                          height: 2,
                          margin: const EdgeInsets.symmetric(horizontal: 6),
                          color: i < idx ? kBrand : const Color(0xFFE1E6F0),
                        ),
                      ),
                  ],
                ],
              ),
            ),
            Expanded(child: _body(idx)),
            if (_msg.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 0, 18, 8),
                child: Row(
                  children: [
                    Icon(
                      _msgOk ? Icons.check_circle_outline : Icons.error_outline,
                      size: 15,
                      color: _msgOk ? const Color(0xFF12A594) : const Color(0xFFE5484D),
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        _msg,
                        style: TextStyle(
                          fontSize: 12,
                          color: _msgOk ? const Color(0xFF0F8A7C) : const Color(0xFFE5484D),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 4, 18, 14),
              child: Row(
                children: [
                  if (!widget.editing && idx == 0)
                    TextButton(
                      onPressed: _busy ? null : _skip,
                      child: const Text('先看演示'),
                    ),
                  if (idx > 0)
                    OutlinedButton(
                      onPressed: _busy ? null : () => setState(() => _step -= 1),
                      child: const Text('上一步'),
                    ),
                  const Spacer(),
                  FilledButton(
                    onPressed: _busy ? null : _next,
                    style: FilledButton.styleFrom(
                      minimumSize: const Size(112, 46),
                    ),
                    child: _busy
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                                strokeWidth: 2.2, color: Colors.white),
                          )
                        : Text(_isLast(idx) ? '完成' : '下一步'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  bool _isLast(int idx) => idx == (widget.editing ? 1 : 2);

  Widget _dot(int i, bool done, String label) {
    final active = i == _step;
    return Row(
      children: [
        Container(
          width: 22,
          height: 22,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: done ? kBrand : const Color(0xFFEDF1F7),
            shape: BoxShape.circle,
          ),
          child: done
              ? Text(
                  '${i + 1}',
                  style: const TextStyle(
                      fontSize: 11, fontWeight: FontWeight.w700, color: Colors.white),
                )
              : Text('${i + 1}',
                  style: const TextStyle(fontSize: 11, color: Color(0xFF9AA3B2))),
        ),
        const SizedBox(width: 5),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: active ? FontWeight.w700 : FontWeight.w500,
            color: active ? const Color(0xFF111827) : const Color(0xFF9AA3B2),
          ),
        ),
      ],
    );
  }

  Widget _body(int idx) {
    if (widget.editing) {
      return idx == 0 ? _accountStep() : _profileStep();
    }
    return switch (idx) {
      0 => _schoolStep(),
      1 => _accountStep(),
      _ => _profileStep(),
    };
  }

  Widget _schoolStep() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 6, 18, 18),
      children: [
        const Text(
          '你所在的学校',
          style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 6),
        const Text(
          '不同的学校在趣拓上有各自的编号，选对了才拉得到本校活动。',
          style: TextStyle(fontSize: 12.5, height: 1.7, color: Color(0xFF6B7688)),
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFE6EAF2)),
          ),
          child: Row(
            children: [
              const Icon(Icons.school_outlined, color: kBrand),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _schoolName.isEmpty ? '还没选学校' : _schoolName,
                      style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700),
                    ),
                    if (_schoolId.isNotEmpty)
                      Text(
                        '编号 $_schoolId',
                        style: const TextStyle(fontSize: 11.5, color: Color(0xFF9AA3B2)),
                      ),
                  ],
                ),
              ),
              TextButton(
                onPressed: _busy ? null : _pickSchool,
                child: const Text('选择'),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _accountStep() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 6, 18, 18),
      children: [
        const Text('登录二课系统',
            style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        Text(
          _schoolName.isEmpty ? '账号和趣拓 App 里用的一样。' : '$_schoolName · 账号和趣拓 App 里用的一样。',
          style: const TextStyle(fontSize: 12.5, height: 1.7, color: Color(0xFF6B7688)),
        ),
        const SizedBox(height: 18),
        TextField(
          controller: _account,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(hintText: '学号'),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _password,
          obscureText: true,
          decoration: const InputDecoration(hintText: '密码'),
        ),
        const SizedBox(height: 12),
        const Row(
          children: [
            Icon(Icons.lock_outline, size: 13, color: Color(0xFF9AA3B2)),
            SizedBox(width: 5),
            Expanded(
              child: Text(
                '密码只加密存在本机（Android Keystore），不会上传到任何第三方服务器。',
                style: TextStyle(fontSize: 11.5, height: 1.6, color: Color(0xFF9AA3B2)),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _profileStep() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 6, 18, 18),
      children: [
        const Text('让推荐更准',
            style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        const Text(
          '年级 / 学院 / 专业 / 班级 决定「这条活动是不是只给你们开的」，填得越准越少踩空。',
          style: TextStyle(fontSize: 12.5, height: 1.7, color: Color(0xFF6B7688)),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _grade,
                decoration: const InputDecoration(hintText: '年级，如 2024'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _college,
                decoration: const InputDecoration(hintText: '学院'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _major,
          decoration: const InputDecoration(hintText: '专业'),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _clazz,
          decoration: const InputDecoration(hintText: '班级，如 软件工程25-4'),
        ),
        const SizedBox(height: 4),
        const Text(
          '班级用于对「参与组织」做限制判断：活动指定了班级时，只有名单内的班级能报名。',
          style: TextStyle(fontSize: 11, height: 1.5, color: Color(0xFF8A94A6)),
        ),
        const SizedBox(height: 18),
        const Text(
          '想攒哪几类学时（可多选，选了会优先推）',
          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: kCreditTypes.map((c) {
            final on = _credits.contains(c);
            final color = kCreditColors[c] ?? kBrand;
            return GestureDetector(
              onTap: () => setState(() {
                if (on) {
                  _credits.remove(c);
                } else {
                  _credits.add(c);
                }
              }),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: on ? color : Colors.white,
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: on ? color : const Color(0xFFE1E6F0)),
                ),
                child: Text(
                  c,
                  style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: on ? FontWeight.w700 : FontWeight.w500,
                    color: on ? Colors.white : const Color(0xFF3A4256),
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Future<void> _pickSchool() async {
    final picked = await showSchoolPicker(
      context,
      widget.state.api,
      currentId: _schoolId,
    );
    if (picked == null) return;
    setState(() {
      _schoolId = picked['id'] ?? '';
      _schoolName = picked['name'] ?? '';
      _msg = '';
    });
  }

  Future<void> _next() async {
    final state = widget.state;
    // 编辑模式第 0 步只校验账号
    if (_isLast(_step)) {
      await _finish();
      return;
    }
    if (!widget.editing && _step == 0) {
      if (_schoolId.isEmpty) {
        setState(() {
          _msg = '先选一个学校吧';
          _msgOk = false;
        });
        return;
      }
      setState(() {
        _step = 1;
        _msg = '';
      });
      return;
    }
    // 账号步：允许不填（先看演示），填了就测一次
    if (_account.text.trim().isEmpty || _password.text.isEmpty) {
      setState(() {
        _step = widget.editing ? 1 : 2;
        _msg = '没填账号，稍后可在设置里补';
        _msgOk = false;
      });
      return;
    }
    setState(() {
      _busy = true;
      _msg = '';
    });
    try {
      final text = await state.testLogin(
        schoolId: _schoolId,
        account: _account.text.trim(),
        password: _password.text,
      );
      final ok = text.startsWith('登录成功');
      setState(() {
        _msg = text;
        _msgOk = ok;
      });
      if (ok) {
        // 登录成功顺手把学院/专业提示填上
        if (_college.text.isEmpty && state.settings.profile.college.isNotEmpty) {
          _college.text = state.settings.profile.college;
        }
        if (_major.text.isEmpty && state.settings.profile.major.isNotEmpty) {
          _major.text = state.settings.profile.major;
        }
        // 班级：登录接口通常能带出学生所属组织，自动填上省得手输
        if (_clazz.text.isEmpty && state.settings.profile.clazz.isNotEmpty) {
          _clazz.text = state.settings.profile.clazz;
        }
        setState(() => _step = widget.editing ? 1 : 2);
      }
    } catch (e) {
      setState(() {
        _msg = '登录失败：$e';
        _msgOk = false;
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _skip() async {
    final next = widget.state.settings.copy();
    next.onboarded = true;
    if (_schoolId.isNotEmpty) {
      next.schoolId = _schoolId;
      next.schoolName = _schoolName;
    }
    await widget.state.saveSettings(next);
    if (mounted) Navigator.of(context).maybePop();
  }

  Future<void> _finish() async {
    final state = widget.state;
    setState(() => _busy = true);
    final next = state.settings.copy();
    next.schoolId = _schoolId;
    next.schoolName = _schoolName;
    next.profile.grade = _grade.text.trim();
    next.profile.college = _college.text.trim();
    next.profile.major = _major.text.trim();
    next.profile.clazz = _clazz.text.trim();
    next.profile.creditTypes = _credits.toList();
    next.onboarded = true;
    await state.saveSettings(next);
    await Notifier.init();
    if (next.notifyEnabled) {
      await Notifier.requestPermission();
    }
    if (!mounted) return;
    setState(() => _busy = false);
    Navigator.of(context).maybePop();
    // 已经登录就直接抓一轮
    if (state.settings.accountMasked.isNotEmpty) {
      state.refresh();
    }
  }
}
