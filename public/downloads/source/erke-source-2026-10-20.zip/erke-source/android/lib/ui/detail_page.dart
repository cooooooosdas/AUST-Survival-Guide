/// 活动详情：名额进度、时间线、适用范围、匹配理由。
library;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/curator.dart' as curator;
import '../core/models.dart';
import 'links.dart';
import 'theme.dart';
import 'widgets.dart';

class DetailPage extends StatelessWidget {
  const DetailPage({super.key, required this.activity});

  final Activity activity;

  @override
  Widget build(BuildContext context) {
    final a = activity;
    return Scaffold(
      appBar: AppBar(title: const Text('活动详情')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 18),
        children: [
          Text(
            a.title,
            style: const TextStyle(
              fontSize: 19,
              height: 1.4,
              fontWeight: FontWeight.w800,
              color: Color(0xFF111827),
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              CreditBadge(creditType: a.creditType),
              _tag(a.enrollStateLabel, _stateColor(a)),
              if (a.hours > 0)
                _tag('${a.hours == a.hours.roundToDouble() ? a.hours.toInt() : a.hours} 学时',
                    kBrand),
              if (a.isNew) _tag('NEW', const Color(0xFFE5484D)),
              if (a.isFull) _tag('已满员', const Color(0xFF8A94A6)),
              ...curator.tags(a).map((t) => _tag(t, const Color(0xFFE5484D))),
            ],
          ),
          const SizedBox(height: 14),
          _Block(
            title: '名额',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      a.capacity > 0
                          ? '已报名 ${a.enrolled} / ${a.capacity}'
                          : '不限人数（当前 ${a.enrolled} 人报名）',
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF1F2937),
                      ),
                    ),
                    const Spacer(),
                    if (a.capacity > 0)
                      Text(
                        a.seatsLeft > 0 ? '剩 ${a.seatsLeft} 个' : '已满',
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w700,
                          color: a.seatsLeft > 0
                              ? const Color(0xFF12A594)
                              : const Color(0xFFE5484D),
                        ),
                      ),
                  ],
                ),
                if (a.capacity > 0) ...[
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(99),
                    child: LinearProgressIndicator(
                      value: (a.enrolled / a.capacity).clamp(0.0, 1.0),
                      minHeight: 7,
                      backgroundColor: const Color(0xFFEDF1F7),
                      valueColor: AlwaysStoppedAnimation(
                        a.isFull ? const Color(0xFFE5484D) : kBrand,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 10),
          _Block(
            title: '时间',
            child: Column(
              children: [
                _kv('报名开始', fmtDt(a.enrollStart)),
                _kv('报名截止', fmtDt(a.enrollEnd), highlight: true),
                _kv('活动开始', fmtDt(a.activityStart)),
                _kv('活动结束', fmtDt(a.activityEnd)),
              ],
            ),
          ),
          const SizedBox(height: 10),
          if (a.location.isNotEmpty || a.organizer.isNotEmpty) ...[
            _Block(
              title: '主办与地点',
              child: Column(
                children: [
                  _kv('主办方', a.organizer.isEmpty ? '未标注' : a.organizer),
                  _kv('地点', a.location.isEmpty ? '未标注' : a.location),
                ],
              ),
            ),
            const SizedBox(height: 10),
          ],
          _Block(
            title: '适用范围',
            child: Column(
              children: [
                _kv('年级', a.gradeScope.isEmpty ? '不限' : a.gradeScope.join('、')),
                _kv('学院', a.collegeScope.isEmpty ? '全校' : a.collegeScope.join('、')),
                _kv('专业', a.majorScope.isEmpty ? '不限' : a.majorScope.join('、')),
                _kv('参与组织', a.orgScope.isEmpty ? '不限' : a.orgScope.join('、')),
                if (a.orgScope.isNotEmpty)
                  const Padding(
                    padding: EdgeInsets.only(top: 8),
                    child: Text(
                      '指定班级后才能报名，不在名单内会被学校系统拒绝。',
                      style: TextStyle(fontSize: 11.5, color: Color(0xFF8A94A6), height: 1.5),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          _Block(
            title: '为什么推给你（${a.matchScore.toStringAsFixed(0)} 分）',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (a.matchReasons.isEmpty)
                  const Text('还没有打分，先到设置里补全画像会更准',
                      style: TextStyle(fontSize: 12.5, color: Color(0xFF6B7688)))
                else
                  ...a.matchReasons.map(
                    (r) => Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(
                            RegExp(r'限|排除|已满|不在|低于').hasMatch(r)
                                ? Icons.remove_circle_outline
                                : Icons.check_circle_outline,
                            size: 14,
                            color: RegExp(r'限|排除|已满|不在|低于').hasMatch(r)
                                ? const Color(0xFF9AA3B2)
                                : const Color(0xFF12A594),
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              r,
                              style: const TextStyle(
                                  fontSize: 12.5, height: 1.5, color: Color(0xFF3A4256)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
          if (a.intro.isNotEmpty) ...[
            const SizedBox(height: 10),
            _Block(
              title: '活动简介',
              child: Text(
                a.intro,
                style: const TextStyle(fontSize: 13, height: 1.75, color: Color(0xFF3A4256)),
              ),
            ),
          ],
          if (a.creditTypeRaw.isNotEmpty && a.creditTypeRaw != a.creditType) ...[
            const SizedBox(height: 10),
            Text(
              '原分类：${a.creditTypeRaw}',
              style: const TextStyle(fontSize: 11.5, color: Color(0xFF9AA3B2)),
            ),
          ],
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 10),
          child: Row(
            children: [
              OutlinedButton.icon(
                onPressed: a.signupUrl.isEmpty
                    ? null
                    : () async {
                        await Clipboard.setData(ClipboardData(text: a.signupUrl));
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('报名链接已复制')),
                          );
                        }
                      },
                icon: const Icon(Icons.link, size: 18),
                label: const Text('复制链接'),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton(
                  onPressed: () => openActivity(context, a),
                  child: const Text('去报名'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _stateColor(Activity a) => switch (a.enrollState) {
        'open' => const Color(0xFF12A594),
        'upcoming' => const Color(0xFFF5A524),
        _ => const Color(0xFF8A94A6),
      };

  Widget _tag(String text, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3.5),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.10),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Text(
          text,
          style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: color),
        ),
      );

  Widget _kv(String k, String v, {bool highlight = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 7),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 68,
            child: Text(k, style: const TextStyle(fontSize: 12.5, color: Color(0xFF8A94A6))),
          ),
          Expanded(
            child: Text(
              v.isEmpty ? '未标注' : v,
              style: TextStyle(
                fontSize: 12.5,
                height: 1.45,
                fontWeight: highlight ? FontWeight.w700 : FontWeight.w500,
                color: highlight ? const Color(0xFFE5484D) : const Color(0xFF1F2937),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Block extends StatelessWidget {
  const _Block({required this.title, required this.child});

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE6EAF2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: Color(0xFF111827),
            ),
          ),
          const SizedBox(height: 9),
          child,
        ],
      ),
    );
  }
}
