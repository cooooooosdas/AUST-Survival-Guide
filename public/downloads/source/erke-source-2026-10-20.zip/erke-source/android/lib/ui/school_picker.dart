/// 学校选择：拉一次全校清单，支持搜索；失败时仍可手填学校编号。
library;

import 'package:flutter/material.dart';

import '../core/api.dart';

Future<Map<String, String>?> showSchoolPicker(
  BuildContext context,
  XueqiApi api, {
  String currentId = '',
}) {
  return showModalBottomSheet<Map<String, String>>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (_) => _SchoolSheet(api: api, currentId: currentId),
  );
}

class _SchoolSheet extends StatefulWidget {
  const _SchoolSheet({required this.api, required this.currentId});

  final XueqiApi api;
  final String currentId;

  @override
  State<_SchoolSheet> createState() => _SchoolSheetState();
}

class _SchoolSheetState extends State<_SchoolSheet> {
  final TextEditingController _kw = TextEditingController();
  final TextEditingController _manualId = TextEditingController();
  final TextEditingController _manualName = TextEditingController();
  List<Map<String, String>> _all = const [];
  bool _loading = true;
  String _error = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _kw.dispose();
    _manualId.dispose();
    _manualName.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = '';
    });
    try {
      final rows = await widget.api.fetchSchools();
      if (!mounted) return;
      setState(() {
        _all = rows;
        _loading = false;
        if (rows.isEmpty) _error = '没拉到学校清单，可以手填学校编号';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = '网络开小差了：$e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final kw = _kw.text.trim();
    final shown = kw.isEmpty
        ? _all
        : _all.where((r) => (r['name'] ?? '').contains(kw)).toList();
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.78,
        child: Column(
          children: [
            const SizedBox(height: 10),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: const Color(0xFFE1E6F0),
                borderRadius: BorderRadius.circular(99),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Row(
                children: [
                  const Text(
                    '选择学校',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
                  ),
                  const Spacer(),
                  if (_loading)
                    const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                controller: _kw,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                  hintText: '搜学校名',
                  prefixIcon: Icon(Icons.search, size: 19),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : ListView(
                      children: [
                        if (_error.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                            child: Text(
                              _error,
                              style: const TextStyle(fontSize: 12, color: Color(0xFFE5484D)),
                            ),
                          ),
                        ...shown.map(
                          (r) => ListTile(
                            dense: true,
                            title: Text(
                              r['name'] ?? '',
                              style: const TextStyle(fontSize: 14),
                            ),
                            subtitle: Text(
                              '编号 ${r['id']}',
                              style: const TextStyle(fontSize: 11, color: Color(0xFF9AA3B2)),
                            ),
                            trailing: r['id'] == widget.currentId
                                ? const Icon(Icons.check, size: 18)
                                : null,
                            onTap: () => Navigator.of(context).pop(r),
                          ),
                        ),
                        const Divider(height: 24),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                '找不到？手动填',
                                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                              ),
                              const SizedBox(height: 8),
                              TextField(
                                controller: _manualId,
                                keyboardType: TextInputType.number,
                                decoration: const InputDecoration(hintText: '学校编号'),
                              ),
                              const SizedBox(height: 8),
                              TextField(
                                controller: _manualName,
                                decoration: const InputDecoration(hintText: '学校名称（自己看得懂就行）'),
                              ),
                              const SizedBox(height: 10),
                              SizedBox(
                                width: double.infinity,
                                child: FilledButton(
                                  onPressed: () {
                                    final id = _manualId.text.trim();
                                    if (id.isEmpty) return;
                                    final name = _manualName.text.trim();
                                    Navigator.of(context).pop({
                                      'id': id,
                                      'name': name.isEmpty ? '学校 $id' : name,
                                    });
                                  },
                                  child: const Text('用这个编号'),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
