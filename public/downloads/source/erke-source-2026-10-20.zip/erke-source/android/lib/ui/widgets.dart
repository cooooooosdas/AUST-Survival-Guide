/// 复用组件：统计块、活动卡片、角标。
library;

import 'package:flutter/material.dart';

import '../core/curator.dart' as curator;
import '../core/models.dart';
import 'theme.dart';

class StatTile extends StatelessWidget {
  const StatTile({super.key, required this.label, required this.value, this.color});

  final String label;
  final String value;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFE6EAF2)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              value,
              style: TextStyle(
                fontSize: 22,
                height: 1.1,
                fontWeight: FontWeight.w800,
                color: color ?? const Color(0xFF111827),
              ),
            ),
            const SizedBox(height: 4),
            Text(label,
                style: const TextStyle(fontSize: 11.5, color: Color(0xFF6B7688))),
          ],
        ),
      ),
    );
  }
}

class CreditBadge extends StatelessWidget {
  const CreditBadge({super.key, required this.creditType, this.dense = false});

  final String creditType;
  final bool dense;

  @override
  Widget build(BuildContext context) {
    final color = kCreditColors[creditType] ?? kCreditColors['未分类']!;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: dense ? 7 : 9, vertical: dense ? 3 : 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: color.withValues(alpha: 0.35)),
      ),
      child: Text(
        creditType,
        style: TextStyle(
          fontSize: dense ? 10.5 : 11.5,
          fontWeight: FontWeight.w600,
          color: color,
        ),
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill({required this.text, required this.color, this.filled = false});

  final String text;
  final Color color;
  final bool filled;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: filled ? color : color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 10.5,
          fontWeight: FontWeight.w600,
          color: filled ? Colors.white : color,
        ),
      ),
    );
  }
}

class ActivityCard extends StatelessWidget {
  const ActivityCard({
    super.key,
    required this.activity,
    required this.onTap,
    this.onSignup,
  });

  final Activity activity;
  final VoidCallback onTap;

  /// 为 null 表示这条活动不可报（年级/学院/专业/班级不符），
  /// 此时按钮置灰并说明原因 —— 不给能点但会失败的入口。
  final VoidCallback? onSignup;

  @override
  Widget build(BuildContext context) {
    final a = activity;
    final stateColor = switch (a.enrollState) {
      'open' => const Color(0xFF12A594),
      'upcoming' => const Color(0xFFF5A524),
      'closed' => const Color(0xFF8A94A6),
      _ => const Color(0xFF8A94A6),
    };
    final tags = curator.tags(a);

    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 13, 14, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 角标行
              Wrap(
                spacing: 6,
                runSpacing: 6,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  CreditBadge(creditType: a.creditType),
                  _Pill(text: a.enrollStateLabel, color: stateColor),
                  if (a.hours > 0)
                    _Pill(
                      text: '${a.hours == a.hours.roundToDouble() ? a.hours.toInt() : a.hours} 学时',
                      color: kBrand,
                    ),
                  if (a.isNew) const _Pill(text: 'NEW', color: Color(0xFFE5484D), filled: true),
                  if (a.isFull) const _Pill(text: '已满员', color: Color(0xFF8A94A6), filled: true),
                ],
              ),
              const SizedBox(height: 9),
              Text(
                a.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 15.5,
                  height: 1.35,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF111827),
                ),
              ),
              const SizedBox(height: 5),
              Row(
                children: [
                  const Icon(Icons.account_balance_outlined,
                      size: 13, color: Color(0xFF8A94A6)),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      a.organizer.isEmpty ? '组织方未标注' : a.organizer,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 12, color: Color(0xFF6B7688)),
                    ),
                  ),
                ],
              ),
              if (a.intro.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  a.intro,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12.5,
                    height: 1.5,
                    color: Color(0xFF4B5563),
                  ),
                ),
              ],
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                decoration: BoxDecoration(
                  color: const Color(0xFFF7F9FD),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    _Metric(
                      label: '名额',
                      value: a.capacity > 0 ? '${a.seatsLeft}/${a.capacity}' : '不限',
                      warn: a.capacity > 0 && a.seatsLeft == 0,
                    ),
                    _Metric(label: '截止', value: fmtDt(a.enrollEnd).isEmpty
                        ? '未标注'
                        : fmtDt(a.enrollEnd).substring(5)),
                    _Metric(label: '匹配', value: '${a.matchScore.toStringAsFixed(0)} 分'),
                  ],
                ),
              ),
              if (tags.isNotEmpty) ...[
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: tags
                      .map((t) => _Pill(text: t, color: const Color(0xFFE5484D)))
                      .toList(),
                ),
              ],
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      _reasonText(a),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 11.5, color: Color(0xFF6B7688)),
                    ),
                  ),
                  const SizedBox(width: 8),
                  OutlinedButton(
                    onPressed: onTap,
                    style: OutlinedButton.styleFrom(
                      visualDensity: VisualDensity.compact,
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                    ),
                    child: const Text('详情'),
                  ),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: onSignup,
                    style: FilledButton.styleFrom(
                      visualDensity: VisualDensity.compact,
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      backgroundColor: onSignup == null
                          ? const Color(0xFFB6BFCE)
                          : null,
                    ),
                    child: Text(onSignup == null ? '不可报' : '去报名'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _reasonText(Activity a) {
    if (a.hardBlocked) {
      final miss = a.matchReasons.where((r) => r.startsWith('限')).toList();
      return miss.isEmpty ? '不在报名范围' : miss.first;
    }
    final reasons = a.matchReasons
        .where((r) => !RegExp(r'限|排除|已满|不在|低于').hasMatch(r))
        .take(3)
        .toList();
    return reasons.isEmpty ? '暂无匹配理由' : reasons.join(' · ');
  }
}

class _Metric extends StatelessWidget {
  const _Metric({required this.label, required this.value, this.warn = false});

  final String label;
  final String value;
  final bool warn;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 10.5, color: Color(0xFF8A94A6))),
          const SizedBox(height: 2),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w700,
              color: warn ? const Color(0xFFE5484D) : const Color(0xFF1F2937),
            ),
          ),
        ],
      ),
    );
  }
}
