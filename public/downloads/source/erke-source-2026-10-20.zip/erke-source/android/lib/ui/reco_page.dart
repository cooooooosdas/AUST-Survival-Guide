/// 提醒页：按画像挑出的 1~3 条精选，以及后台提醒的状态说明。
library;

import 'package:flutter/material.dart';

import '../core/curator.dart' as curator;
import '../core/models.dart';
import '../core/state.dart';
import 'detail_page.dart';
import 'links.dart';
import 'theme.dart';
import 'widgets.dart';

class RecoPage extends StatelessWidget {
  const RecoPage({super.key, required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: state,
      builder: (context, _) {
        // 流程顺序固定为：可报列表 → 逐个算匹配分 → 按分降序 → 取前 N 条推送。
        // 推荐列表、首页列表、统计基数都用同一份 eligible，口径不会再各说各话。
        final eligible = state.eligible;
        final picks = curator.pick(
          eligible,
          limit: state.settings.limit,
          minScore: state.settings.minScore,
        );
        return SafeArea(
          bottom: false,
          child: RefreshIndicator(
            onRefresh: () => state.refresh(),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(14, 8, 14, 24),
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                const Text(
                  '精选提醒',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF111827),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '可报 ${eligible.length} 条 → 逐个算匹配分 → 从高到低取前'
                  ' ${state.settings.limit} 条（门槛 ${state.settings.minScore.toStringAsFixed(0)} 分）；'
                  '已截止 / 已满 / 不在报名范围的不推。',
                  style: const TextStyle(fontSize: 12, height: 1.6, color: Color(0xFF6B7688)),
                ),
                if (state.stats.blocked > 0) ...[
                  const SizedBox(height: 4),
                  Text(
                    '另有 ${state.stats.blocked} 条因年级/学院/专业/班级不符被排除，无法报名。',
                    style: const TextStyle(fontSize: 11.5, height: 1.6, color: Color(0xFF8A94A6)),
                  ),
                ],
                const SizedBox(height: 12),
                if (picks.isEmpty)
                  _EmptyCard(state: state)
                else
                  ...picks.map((a) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: _PickCard(activity: a, state: state),
                      )),
                const SizedBox(height: 6),
                _Notice(state: state),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _PickCard extends StatelessWidget {
  const _PickCard({required this.activity, required this.state});

  final Activity activity;
  final AppState state;

  @override
  Widget build(BuildContext context) {
    final a = activity;
    final urgent = curator.isUrgent(a);
    final mins = curator.minutesLeft(a, DateTime.now());
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: urgent ? const Color(0xFFFBC5C7) : const Color(0xFFE6EAF2)),
      ),
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CreditBadge(creditType: a.creditType, dense: true),
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2.5),
                decoration: BoxDecoration(
                  color: kBrand.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  '${a.matchScore.toStringAsFixed(0)} 分',
                  style: const TextStyle(
                      fontSize: 10.5, fontWeight: FontWeight.w700, color: kBrand),
                ),
              ),
              const Spacer(),
              if (mins != null && mins > 0)
                Text(
                  mins < 60 ? '剩 ${mins.toStringAsFixed(0)} 分钟' : '剩 ${(mins / 60).toStringAsFixed(0)} 小时',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: urgent ? const Color(0xFFE5484D) : const Color(0xFF8A94A6),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 8),
          GestureDetector(
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => DetailPage(activity: a)),
            ),
            child: Text(
              a.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 15.5,
                height: 1.35,
                fontWeight: FontWeight.w700,
                color: Color(0xFF111827),
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            curator.explain(a),
            style: const TextStyle(fontSize: 12.5, height: 1.6, color: Color(0xFF4B5563)),
          ),
          const SizedBox(height: 4),
          Text(
            [
              if (a.capacity > 0) '名额 ${a.seatsLeft}/${a.capacity}',
              if (a.hours > 0)
                '${a.hours == a.hours.roundToDouble() ? a.hours.toInt() : a.hours} 学时',
              if (fmtDt(a.enrollEnd).isNotEmpty) '截止 ${fmtDt(a.enrollEnd)}',
            ].join(' · '),
            style: const TextStyle(fontSize: 11.5, color: Color(0xFF8A94A6)),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => DetailPage(activity: a)),
                  ),
                  child: const Text('看详情'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton(
                  onPressed: () => openActivity(context, a),
                  child: const Text('去报名'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _EmptyCard extends StatelessWidget {
  const _EmptyCard({required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    final noLogin = state.settings.accountMasked.isEmpty;
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE6EAF2)),
      ),
      child: Column(
        children: [
          const Icon(Icons.notifications_none_rounded, size: 40, color: Color(0xFFB6BFCE)),
          const SizedBox(height: 12),
          Text(
            noLogin ? '还没登录，暂时没有可推的活动' : '这一轮没有够格的活动',
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF3A4256)),
          ),
          const SizedBox(height: 6),
          Text(
            noLogin
                ? '到「设置 → 账号」填学校和学号密码，登录后自动抓真实活动。'
                : '可以到设置里把「推送门槛」调低一点，或者放宽画像的学时偏好。',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 12, height: 1.65, color: Color(0xFF6B7688)),
          ),
          const SizedBox(height: 14),
          FilledButton.tonal(
            onPressed: state.syncing ? null : () => state.refresh(),
            child: Text(state.syncing ? '同步中…' : '马上同步一次'),
          ),
        ],
      ),
    );
  }
}

class _Notice extends StatelessWidget {
  const _Notice({required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    final s = state.settings;
    final rows = <String>[
      '后台轮询：${s.intervalMinutes} 分钟一次（系统最短 15 分钟，实际由省电策略决定）',
      '免打扰：${s.quietStart} ~ ${s.quietEnd}（这段时间只更新数据，不响铃）',
      '通知：${s.notifyEnabled ? '已开启' : '已关闭'}',
    ];
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: const Color(0xFFF0F4FF),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '提醒怎么工作',
            style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: Color(0xFF2F4C8F)),
          ),
          const SizedBox(height: 6),
          ...rows.map((r) => Padding(
                padding: const EdgeInsets.only(bottom: 3),
                child: Text(
                  '· $r',
                  style: const TextStyle(fontSize: 11.5, height: 1.6, color: Color(0xFF4A5A80)),
                ),
              )),
          const SizedBox(height: 4),
          const Text(
            '同一个活动只推一次；推送过的会记在本地台账里，不会重复打扰。',
            style: TextStyle(fontSize: 11, height: 1.6, color: Color(0xFF6A7BA6)),
          ),
        ],
      ),
    );
  }
}
