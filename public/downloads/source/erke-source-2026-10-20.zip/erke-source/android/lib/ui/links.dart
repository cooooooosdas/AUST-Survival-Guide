/// 外部链接：报名按钮 / 通知点击都走这里。
library;

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/api.dart';
import '../core/models.dart';

String resolveUrl(String raw) {
  final text = raw.trim();
  if (text.isEmpty) return '';
  if (text.startsWith('http://') || text.startsWith('https://')) return text;
  if (text.startsWith('//')) return 'https:$text';
  if (text.startsWith('/')) return '$kDefaultWebOrigin$text';
  return text;
}

Future<bool> openUrl(BuildContext context, String raw, {String emptyHint = ''}) async {
  final url = resolveUrl(raw);
  if (url.isEmpty) {
    if (emptyHint.isNotEmpty && context.mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(emptyHint)));
    }
    return false;
  }
  final uri = Uri.tryParse(url);
  var ok = false;
  if (uri != null) {
    try {
      ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      ok = false;
    }
  }
  if (!ok && context.mounted) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('打不开链接，可以复制到浏览器：$url')),
    );
  }
  return ok;
}

Future<void> openActivity(BuildContext context, Activity a) => openUrl(
      context,
      a.signupUrl,
      emptyHint: '这个活动没给外部报名链接，请到趣拓 App 或学校二课系统里报名',
    );
