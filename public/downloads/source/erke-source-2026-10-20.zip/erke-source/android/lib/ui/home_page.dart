/// 首页：统计 + 筛选 + 活动流。
library;

import 'package:flutter/material.dart';

import '../core/models.dart';
import '../core/state.dart';
import 'detail_page.dart';
import 'links.dart';
import 'theme.dart';
import 'widgets.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.state});

  final AppState state;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _search = TextEditingController();

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.state;
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) {
        final stats = s.stats;
        final list = s.visible;
        return SafeArea(
          bottom: false,
          child: Column(
            children: [
              _Header(state: s, stats: stats),
              _FilterBar(
                state: s,
                controller: _search,
                onKeyword: s.setKeyword,
              ),
              Expanded(
                child: RefreshIndicator(
                  onRefresh: () => s.refresh(),
                  child: list.isEmpty
                      ? _Empty(state: s)
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(14, 4, 14, 24),
                          physics: const AlwaysScrollableScrollPhysics(),
                          itemCount: list.length + 1,
                          separatorBuilder: (_, __) => const SizedBox(height: 10),
                          itemBuilder: (context, i) {
                            if (i == list.length) return _Footer(state: s);
                            final a = list[i];
                            return ActivityCard(
                              activity: a,
                              onTap: () => _openDetail(a),
                              // 不可报的活动不给报名入口：点了也会被学校系统拒绝。
                              // 报名入口出现在「匹配分算完并排序」之后，顺序上不能再靠前。
                              onSignup: a.hardBlocked ? null : () => openActivity(context, a),
                            );
                          },
                        ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _openDetail(Activity a) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => DetailPage(activity: a)),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.state, required this.stats});

  final AppState state;
  final Stats stats;

  @override
  Widget build(BuildContext context) {
    final school = state.settings.schoolName.isEmpty ? '未选择学校' : state.settings.schoolName;
    final syncAt = state.settings.lastSyncAt.isEmpty ? '还没同步过' : '上次同步 ${state.settings.lastSyncAt}';
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(16, 6, 8, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      '第二课堂',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF111827),
                        height: 1.2,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      '$school · $syncAt',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 12, color: Color(0xFF6B7688)),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: '立即同步',
                onPressed: state.syncing ? null : () => state.refresh(),
                icon: state.syncing
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2.2),
                      )
                    : const Icon(Icons.refresh_rounded),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              StatTile(label: '活动总数', value: '${stats.total}'),
              const SizedBox(width: 8),
              StatTile(
                label: '报名中',
                value: '${stats.open}',
                color: const Color(0xFF12A594),
              ),
              const SizedBox(width: 8),
              StatTile(
                label: '新增',
                value: '${stats.newCount}',
                color: const Color(0xFFE5484D),
              ),
              const SizedBox(width: 8),
              StatTile(label: '匹配', value: '${stats.matched}', color: kBrand),
            ],
          ),
          if (stats.blocked > 0) ...[
            const SizedBox(height: 6),
            Row(
              children: [
                const Icon(Icons.block_rounded, size: 12, color: Color(0xFF8A94A6)),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    '活动总数只算你能报的；另有 ${stats.blocked} 条因年级/学院/专业/班级不符被排除',
                    style: const TextStyle(
                        fontSize: 11, height: 1.4, color: Color(0xFF8A94A6)),
                  ),
                ),
              ],
            ),
          ],
          if (state.errorText.isNotEmpty) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.error_outline, size: 14, color: Color(0xFFE5484D)),
                const SizedBox(width: 5),
                Expanded(
                  child: Text(
                    state.errorText,
                    style: const TextStyle(fontSize: 11.5, color: Color(0xFFE5484D)),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class _FilterBar extends StatelessWidget {
  const _FilterBar({
    required this.state,
    required this.controller,
    required this.onKeyword,
  });

  final AppState state;
  final TextEditingController controller;
  final ValueChanged<String> onKeyword;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
      child: Column(
        children: [
          SizedBox(
            height: 40,
            child: TextField(
              controller: controller,
              onChanged: onKeyword,
              textInputAction: TextInputAction.search,
              style: const TextStyle(fontSize: 14),
              decoration: InputDecoration(
                hintText: '搜活动名 / 主办方 / 关键词',
                hintStyle: const TextStyle(fontSize: 13.5, color: Color(0xFF9AA3B2)),
                prefixIcon: const Icon(Icons.search, size: 19),
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
                suffixIcon: controller.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.close, size: 17),
                        onPressed: () {
                          controller.clear();
                          onKeyword('');
                        },
                      ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 34,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                _Chip(
                  label: '只看新增',
                  active: state.onlyNew,
                  onTap: () => state.toggleOnlyNew(!state.onlyNew),
                ),
                const SizedBox(width: 6),
                _Chip(
                  label: '只看匹配',
                  active: state.onlyMatchable,
                  onTap: () => state.toggleOnlyMatchable(!state.onlyMatchable),
                ),
                const SizedBox(width: 6),
                _Chip(
                  label: '可报名',
                  active: state.filterState == 'open',
                  onTap: () => state.setState_('open'),
                ),
                const SizedBox(width: 6),
                _Chip(
                  label: '未开始',
                  active: state.filterState == 'upcoming',
                  onTap: () => state.setState_('upcoming'),
                ),
                const SizedBox(width: 6),
                _Chip(
                  label: '显示不可报',
                  active: state.showBlocked,
                  onTap: () => state.toggleShowBlocked(!state.showBlocked),
                ),
                const SizedBox(width: 6),
                for (final c in kCreditTypes) ...[
                  _Chip(
                    label: c,
                    color: kCreditColors[c],
                    active: state.filterCredit == c,
                    onTap: () => state.setCredit(c),
                  ),
                  const SizedBox(width: 6),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  const _Chip({
    required this.label,
    required this.active,
    required this.onTap,
    this.color,
  });

  final String label;
  final bool active;
  final VoidCallback onTap;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final c = color ?? kBrand;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        padding: const EdgeInsets.symmetric(horizontal: 12),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: active ? c : Colors.white,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: active ? c : const Color(0xFFE1E6F0)),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12.5,
            fontWeight: active ? FontWeight.w700 : FontWeight.w500,
            color: active ? Colors.white : const Color(0xFF3A4256),
          ),
        ),
      ),
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty({required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    final firstRun = state.settings.lastSyncAt.isEmpty;
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        SizedBox(height: MediaQuery.of(context).size.height * 0.18),
        Center(
          child: Column(
            children: [
              if (state.syncing)
                const SizedBox(
                  width: 28,
                  height: 28,
                  child: CircularProgressIndicator(strokeWidth: 2.6),
                )
              else
                const Icon(Icons.inbox_outlined, size: 46, color: Color(0xFFB6BFCE)),
              const SizedBox(height: 14),
              Text(
                state.syncing
                    ? '正在首次检索活动…'
                    : (firstRun ? '还没有数据' : '没有符合筛选条件的活动'),
                style: const TextStyle(fontSize: 14, color: Color(0xFF6B7688)),
              ),
              const SizedBox(height: 6),
              Text(
                state.syncing ? '首次会抓取几页活动并补全详情，约 20~40 秒' : '下拉刷新，或清掉筛选条件再试',
                style: const TextStyle(fontSize: 12, color: Color(0xFF9AA3B2)),
              ),
              const SizedBox(height: 16),
              FilledButton.tonal(
                onPressed: state.syncing ? null : () => state.refresh(),
                child: const Text('立即同步'),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _Footer extends StatelessWidget {
  const _Footer({required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    final text = state.statusText.isEmpty ? '共 ${state.visible.length} 条' : state.statusText;
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 8, 4, 12),
      child: Center(
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 11.5, color: Color(0xFF9AA3B2)),
        ),
      ),
    );
  }
}
