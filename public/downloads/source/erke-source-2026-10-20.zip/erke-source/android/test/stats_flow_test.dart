/// 统计口径与排序的回归测试。
///
/// 之前的问题：
///   1. 活动总数 / 报名中 / 匹配 三个数恒等 —— 因为「总数」把报不了名的活动也算进去了，
///      而「匹配」的判据是 score > 0（几乎人人命中）。
///   2. 首页列表没按匹配分排序，报名入口出现在算分之前。
///   3. 库里存的是旧画像下的分数，改完画像不重算 → 「匹配 9 个，刷新后变 46 个」。
library;

import 'package:erke_app/core/curator.dart';
import 'package:erke_app/core/models.dart';
import 'package:flutter_test/flutter_test.dart';

Profile me() => Profile(
      grade: '2025',
      college: '计算机科学与工程学院',
      major: '软件工程',
      clazz: '软件工程25-4',
      creditTypes: const ['实践能力培养'],
    );

/// 造一条活动；[block] 用来模拟「不在报名范围」。
Activity act(String id, {double hours = 3, List<String>? orgs}) => Activity(
      id: id,
      title: '活动 $id',
      hours: hours,
      creditType: '实践能力培养',
      intro: '简介',
      orgScope: orgs ?? const [],
      enrollEnd: '2099-01-01 10:00',
      enrollStart: '2026-01-01 10:00',
    );

List<Activity> scored(List<Activity> src) => applyMatching(src, me());

void main() {
  group('统计基数：只算可报的', () {
    test('全部符合 → 总数 = 全部条数', () {
      final list = scored([act('a'), act('b'), act('c')]);
      final s = Stats.of(list, minScore: 0);
      expect(s.total, 3);
      expect(s.blocked, 0);
    });

    test('全部不符 → 总数 = 0，全部计入被排除', () {
      final list = scored([
        act('a')..orgScope = ['制药25-1_2025'],
        act('b')..orgScope = ['化工25-3_2025'],
      ]);
      final s = Stats.of(list, minScore: 0);
      expect(s.total, 0);
      expect(s.blocked, 2);
      expect(s.open, 0, reason: '报不了名的不该计进「报名中」');
      expect(s.matched, 0);
    });

    test('部分符合 → 总数只算可报的，三个数不再恒等', () {
      final list = scored([
        act('a', hours: 8),                               // 可报，高分
        act('b', hours: 2)..creditType = '思想政治引领',    // 可报，但低于门槛
        act('c')..orgScope = ['制药25-1_2025'],           // 不可报
        act('d')..orgScope = ['化工25-3_2025'],           // 不可报
      ]);
      final s = Stats.of(list, minScore: 0);
      expect(s.total, 2, reason: '总数只算可报的');
      expect(s.blocked, 2);
      expect(s.matched, lessThanOrEqualTo(s.total));
      // 门槛调高后，「匹配」就该明显少于「总数」（不再恒等）
      expect(Stats.of(list, minScore: 35).matched, 1);
      expect(Stats.of(list, minScore: 35).matched, lessThan(s.total));
    });

    test('报名中 ⊆ 总数，匹配 ⊆ 总数（用门槛卡出差异）', () {
      final low = act('b', hours: 2)..creditType = '思想政治引领'; // 不在关注列表 → 扣分
      final closed = act('c')..enrollEnd = '2020-01-01 10:00';    // 已截止
      final list = scored([
        act('a', hours: 8),                              // 高分，可报
        low,                                             // 可报但低于门槛
        closed,                                          // 可报但已截止
        act('d')..orgScope = ['制药25-1_2025'],           // 不可报
      ]);
      final s = Stats.of(list, minScore: 35);
      expect(s.total, 3, reason: '排除 1 条不可报');
      expect(s.blocked, 1);
      // 匹配看的是分数够不够门槛，和「是否还在报名中」是两回事：
      // a(56) / c(46) 够门槛，b(27) 不够
      expect(s.matched, 2);
      expect(s.matched, lessThan(s.total));
      expect(s.open, 2, reason: '已截止那条不算报名中');
      expect(s.open, lessThan(s.total));
    });
  });

  group('排序：匹配分由高到低', () {
    test('可报列表按分降序', () {
      final list = scored([act('low', hours: 2), act('high', hours: 8)]);
      final sorted = [...list]..sort(compareByMatch);
      expect(sorted.first.id, 'high');
      expect(sorted.first.matchScore, greaterThan(sorted.last.matchScore));
    });

    test('不可报的排在后面（分数为负）', () {
      final list = scored([
        act('ok', hours: 8),
        act('no')..orgScope = ['制药25-1_2025'],
      ]);
      final sorted = [...list]..sort(compareByMatch);
      expect(sorted.first.id, 'ok');
      expect(isEligible(sorted.first), isTrue);
      expect(isEligible(sorted.last), isFalse);
    });

    test('同分时报名截止早的在前（学时也会影响分数，所以这里用同学时）', () {
      final late = act('late', hours: 3)..enrollEnd = '2099-03-01 10:00';
      final early = act('early', hours: 3)..enrollEnd = '2099-01-02 10:00';
      final list = applyMatching([late, early], me());
      expect(list.first.matchScore, list.last.matchScore); // 分数确实相同
      final sorted = [...list]..sort(compareByMatch);
      expect(sorted.first.id, 'early', reason: '同分时应优先截止早的');
    });
  });

  group('推送顺序 = 排序后的顺序', () {
    test('精选取的是排序后最靠前的几条', () {
      final list = scored([
        act('s1', hours: 2),
        act('s2', hours: 8),
        act('s3', hours: 6),
        act('blocked')..orgScope = ['制药25-1_2025'],
      ]);
      final eligible = list.where(isEligible).toList()..sort(compareByMatch);
      final picks = pick(eligible, limit: 2, minScore: 0);
      expect(picks.map((e) => e.id).toList(), ['s2', 's3']);
      expect(picks.every(isEligible), isTrue);
    });

    test('一条都不符合 → 精选为空', () {
      final list = scored([
        act('a')..orgScope = ['制药25-1_2025'],
        act('b')..orgScope = ['化工25-3_2025'],
      ]);
      final eligible = list.where(isEligible).toList()..sort(compareByMatch);
      expect(pick(eligible, limit: 3, minScore: 0), isEmpty);
      expect(Stats.of(list, minScore: 0).total, 0);
    });

    test('全部符合 → 按分取前 N 条', () {
      final list = scored([
        act('a', hours: 2),
        act('b', hours: 8),
        act('c', hours: 5),
      ]);
      final eligible = list.where(isEligible).toList()..sort(compareByMatch);
      expect(pick(eligible, limit: 2, minScore: 0).map((e) => e.id).toList(),
          ['b', 'c']);
      expect(Stats.of(list, minScore: 0).total, 3);
    });
  });

  group('重算分数：改完画像不残留旧分', () {
    test('换了班级后重算，同一批活动分数会变', () {
      final list = [act('a')..orgScope = ['软件工程25-4_2025']];
      final before = applyMatching(list, Profile(clazz: '制药25-1'));
      expect(before.first.hardBlocked, isTrue);

      final after = applyMatching([act('a')..orgScope = ['软件工程25-4_2025']],
          Profile(clazz: '软件工程25-4'));
      expect(after.first.hardBlocked, isFalse);

      // 这正是「匹配 9 个 → 刷新后 46 个」的根因：必须用当前画像重算再统计
      expect(Stats.of(before, minScore: 0).total, 0);
      expect(Stats.of(after, minScore: 0).total, 1);
    });
  });
}
