/// 接口层的行为测试：不联网，用假 Client 验证「详情补全是并发的、且有上限」。
///
/// 这段逻辑在 v1.0.1 从串行改成了 4 路并发，牵扯共享游标和计数，
/// 值得用测试钉住：数量对得上、不重复、不多路打爆服务器。
library;

import 'dart:convert';

import 'package:erke_app/core/api.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

/// 造一个假接口：list 返回 [count] 条没有简介的活动，detail 返回简介。
http.Client fakeClient({
  required int count,
  void Function()? onDetailStart,
  void Function()? onDetailEnd,
}) {
  return MockClient((req) async {
    final path = req.url.path;
    if (path.endsWith('activity/list')) {
      final rows = List.generate(
        count,
        (i) => {'id': 'a$i', 'name': '活动 $i'},
      );
      return http.Response.bytes(
        utf8.encode(jsonEncode({
          'code': 0,
          'data': {'list': rows, 'total': count},
        })),
        200,
        headers: {'content-type': 'application/json; charset=utf-8'},
      );
    }
    if (path.endsWith('activity/detail/non-member')) {
      onDetailStart?.call();
      // 停一下，让并发真的重叠起来
      await Future<void>.delayed(const Duration(milliseconds: 20));
      onDetailEnd?.call();
      final id = jsonDecode(req.url.queryParameters['params'] ?? '{}')['id'];
      return http.Response.bytes(
        utf8.encode(jsonEncode({
          'code': 0,
          'data': {
            'introduce': '简介 for $id',
            'classifyName': '实践能力培养',
            // 参与组织：班级级限制，空数组 = 不限班级
            'organizationList': [
              {'name': '制药25-1_2025'}
            ],
          },
        })),
        200,
        headers: {'content-type': 'application/json; charset=utf-8'},
      );
    }
    return http.Response('{"code":404,"msg":"no such path"}', 404);
  });
}

void main() {
  test('详情补全走并发，且并发数不超过 4', () async {
    var inFlight = 0;
    var peak = 0;
    final client = fakeClient(
      count: 12,
      onDetailStart: () {
        inFlight++;
        if (inFlight > peak) peak = inFlight;
      },
      onDetailEnd: () => inFlight--,
    );
    final api = XueqiApi(
      client: client,
      minInterval: Duration.zero, // 测试里不要限流等待
    )..setToken('fake-token');

    final result = await api.fetchActivities(pages: 1, pageSize: 20, enrichLimit: 20);

    expect(result.ok, isTrue, reason: result.message);
    expect(result.activities.length, 12);
    expect(result.enriched, 12);
    expect(peak, greaterThan(1), reason: '应该是并发的，不能退化成串行');
    expect(peak, lessThanOrEqualTo(4), reason: '并发上限是 4，别把学校服务器打疼');
    for (final a in result.activities) {
      expect(a.intro, isNotEmpty, reason: '${a.id} 的详情没补上');
      expect(a.creditType, '实践能力培养');
      // 参与组织（班级级限制）必须落到模型上，否则班级限制判断无从谈起
      expect(a.orgScope, ['制药25-1_2025']);
    }
  });

  test('enrichLimit 生效：只补前 N 条', () async {
    var detailCalls = 0;
    final client = fakeClient(
      count: 10,
      onDetailStart: () => detailCalls++,
    );
    final api = XueqiApi(client: client, minInterval: Duration.zero)
      ..setToken('fake-token');

    final result = await api.fetchActivities(pages: 1, pageSize: 20, enrichLimit: 3);

    expect(result.ok, isTrue);
    expect(detailCalls, 3, reason: '请求数要等于上限，不能多打');
    expect(result.enriched, 3);
    // 后面 7 条没有被补全，简介仍为空
    expect(result.activities.where((a) => a.intro.isEmpty).length, 7);
  });

  test('库里已有详情的不再重复请求', () async {
    var detailCalls = 0;
    final client = fakeClient(count: 6, onDetailStart: () => detailCalls++);
    final api = XueqiApi(client: client, minInterval: Duration.zero)
      ..setToken('fake-token');

    // 假设 a0~a3 库里已经有详情
    final result = await api.fetchActivities(
      pages: 1,
      pageSize: 20,
      enrichLimit: 20,
      knownIds: {'a0', 'a1', 'a2', 'a3'},
    );

    expect(detailCalls, 2, reason: '只应该补 a4 / a5 两条');
    expect(result.enriched, 2);
    expect(result.message, contains('已有详情'));
  });

  test('详情接口失败不影响整体结果', () async {
    // 一半详情 500，另一半正常
    var n = 0;
    final client = MockClient((req) async {
      if (req.url.path.endsWith('activity/list')) {
        final rows = List.generate(8, (i) => {'id': 'b$i', 'name': '活动 $i'});
        return http.Response.bytes(
          utf8.encode(jsonEncode({
            'code': 0,
            'data': {'list': rows, 'total': 8},
          })),
          200,
        );
      }
      n++;
      if (n.isOdd) return http.Response('boom', 500);
      return http.Response.bytes(
        utf8.encode(jsonEncode({
          'code': 0,
          'data': {'introduce': 'ok'},
        })),
        200,
      );
    });
    final api = XueqiApi(client: client, minInterval: Duration.zero)
      ..setToken('fake-token');

    final result = await api.fetchActivities(pages: 1, pageSize: 20, enrichLimit: 8);

    expect(result.ok, isTrue, reason: '个别详情失败不该让整轮抓取失败');
    expect(result.activities.length, 8);
    expect(result.enriched, 4, reason: '8 条里有一半详情 500，应该只补全 4 条');
    expect(result.message, contains('详情失败'));
  });

  test('未登录不发请求', () async {
    var hits = 0;
    final client = MockClient((req) async {
      hits++;
      return http.Response('{}', 200);
    });
    final api = XueqiApi(client: client, minInterval: Duration.zero);
    final result = await api.fetchActivities();
    expect(result.ok, isFalse);
    expect(hits, 0);
  });
}
