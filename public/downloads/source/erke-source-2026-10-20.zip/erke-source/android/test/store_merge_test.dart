/// 入库合并的回归测试。
///
/// 背景：列表接口只给 10 个字段，简介/名额/报名时间只在详情里。
/// 而 upsert 是整条 payload 覆盖 —— 如果不同旧记录合并，
/// 每轮同步都会把上一轮补全的详情抹掉，表现是「只有最新 20 个活动能被推荐」。
library;

import 'package:erke_app/core/models.dart';
import 'package:erke_app/core/store.dart';
import 'package:flutter_test/flutter_test.dart';

Activity detailed() => Activity(
      id: 'a1',
      title: '志愿活动',
      intro: '去社区做志愿服务',
      creditType: '社会责任担当',
      creditTypeRaw: '社会责任担当',
      capacity: 50,
      enrolled: 12,
      enrollStart: '2026-10-01 08:00',
      enrollEnd: '2026-10-25 23:59',
      hours: 3,
      location: '一号楼',
      organizer: '校团委',
      collegeScope: const ['计算机学院'],
    );

Activity listOnly() => Activity(id: 'a1', title: '志愿活动');

void main() {
  test('mergeDetailsFrom：新对象缺详情时从旧记录补齐', () {
    final fresh = listOnly()..mergeDetailsFrom(detailed());

    expect(fresh.intro, '去社区做志愿服务');
    expect(fresh.capacity, 50);
    expect(fresh.enrolled, 12);
    expect(fresh.enrollEnd, '2026-10-25 23:59');
    expect(fresh.hours, 3);
    expect(fresh.location, '一号楼');
    expect(fresh.creditType, '社会责任担当');
    expect(fresh.collegeScope, ['计算机学院']);
  });

  test('mergeDetailsFrom：新对象自己有详情时不覆盖', () {
    final fresh = Activity(
      id: 'a1',
      title: '志愿活动（改）',
      intro: '新的简介',
      capacity: 30,
    )..mergeDetailsFrom(detailed());

    expect(fresh.intro, '新的简介');
    expect(fresh.capacity, 30, reason: '新数据有详情，应该以新的为准');
    expect(fresh.location, '一号楼', reason: '新数据没给地点，仍可从旧记录补');
  });

  test('MemoryActivityStore：第二轮只带列表字段，详情不能被抹掉', () async {
    final store = MemoryActivityStore();
    await store.upsertAll([detailed()]);

    // 模拟下一轮同步：列表接口返回的对象没有任何详情
    final second = await store.upsertAll([listOnly()]);
    expect(second, 0, reason: '不是新活动');

    final rows = await store.loadAll();
    expect(rows.length, 1);
    expect(rows.first.intro, '去社区做志愿服务', reason: '详情被覆盖就是 bug');
    expect(rows.first.capacity, 50);
    expect(rows.first.enrollEnd, '2026-10-25 23:59');
    expect(rows.first.hours, 3);
  });

  test('MemoryActivityStore：新数据带了新详情要生效', () async {
    final store = MemoryActivityStore();
    await store.upsertAll([detailed()]);
    await store.upsertAll([
      Activity(id: 'a1', title: '志愿活动', intro: '地点改了', capacity: 80, enrolled: 79)
    ]);

    final row = (await store.loadAll()).first;
    expect(row.intro, '地点改了');
    expect(row.capacity, 80);
    expect(row.seatsLeft, 1);
  });
}
