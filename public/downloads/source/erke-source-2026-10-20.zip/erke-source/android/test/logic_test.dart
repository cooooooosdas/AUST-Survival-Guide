/// 纯逻辑单测（不碰网络、不碰数据库），`flutter test` 可直接跑。
library;

import 'package:erke_app/core/curator.dart';
import 'package:erke_app/core/models.dart';
import 'package:erke_app/core/settings.dart';
import 'package:erke_app/core/store.dart';
import 'package:flutter_test/flutter_test.dart';

String _at(int days, int hour) {
  final t = DateTime.now().add(Duration(days: days));
  String two(int v) => v.toString().padLeft(2, '0');
  return '${t.year}-${two(t.month)}-${two(t.day)} ${two(hour)}:00';
}

Activity act({
  String id = 'a1',
  String title = '测试活动',
  String credit = '社会责任担当',
  int capacity = 100,
  int enrolled = 10,
  double hours = 3,
  List<String> grade = const [],
  List<String> college = const [],
  List<String> major = const [],
  String enrollEnd = '',
}) {
  return Activity(
    id: id,
    title: title,
    creditType: credit,
    capacity: capacity,
    enrolled: enrolled,
    hours: hours,
    gradeScope: grade,
    collegeScope: college,
    majorScope: major,
    enrollEnd: enrollEnd.isEmpty ? _at(3, 20) : enrollEnd,
  );
}

void main() {
  test('学时类型归一化', () {
    expect(normalizeCreditType('志愿服务'), '社会责任担当');
    expect(normalizeCreditType('菁英骨干培训班'), '精英锻炼养成');
    expect(normalizeCreditType('思想政治引领'), '思想政治引领');
    expect(normalizeCreditType(null), kCreditUnknown);
    expect(normalizeCreditType('莫名其妙'), kCreditUnknown);
  });

  test('时间解析兼容多种写法', () {
    expect(parseDt('2026-10-16 23:25:00')!.month, 10);
    expect(parseDt('2026/10/16')!.day, 16);
    final ts = DateTime(2026, 10, 16, 12).millisecondsSinceEpoch;
    expect(parseDt(ts)!.year, 2026);
    expect(parseDt(''), isNull);
  });

  test('打分：学院定向 > 全校', () {
    final p = Profile(grade: '2024', college: '计算机学院', major: '软件工程');
    final targeted = matchActivity(act(college: ['计算机学院']), p);
    final allSchool = matchActivity(act(), p);
    expect(targeted.matchScore, greaterThan(allSchool.matchScore));
    expect(targeted.matchReasons, contains('学院定向'));
  });

  test('打分：命中排除词直接清零', () {
    final p = Profile(keywordsExclude: ['献血']);
    final a = matchActivity(act(title: '无偿献血公益活动'), p);
    expect(a.matchScore, lessThanOrEqualTo(0));
  });

  test('打分：满员扣分', () {
    final p = Profile(grade: '2024');
    final full = matchActivity(act(capacity: 10, enrolled: 10), p);
    final normal = matchActivity(act(capacity: 10, enrolled: 3), p);
    expect(full.matchScore, lessThan(normal.matchScore));
  });

  test('排序：分数高的在前', () {
    final p = Profile(grade: '2024', college: '计算机学院');
    final list = applyMatching(
      [act(id: 'x', college: ['计算机学院']), act(id: 'y')],
      p,
    );
    expect(list.first.id, 'x');
  });

  test('精选：已截止 / 已满 / 低于门槛都不推', () {
    final p = Profile(grade: '2024');
    final pool = applyMatching([
      act(id: 'ok'),
      act(id: 'closed', enrollEnd: _at(-2, 12)),
      act(id: 'full', capacity: 5, enrolled: 5),
      act(id: 'low', capacity: 0, enrolled: 0, hours: 0),
    ], p);
    final picked = pick(pool, limit: 5, minScore: 30);
    final ids = picked.map((e) => e.id).toList();
    expect(ids, contains('ok'));
    expect(ids, isNot(contains('closed')));
    expect(ids, isNot(contains('full')));
  });

  test('精选：同名活动只留一条（去掉括号后缀）', () {
    final p = Profile(grade: '2024');
    final pool = applyMatching([
      act(id: 'b1', title: '校园歌手大赛（初赛）'),
      act(id: 'b2', title: '校园歌手大赛（复赛）'),
    ], p);
    final picked = pick(pool, limit: 3, minScore: 0);
    expect(picked.length, 1);
  });

  test('免打扰支持跨零点', () {
    final s = AppSettings(quietStart: '23:30', quietEnd: '07:00');
    expect(inQuietHours(s, DateTime(2026, 10, 16, 23, 45)), isTrue);
    expect(inQuietHours(s, DateTime(2026, 10, 17, 3, 0)), isTrue);
    expect(inQuietHours(s, DateTime(2026, 10, 17, 12, 0)), isFalse);
  });

  test('演示数据可打分且不为空', () {
    final demo = applyMatching(demoActivities(), Profile(grade: '2024'));
    expect(demo, isNotEmpty);
    expect(demo.every((e) => e.title.isNotEmpty), isTrue);
  });
}
