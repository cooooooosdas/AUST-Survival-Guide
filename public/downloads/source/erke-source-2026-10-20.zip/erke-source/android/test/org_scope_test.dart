/// 「参与组织」（班级级限制）的回归测试。
///
/// 背景：活动详情的 organizationList 指定班级范围，不在名单内会被学校系统直接拒绝报名。
/// 之前只有年级/学院/专业三个维度，班级限制完全没接 ——
/// 班级内部活动会被当成普通活动推荐给别的班，收到推送也报不上。
///
/// 字段名来源：前端产物 chunk_35.js（活动详情页渲染 参与组织 → activity.organizationList）。
library;

import 'package:erke_app/core/curator.dart';
import 'package:erke_app/core/models.dart';
import 'package:flutter_test/flutter_test.dart';

Profile me() => Profile(
      grade: '2025',
      college: '计算机科学与工程学院',
      major: '软件工程',
      clazz: '软件工程25-4',
    );

Activity actWithOrg(List<String> orgs) => Activity(
      id: 'x1',
      title: '班级团日活动',
      hours: 4,
      creditType: '思想政治引领',
      orgScope: orgs,
      intro: '班级内部活动',
      enrollEnd: '2099-01-01 10:00',
    );

void main() {
  group('参与组织命中判断', () {
    test('不限组织 → 不受影响', () {
      final a = matchActivity(actWithOrg(const []), me());
      expect(a.hardBlocked, isFalse);
      expect(a.matchScore, greaterThan(0));
    });

    test('名单里出现「全校」→ 放开', () {
      final a = matchActivity(actWithOrg(const ['全校']), me());
      expect(a.hardBlocked, isFalse);
    });

    test('同班命中（名单带 _入学年 后缀）', () {
      final a = matchActivity(actWithOrg(const ['软件工程25-4_2025']), me());
      expect(a.hardBlocked, isFalse);
      expect(a.matchReasons, contains('班级定向'));
      expect(a.matchScore, greaterThan(0));
    });

    test('别的班级 → 硬拦截', () {
      final a = matchActivity(actWithOrg(const ['制药25-1_2025']), me());
      expect(a.hardBlocked, isTrue);
      expect(a.matchScore, lessThan(0));
      expect(a.matchReasons.first, startsWith('限班级'));
      expect(a.matchReasons.first, contains('制药25-1'));
    });

    test('未填班级 + 有班级限制 → 视为不符（无法证明在名单内）', () {
      final me2 = Profile(clazz: '');
      final a = matchActivity(actWithOrg(const ['制药25-1_2025']), me2);
      expect(a.hardBlocked, isTrue);
      expect(a.matchReasons.first, contains('未填班级'));
    });
  });

  group('班级匹配的边界情况', () {
    test('班号前缀不能误命中：25-1 不命中 25-11', () {
      // 「制药25-11」的学生不该被「制药25-1」的活动放行
      final other = Profile(clazz: '制药25-11');
      final a = matchActivity(actWithOrg(const ['制药25-1_2025']), other);
      expect(a.hardBlocked, isTrue);
    });

    test('班号后缀不能误命中：25-11 不命中 25-1', () {
      final other = Profile(clazz: '制药25-1');
      final a = matchActivity(actWithOrg(const ['制药25-11_2025']), other);
      expect(a.hardBlocked, isTrue, reason: '25-1 的学生报不了 25-11 的班级活动');
    });

    test('只填专业名称不算命中班级（专业 ≠ 班级）', () {
      final only = Profile(major: '制药', clazz: '制药');
      final a = matchActivity(actWithOrg(const ['制药25-1_2025']), only);
      expect(a.hardBlocked, isTrue, reason: '只说专业不算，班级必须写到班号');
    });

    test('末尾「班」字与空格不影响命中', () {
      final withBan = Profile(clazz: '软件工程25-4班');
      expect(matchActivity(actWithOrg(const ['软件工程25-4_2025']), withBan).hardBlocked,
          isFalse);

      final withSpace = Profile(clazz: ' 软件工程25-4 ');
      expect(matchActivity(actWithOrg(const ['软件工程25-4']), withSpace).hardBlocked,
          isFalse);
    });

    test('多班级名单里命中任意一个即可', () {
      final a = matchActivity(
          actWithOrg(const ['制药25-1_2025', '软件工程25-4_2025', '化工25-3']), me());
      expect(a.hardBlocked, isFalse);
    });

    test('多班级名单里一个都不命中 → 拦截', () {
      final a = matchActivity(
          actWithOrg(const ['制药25-1_2025', '化工25-3_2025', '机械25-2']), me());
      expect(a.hardBlocked, isTrue);
    });

    test('名单过长只展示前 3 个 + 省略号', () {
      final a = matchActivity(
          actWithOrg(const ['A25-1', 'B25-2', 'C25-3', 'D25-4', 'E25-5']), me());
      expect(a.matchReasons.first, contains('…'));
      expect(a.matchReasons.first, isNot(contains('E25-5')));
    });
  });

  group('精选器：硬性不符的不能推', () {
    test('班级不符 → rejectReason 有明确原因', () {
      final a = matchActivity(actWithOrg(const ['制药25-1_2025']), me());
      expect(rejectReason(a, minScore: 0), contains('不在报名范围'));
    });

    test('班级不符 → 即使分数门槛调到 0 也不进精选', () {
      final blocked = matchActivity(actWithOrg(const ['制药25-1_2025']), me());
      final open = matchActivity(actWithOrg(const []), me());
      final picked = pick([blocked, open], minScore: 0);
      expect(picked.map((e) => e.id), ['x1']); // 两个 id 相同，只应留下符合条件的那条
      expect(picked.first.hardBlocked, isFalse);
    });

    test('同班活动 → 可以进精选', () {
      final a = matchActivity(actWithOrg(const ['软件工程25-4_2025']), me());
      expect(rejectReason(a, minScore: 0), isEmpty);
      expect(pick([a], minScore: 0).length, 1);
    });
  });

  group('序列化与合并', () {
    test('orgScope / clazz / hardBlocked 能存能取', () {
      final a = matchActivity(actWithOrg(const ['制药25-1_2025']), me());
      final back = Activity.fromMap(a.toMap());
      expect(back.orgScope, ['制药25-1_2025']);
      expect(back.hardBlocked, isTrue);

      final p = me().toMap();
      expect(Profile.fromMap(p).clazz, '软件工程25-4');
    });

    test('mergeDetailsFrom 保留上一轮的组织名单', () {
      final old = actWithOrg(const ['制药25-1_2025']);
      final fresh = Activity(id: 'x1', title: '班级团日活动'); // 列表接口返回的对象
      fresh.mergeDetailsFrom(old);
      expect(fresh.orgScope, ['制药25-1_2025'], reason: '组织名单被冲掉就和详情被冲掉是同一个坑');
    });
  });
}
