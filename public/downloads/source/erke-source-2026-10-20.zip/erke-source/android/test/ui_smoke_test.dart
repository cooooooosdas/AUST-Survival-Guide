/// 界面冒烟测试：在 360×780 的手机尺寸下把三个主页面和详情页渲染一遍，
/// 任何布局溢出（RenderFlex overflow）都会让测试失败。
library;

import 'package:erke_app/core/models.dart';
import 'package:erke_app/core/settings.dart';
import 'package:erke_app/core/state.dart';
import 'package:erke_app/core/store.dart';
import 'package:erke_app/ui/detail_page.dart';
import 'package:erke_app/ui/home_page.dart';
import 'package:erke_app/ui/reco_page.dart';
import 'package:erke_app/ui/theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Widget _wrap(Widget child) => MaterialApp(
      theme: buildTheme(),
      locale: const Locale('zh', 'CN'),
      // 真机上页面都活在 RootPage 的 Scaffold 里，测试里补一个等价的 Material 上下文
      home: Scaffold(body: child),
    );

AppState _state() {
  final state = AppState();
  state.settings = AppSettings(
    schoolName: '某某大学',
    schoolId: '1',
    onboarded: true,
    accountMasked: '2024****01',
    lastSyncAt: '2026-10-16 23:40',
  );
  state.all = applyMatching(demoActivities(), state.settings.profile);
  state.visible = state.all;
  state.statusText = '共 ${state.all.length} 条活动';
  return state;
}

void _phone(WidgetTester tester, {double width = 360, double height = 780}) {
  tester.view.physicalSize = Size(width * 3, height * 3);
  tester.view.devicePixelRatio = 3.0;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);
}

void main() {
  testWidgets('首页：统计块 + 筛选 chip + 活动卡片', (tester) async {
    _phone(tester);
    await tester.pumpWidget(_wrap(HomePage(state: _state())));
    await tester.pump(const Duration(milliseconds: 200));

    expect(find.text('第二课堂'), findsOneWidget);
    expect(find.text('活动总数'), findsOneWidget);
    expect(find.text('只看新增'), findsOneWidget);
    expect(find.textContaining('某某大学'), findsOneWidget);
    // 演示数据里至少有一条活动卡片
    expect(find.text('去报名'), findsWidgets);
  });

  testWidgets('提醒页：精选卡片 + 说明区', (tester) async {
    _phone(tester);
    await tester.pumpWidget(_wrap(RecoPage(state: _state())));
    await tester.pump(const Duration(milliseconds: 200));

    expect(find.text('精选提醒'), findsOneWidget);
    expect(find.text('提醒怎么工作'), findsOneWidget);
  });

  testWidgets('详情页：名额 / 时间 / 匹配理由', (tester) async {
    _phone(tester);
    final a = demoActivities().first;
    await tester.pumpWidget(_wrap(DetailPage(activity: a)));
    await tester.pump(const Duration(milliseconds: 200));

    expect(find.text('活动详情'), findsOneWidget);
    expect(find.text('名额'), findsOneWidget);
    expect(find.text('时间'), findsOneWidget);
    expect(find.textContaining('为什么推给你'), findsOneWidget);
    expect(find.text('去报名'), findsOneWidget);
  });

  testWidgets('窄屏（320 宽）也不溢出', (tester) async {
    _phone(tester, width: 320, height: 640);
    await tester.pumpWidget(_wrap(HomePage(state: _state())));
    await tester.pump(const Duration(milliseconds: 200));
    expect(find.text('第二课堂'), findsOneWidget);
  });
}
