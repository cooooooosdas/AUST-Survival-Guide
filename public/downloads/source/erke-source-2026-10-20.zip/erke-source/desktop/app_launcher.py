"""PyInstaller 打包入口。

打包后的 exe 双击即运行，等价于 `python -m backend.main`。
之所以单独放一个入口文件：`backend/main.py` 里用的是包内相对导入
（`from . import api`），不能直接当脚本执行。
"""

from backend.main import main

if __name__ == "__main__":
    main()
