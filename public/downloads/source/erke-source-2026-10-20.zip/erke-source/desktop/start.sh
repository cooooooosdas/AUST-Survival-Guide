#!/usr/bin/env bash
# 二课提醒小助手 - 启动脚本（macOS / Linux / Git Bash）
set -euo pipefail
cd "$(dirname "$0")"

echo "============================================================"
echo "  二课提醒小助手 - 启动脚本"
echo "============================================================"

PY=${PYTHON:-python3}
command -v "$PY" >/dev/null 2>&1 || { echo "[错误] 未找到 $PY，请先安装 Python 3.10+"; exit 1; }

if [ ! -x ".venv/bin/python" ]; then
  echo "[1/3] 首次运行，正在创建虚拟环境..."
  "$PY" -m venv .venv
  echo "[2/3] 正在安装依赖..."
  .venv/bin/python -m pip install --upgrade pip -q
  .venv/bin/python -m pip install -r requirements.txt
else
  echo "[1/3] 已存在虚拟环境，跳过创建"
  echo "[2/3] 跳过依赖安装"
fi

echo "[3/3] 启动服务..."
exec .venv/bin/python -m backend.main
