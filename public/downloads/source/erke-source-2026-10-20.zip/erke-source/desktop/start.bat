@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================================
echo   二课提醒小助手 - 启动脚本
echo ============================================================

rem 优先用项目自带虚拟环境；其次用本机已就绪的共享环境；
rem 都没有才现建（首次建环境要联网装依赖，比较慢）。
set "PY="
if exist ".venv\Scripts\python.exe" set "PY=.venv\Scripts\python.exe"
if not defined PY if exist "%USERPROFILE%\.workbuddy\binaries\python\envs\default\Scripts\python.exe" set "PY=%USERPROFILE%\.workbuddy\binaries\python\envs\default\Scripts\python.exe"

if defined PY goto :run

where python >nul 2>nul
if errorlevel 1 (
  echo [错误] 未检测到 python，请先安装 Python 3.10+ 并勾选 Add to PATH
  pause
  exit /b 1
)

echo [1/2] 首次运行，正在创建虚拟环境...
python -m venv .venv
if errorlevel 1 (
  echo [错误] 创建虚拟环境失败
  pause
  exit /b 1
)
set "PY=.venv\Scripts\python.exe"
echo [2/2] 正在安装依赖（约 1-3 分钟）...
"%PY%" -m pip install --upgrade pip -q -i https://pypi.tuna.tsinghua.edu.cn/simple
"%PY%" -m pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
goto :run

:run
echo [1/1] 使用 Python 环境：%PY%
echo [2/2] 启动服务，浏览器请打开： http://127.0.0.1:8848/
echo       （关闭本窗口即停止服务）
rem 已占端口时先让用户知道，免得看到「启动失败」不知所措
netstat -ano | findstr ":8848" | findstr "LISTENING" >nul 2>nul
if not errorlevel 1 (
  echo [提示] 8848 端口已被占用，服务可能已在运行。
  echo        直接打开 http://127.0.0.1:8848/ 即可；要重启请先关掉旧窗口。
  pause
  exit /b 0
)

"%PY%" -m backend.main

endlocal
