"""凭据保护模块 —— 隐私保护的第一道防线。

设计原则（对应需求「系统须严格保护用户隐私」）：
  1. 明文密码永不落盘。落盘的只有密文信封（data/credentials.bin）。
  2. 明文密码永不进入日志、永不通过 HTTP 回传前端。前端只看到掩码串。
  3. 默认使用操作系统级密钥保护：
       - Windows：DPAPI(CryptProtectData)，密文与当前 Windows 用户绑定，
         拷走到别的机器/别的账户也无法解密，无需用户额外记一个主密码。
       - 其他平台：scrypt + AES-256-GCM，主密码只存在于内存。
  4. 内存中的明文仅在「需要发起登录请求」的瞬间存在，请求结束立即覆盖。
  5. 一键「清除本地凭据」彻底删除密文文件。

密文信封格式（JSON）::

    {
      "v": 1,
      "backend": "dpapi" | "scrypt-aesgcm",
      "kdf": {"salt": "...", "n": 32768, "r": 8, "p": 1} | null,
      "nonce": "..." | null,
      "ciphertext": "<base64>"
    }
"""

from __future__ import annotations

import base64
import ctypes
import json
import os
import sys
from ctypes import wintypes
from pathlib import Path
from typing import Any

from .settings import SECRET_PATH, ensure_dirs

_APP_ENTROPY = b"erke-helper::v1::credential-vault"

# --------------------------------------------------------------------------- #
# Windows DPAPI
# --------------------------------------------------------------------------- #

_IS_WINDOWS = sys.platform.startswith("win")


class _DataBlob(ctypes.Structure):
    _fields_ = [
        ("cbData", wintypes.DWORD),
        ("pbData", ctypes.POINTER(ctypes.c_byte)),
    ]


def _dpapi_available() -> bool:
    if not _IS_WINDOWS:
        return False
    try:
        ctypes.WinDLL("crypt32")
        return True
    except Exception:
        return False


def _make_blob(data: bytes):
    buf = ctypes.create_string_buffer(data, len(data)) if data else ctypes.create_string_buffer(1)
    blob = _DataBlob(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte)))
    return blob, buf  # 必须把 buf 一起返回，防止被 GC 回收


def _dpapi_protect(plain: bytes) -> bytes:
    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    crypt32.CryptProtectData.argtypes = [
        ctypes.POINTER(_DataBlob), wintypes.LPCWSTR, ctypes.POINTER(_DataBlob),
        ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(_DataBlob),
    ]
    crypt32.CryptProtectData.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p

    in_blob, _in_buf = _make_blob(plain)
    ent_blob, _ent_buf = _make_blob(_APP_ENTROPY)
    out_blob = _DataBlob()
    # CRYPTPROTECT_UI_FORBIDDEN = 0x1 —— 禁止弹出任何 UI，静默失败
    ok = crypt32.CryptProtectData(
        ctypes.byref(in_blob), "erke-helper", ctypes.byref(ent_blob),
        None, None, 0x1, ctypes.byref(out_blob),
    )
    if not ok:
        raise OSError(f"CryptProtectData failed: {ctypes.get_last_error()}")
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        kernel32.LocalFree(out_blob.pbData)


def _dpapi_unprotect(cipher: bytes) -> bytes:
    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    crypt32.CryptUnprotectData.argtypes = [
        ctypes.POINTER(_DataBlob), ctypes.POINTER(wintypes.LPWSTR), ctypes.POINTER(_DataBlob),
        ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(_DataBlob),
    ]
    crypt32.CryptUnprotectData.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p

    in_blob, _in_buf = _make_blob(cipher)
    ent_blob, _ent_buf = _make_blob(_APP_ENTROPY)
    out_blob = _DataBlob()
    ok = crypt32.CryptUnprotectData(
        ctypes.byref(in_blob), None, ctypes.byref(ent_blob),
        None, None, 0x1, ctypes.byref(out_blob),
    )
    if not ok:
        raise OSError(
            "CryptUnprotectData failed —— 密文可能来自其他 Windows 账户或已被篡改"
        )
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        kernel32.LocalFree(out_blob.pbData)


# --------------------------------------------------------------------------- #
# scrypt + AES-GCM（跨平台 / 主密码模式）
# --------------------------------------------------------------------------- #

_SCRYPT_N, _SCRYPT_R, _SCRYPT_P = 1 << 15, 8, 1


def _derive_key(password: str, salt: bytes, n: int, r: int, p: int) -> bytes:
    from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

    kdf = Scrypt(salt=salt, length=32, n=n, r=r, p=p)
    return kdf.derive(password.encode("utf-8"))


def _aesgcm_encrypt(key: bytes, plain: bytes) -> tuple[bytes, bytes]:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    nonce = os.urandom(12)
    return AESGCM(key).encrypt(nonce, plain, _APP_ENTROPY), nonce


def _aesgcm_decrypt(key: bytes, nonce: bytes, cipher: bytes) -> bytes:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    return AESGCM(key).decrypt(nonce, cipher, _APP_ENTROPY)


# --------------------------------------------------------------------------- #
# 对外接口
# --------------------------------------------------------------------------- #


class VaultError(RuntimeError):
    pass


class CredentialVault:
    """凭据保险箱：负责密文的读写与加解密。"""

    def __init__(self, path: Path | None = None) -> None:
        self.path = Path(path or SECRET_PATH)
        # 主密码只驻留内存，绝不落盘
        self._master_password: str | None = None
        ensure_dirs()

    # -- 模式 --------------------------------------------------------------- #

    @property
    def backend(self) -> str:
        return "dpapi" if _dpapi_available() else "scrypt-aesgcm"

    @property
    def mode_label(self) -> str:
        return {
            "dpapi": "Windows 系统级加密（DPAPI，绑定当前 Windows 账户）",
            "scrypt-aesgcm": "主密码加密（scrypt + AES-256-GCM）",
        }[self.backend]

    def set_master_password(self, password: str | None) -> None:
        """非 DPAPI 环境下必须提供主密码；也可在 Windows 上强制使用主密码模式。"""
        self._master_password = password

    def has_master_password(self) -> bool:
        return bool(self._master_password)

    # -- 读写 --------------------------------------------------------------- #

    def exists(self) -> bool:
        return self.path.exists() and self.path.stat().st_size > 0

    def save(self, payload: dict[str, Any]) -> None:
        plain = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        backend = self.backend
        try:
            if backend == "dpapi":
                envelope = {
                    "v": 1,
                    "backend": "dpapi",
                    "kdf": None,
                    "nonce": None,
                    "ciphertext": base64.b64encode(_dpapi_protect(plain)).decode("ascii"),
                }
            else:
                if not self._master_password:
                    raise VaultError(
                        "当前环境不支持系统级加密，请先设置主密码后再保存凭据。"
                    )
                salt = os.urandom(16)
                key = _derive_key(self._master_password, salt, _SCRYPT_N, _SCRYPT_R, _SCRYPT_P)
                cipher, nonce = _aesgcm_encrypt(key, plain)
                envelope = {
                    "v": 1,
                    "backend": "scrypt-aesgcm",
                    "kdf": {
                        "salt": base64.b64encode(salt).decode("ascii"),
                        "n": _SCRYPT_N, "r": _SCRYPT_R, "p": _SCRYPT_P,
                    },
                    "nonce": base64.b64encode(nonce).decode("ascii"),
                    "ciphertext": base64.b64encode(cipher).decode("ascii"),
                }
        finally:
            # 尽快丢弃明文副本
            del plain

        ensure_dirs()
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(envelope), encoding="utf-8")
        os.replace(tmp, self.path)
        try:
            os.chmod(self.path, 0o600)  # 尽力而为：POSIX 下限制为仅属主可读写
        except Exception:
            pass

    def load(self) -> dict[str, Any]:
        if not self.exists():
            raise VaultError("尚未保存任何凭据")
        envelope = json.loads(self.path.read_text(encoding="utf-8"))
        backend = envelope.get("backend")
        cipher = base64.b64decode(envelope["ciphertext"])
        if backend == "dpapi":
            plain = _dpapi_unprotect(cipher)
        elif backend == "scrypt-aesgcm":
            if not self._master_password:
                raise VaultError("该凭据由主密码保护，需要提供主密码。")
            kdf = envelope["kdf"]
            key = _derive_key(
                self._master_password,
                base64.b64decode(kdf["salt"]),
                int(kdf["n"]), int(kdf["r"]), int(kdf["p"]),
            )
            plain = _aesgcm_decrypt(key, base64.b64decode(envelope["nonce"]), cipher)
        else:
            raise VaultError(f"未知的密文后端: {backend}")
        return json.loads(plain.decode("utf-8"))

    def clear(self) -> None:
        """彻底销毁本地凭据。"""
        for p in (self.path, self.path.with_suffix(".tmp")):
            try:
                if p.exists():
                    data = bytearray(p.read_bytes())
                    for i in range(len(data)):  # 覆写后删除，降低磁盘残留概率
                        data[i] = 0
                    p.write_bytes(bytes(data))
                    p.unlink()
            except Exception:
                try:
                    p.unlink(missing_ok=True)
                except Exception:
                    pass

    def status(self) -> dict[str, Any]:
        return {
            "exists": self.exists(),
            "backend": self.backend,
            "mode_label": self.mode_label,
            "needs_master_password": self.backend != "dpapi",
        }


# --------------------------------------------------------------------------- #
# 展示辅助
# --------------------------------------------------------------------------- #


def mask(secret: str | None, keep_head: int = 1, keep_tail: int = 1) -> str:
    """生成只用于界面展示的掩码串；任何情况下都不回传明文。"""
    if not secret:
        return ""
    s = str(secret)
    if len(s) <= keep_head + keep_tail:
        return "*" * len(s)
    return f"{s[:keep_head]}{'*' * (len(s) - keep_head - keep_tail)}{s[-keep_tail:]}"


def hint_of(password: str | None) -> str:
    """仅暴露长度量级，不泄露任何字符。"""
    if not password:
        return "未设置"
    return f"已设置 · {'短' if len(password) < 8 else '中' if len(password) < 14 else '长'}"
