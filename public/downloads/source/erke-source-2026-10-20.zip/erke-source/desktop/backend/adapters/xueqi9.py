"""趣拓（9xueqi）第二课堂适配器。

接口契约来源：对 https://win.9xueqi.com 前端打包产物（app.js / chunk_*.js）
的静态分析还原，详见 docs/02-接口逆向记录.md。

已确认：
  * baseURL      : https://win.9xueqi.com/api/app/client/v1/
  * 登录         : POST token   form: schoolCode / code / password / openId
                   -> { code:0, data:{ access_token } }
  * 鉴权         : header  Authorization: <token>，同时 token 也放进 params
  * GET 传参     : 所有业务参数被合并成一个 JSON 串塞进单一 query 参数 params
  * 通用参数     : token / platform / version / device / timestamp
  * 用户信息     : GET student/user/my-info
  * 活动列表     : GET page/activity/list   (pageNum, pageSize, sortType,
                   classifyId, fieldType=activity_iseErollment, keyWord=switch)
  * 分类字典     : GET dict/activity/choice-sort
  * 会话失效     : 业务码 code == 10001  ("登陆失败，请重新登陆")

待用真实测试账号验证（已在代码中做了容错与多字段名兜底）：
  * 活动详情页的路由名（影响「一键跳转报名」的深链格式）
  * 活动列表返回体里各字段的确切命名
  * 年龄/学院/专业限制字段的存放位置
"""

from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime
from typing import Any
from urllib.parse import quote

import httpx

from ..models import Activity, digest_id, normalize_credit_type
from ..settings import DATA_DIR, SourceSettings
from .base import FetchResult, LoginResult

CODE_OK = 0
CODE_SESSION_INVALID = 10001
CODE_PARAM_ERROR = 10002

_UA = (
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1 MicroMessenger/8.0.49"
)


def _pack(payload: dict[str, Any]) -> str:
    """把请求参数序列化成服务端要求的紧凑 JSON 字符串。

    服务端对 GET 的 params 查询参数、POST 的 params 表单字段都只认 JSON，
    非 JSON 会直接回 `10002 参数格式不正确，参数必须是JSON格式`。
    """
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def _pick(obj: dict, *names: str, default: Any = None) -> Any:
    """在多个候选字段名中取第一个非空值（应对字段命名不确定）。"""
    for n in names:
        if n in obj and obj[n] not in (None, "", [], {}):
            return obj[n]
    return default


def _to_str_list(value: Any) -> list[str]:
    """把各种形态的「范围」字段归一化成字符串列表。"""
    if value in (None, "", [], {}):
        return []
    if isinstance(value, str):
        parts: list[str] = []
        for chunk in value.replace("，", ",").replace("、", ",").replace(";", ",").split(","):
            chunk = chunk.strip()
            if chunk:
                parts.append(chunk)
        return parts
    if isinstance(value, dict):
        for key in ("name", "names", "list", "value", "label", "text", "id"):
            if key in value:
                return _to_str_list(value[key])
        return []
    if isinstance(value, (list, tuple, set)):
        out: list[str] = []
        for item in value:
            out.extend(_to_str_list(item))
        return [x for x in out if x]
    return [str(value)]


class Xueqi9Source:
    """趣拓二课系统数据源。"""

    name = "xueqi9"

    def __init__(self, settings: SourceSettings) -> None:
        self.settings = settings
        self.base = settings.base_url.rstrip("/") + "/"
        self._client: httpx.AsyncClient | None = None
        self._token = ""
        self._logged_in = False
        self._account = ""
        self._lock = asyncio.Lock()
        self._last_request_at = 0.0
        self._last_error = ""
        self.login_count = 0
        self.last_login_at = ""
        # 详情缓存 + 已见过的活动 ID（用于把「补详情的预算」优先花在新活动上）
        self._detail_cache: dict[str, dict[str, Any]] = _load_detail_cache()
        self._known_ids: set[str] = set(self._detail_cache.keys())
        self._last_ids: set[str] = set()

    # ------------------------------------------------------------------ #
    # 基础设施
    # ------------------------------------------------------------------ #

    async def _http(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=self.settings.request_timeout,
                follow_redirects=True,
                headers={
                    "User-Agent": _UA,
                    "Accept": "application/json, text/plain, */*",
                    "Origin": self.settings.web_origin,
                    "Referer": self.settings.web_origin + "/",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
            )
        return self._client

    async def _throttle(self) -> None:
        """礼貌节流：避免高频请求给对方服务器造成压力。"""
        gap = float(self.settings.min_interval_between_requests or 0)
        if gap <= 0:
            return
        wait = gap - (time.monotonic() - self._last_request_at)
        if wait > 0:
            await asyncio.sleep(wait)
        self._last_request_at = time.monotonic()

    def _common_params(self) -> dict[str, Any]:
        return {
            "token": self._token or "",
            "platform": self.settings.platform,
            "version": self.settings.platform_version,
            "device": self.settings.device_id,
            "timestamp": int(time.time() * 1000),
        }

    async def _request(self, method: str, path: str,
                       params: dict[str, Any] | None = None,
                       data: dict[str, Any] | None = None) -> dict[str, Any]:
        """统一的请求入口，自动处理 params 包装与 10001 会话失效。"""
        client = await self._http()
        headers = {}
        if self._token:
            headers["Authorization"] = self._token

        url = self.base + path.lstrip("/")

        if method.upper() == "GET":
            merged = {**(params or {}), **self._common_params()}
            # 前端把整个 JSON 塞进单个 params 查询参数
            query = f"params={quote(_pack(merged), safe='')}"
            full = f"{url}?{query}"
            await self._throttle()
            resp = await client.get(full, headers=headers)
        else:
            merged = {**(data or {}), **self._common_params()}
            await self._throttle()
            resp = await client.post(url, data={"params": _pack(merged)}, headers=headers)

        if resp.status_code != 200:
            raise RuntimeError(f"HTTP {resp.status_code} on {path}")

        try:
            payload = resp.json()
        except Exception as exc:
            raise RuntimeError(f"响应不是合法 JSON（{path}）") from exc

        code = payload.get("code")
        if code == CODE_SESSION_INVALID:
            self._logged_in = False
            self._token = ""
            raise SessionExpired(payload.get("msg") or "登陆失败，请重新登陆")
        if code != CODE_OK:
            raise RuntimeError(payload.get("msg") or f"业务失败 code={code}")
        return payload

    # ------------------------------------------------------------------ #
    # 登录 / 保活
    # ------------------------------------------------------------------ #

    async def login(self, credential: dict[str, Any]) -> LoginResult:
        account = str(credential.get("account") or "").strip()
        password = str(credential.get("password") or "")
        if not account or not password:
            return LoginResult(ok=False, message="缺少账号或密码")
        if not self.settings.school_id:
            return LoginResult(ok=False, message="缺少学校 ID（schoolId），请先在设置中选择学校")

        form = {
            "schoolCode": str(self.settings.school_id),
            "code": account,
            "password": password,
            "openId": "",
        }
        try:
            client = await self._http()
            await self._throttle()
            # 关键：POST 的负载必须「整体」包进单一的 params 字段（JSON 字符串）。
            # 平铺成 schoolCode=..&code=..&password=.. 会被服务端判为
            # code=10002「参数错误!」——这一点是 2026-10-17 用真实账号实测出来的，
            # 与前端 axios 拦截器一致：
            #   t.data = qs.stringify({ params: JSON.stringify(t.data) })
            body = {"params": _pack(form)}
            resp = await client.post(self.base + "token", data=body)
            payload = resp.json()
        except Exception as exc:
            self._last_error = str(exc)
            return LoginResult(ok=False, message=f"登录请求失败：{exc}")

        if payload.get("code") != CODE_OK:
            code = payload.get("code")
            msg = payload.get("msg") or "登录失败"
            if code == CODE_PARAM_ERROR:
                # 实测：schoolCode 缺失时服务端才回 10002；不是「学校不存在」的意思
                msg = "参数错误（10002）：学校编号（schoolId）为空或无效，请先选择学校"
            self._last_error = str(msg)
            return LoginResult(ok=False, message=msg)

        token = (payload.get("data") or {}).get("access_token") or payload.get("token") or ""
        if not token:
            return LoginResult(ok=False, message="登录成功但未取到 access_token")

        self._token = token
        self._logged_in = True
        self._account = account
        self.login_count += 1
        self.last_login_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self._last_error = ""

        info = await self._my_info()
        return LoginResult(
            ok=True,
            message="登录成功",
            display_name=str(_pick(info, "userName", "name", "realName", "studentName", default=account)),
            profile_hint=self._profile_hint(info),
        )

    async def _my_info(self) -> dict[str, Any]:
        try:
            payload = await self._request("GET", "student/user/my-info")
            data = payload.get("data") or {}
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    @staticmethod
    def _profile_hint(info: dict[str, Any]) -> dict[str, Any]:
        return {
            "schoolName": _pick(info, "schoolName", "schoolShortName", default=""),
            "schoolId": _pick(info, "schoolId", default=""),
            "college": _pick(info, "collegeName", "departmentName", "academyName", default=""),
            "major": _pick(info, "majorName", "specialityName", default=""),
            "grade": _pick(info, "gradeName", "grade", "enrollYear", default=""),
            "className": _pick(info, "className", default=""),
            "name": _pick(info, "userName", "name", "realName", default=""),
        }

    async def keepalive(self) -> LoginResult:
        """轻量保活：命中一个已登录才可用的接口，顺带刷新会话。"""
        if not self._logged_in:
            return LoginResult(ok=False, message="会话已失效")
        try:
            await self._request("GET", "student/user/my-info")
            return LoginResult(ok=True, message="会话正常")
        except SessionExpired as exc:
            return LoginResult(ok=False, message=str(exc))
        except Exception as exc:
            self._last_error = str(exc)
            return LoginResult(ok=False, message=str(exc))

    # ------------------------------------------------------------------ #
    # 取活动
    # ------------------------------------------------------------------ #

    async def fetch_activities(self, *, pages: int = 3, page_size: int = 20) -> FetchResult:
        """拉取活动列表，并「按需」补全详情。

        列表接口（GET /activity/list）很瘦，只回 10 个字段：
           name / logo / startTime / endTime / address / organizationName /
           hours / createId / organizationStatus / id
        报名起止时间、人数上限、已报名人数、六类学时归属、活动简介、面向范围
        全部只在详情接口（GET /activity/detail/non-member）里。所以这里做两段式：
          1) 列表分页拿全量 ID（1 次请求/页）
          2) 只对「本适配器还没见过」的活动补详情，每轮有预算上限（enrich_limit），
             避免一次 77 个活动把对方服务器打爆。
        详情结果在实例内缓存，跨轮复用；因此首轮之后的增量轮询只补真正的新活动。
        """
        if not self._logged_in:
            return FetchResult(ok=False, message="尚未登录")

        collected: list[Activity] = []
        raw_total = 0
        try:
            for page_num in range(1, max(1, pages) + 1):
                payload = await self._request(
                    "GET", "activity/list",
                    params={
                        "pageNum": page_num,
                        "pageSize": page_size,
                        "name": "",
                        "classifyId": "",
                        "sortType": self.settings.sort_type,
                    },
                )
                data = payload.get("data") or {}
                rows = data.get("list") or data.get("records") or []
                raw_total = int(data.get("total") or raw_total)
                if not rows:
                    break
                for row in rows:
                    if isinstance(row, dict):
                        collected.append(self._map_list_row(row))
                if len(rows) < page_size:
                    break
                if raw_total and len(collected) >= raw_total:
                    break
        except SessionExpired as exc:
            return FetchResult(ok=False, message=f"会话失效：{exc}")
        except Exception as exc:
            self._last_error = str(exc)
            return FetchResult(ok=False, message=f"拉取活动失败：{exc}")

        enriched, enrich_note = await self._enrich_details(collected)

        return FetchResult(
            activities=collected, ok=True,
            message=(f"拉取 {len(collected)} 条活动（服务端 total={raw_total}）"
                     + (f"，补全 {enriched} 条详情" if enriched else "")
                     + (f"（{enrich_note}）" if enrich_note else "")),
            raw_count=raw_total,
            extra={"total": raw_total, "enriched": enriched},
        )

    async def _enrich_details(self, activities: list[Activity]) -> tuple[int, str]:
        """给活动补详情。返回 (补全条数, 说明)。"""
        if not self.settings.enrich_detail or not activities:
            return 0, ""

        limit = max(0, int(self.settings.enrich_limit))
        if limit == 0:
            return 0, ""

        # 缓存命中：直接套用
        for act in activities:
            cached = self._detail_cache.get(act.id)
            if cached:
                self._apply_detail(act, cached)

        fresh_ids = {a.id for a in activities if a.id not in self._known_ids}
        todo = [a for a in activities if a.id not in self._detail_cache]
        # 优先级：本轮首次出现的新活动排在最前，保证新活动的报名信息最先补全
        todo.sort(key=lambda a: (a.id not in fresh_ids,))

        done = 0
        failed = 0
        for act in todo[:limit]:
            detail = await self._fetch_detail(act.id)
            if detail:
                self._detail_cache[act.id] = detail
                self._apply_detail(act, detail)
                done += 1
            else:
                failed += 1

        self._known_ids.update(a.id for a in activities)
        self._last_ids = {a.id for a in activities}
        if done or failed:
            _save_detail_cache(self._detail_cache, keep_ids=self._last_ids)

        pending = len(todo) - done - failed
        notes = []
        if pending > 0:
            notes.append(f"还有 {pending} 条待下轮补全")
        if failed:
            notes.append(f"{failed} 条详情获取失败")
        return done, "；".join(notes)

    async def _fetch_detail(self, act_id: str) -> dict[str, Any] | None:
        """GET /activity/detail/non-member —— 学生视角的活动详情。"""
        try:
            payload = await self._request(
                "GET", "activity/detail/non-member", params={"id": act_id}
            )
        except SessionExpired:
            raise
        except Exception as exc:
            self._last_error = str(exc)
            return None
        data = payload.get("data")
        return data if isinstance(data, dict) else None

    async def fetch_detail(self, act_id: str) -> dict[str, Any] | None:
        """对外暴露的详情获取（前端点开某条活动时按需调用）。"""
        if not self._logged_in:
            return None
        cached = self._detail_cache.get(str(act_id))
        if cached:
            return cached
        detail = await self._fetch_detail(str(act_id))
        if detail:
            self._detail_cache[str(act_id)] = detail
            _save_detail_cache(self._detail_cache, keep_ids=self._last_ids or None)
        return detail

    # ------------------------------------------------------------------ #
    # 字段映射
    # ------------------------------------------------------------------ #

    def _map_list_row(self, row: dict[str, Any]) -> Activity:
        """映射「列表」返回的瘦字段（实测 10 个字段）。

        实测样例：
        {"hours":3.0,"address":"天工南107","organizationName":"计算机科学与工程学院",
         "createId":1363543,"name":"…宏辞辩论队新生赛","logo":"https://…",
         "startTime":1792216800000,"organizationStatus":1,"id":572270,
         "endTime":1792224000000}
        """
        act_id = str(_pick(row, "id", "activityId", "actId",
                           default=digest_id(json.dumps(row, sort_keys=True, ensure_ascii=False))))
        act = Activity(
            id=act_id,
            title=str(_pick(row, "name", "activityName", "title", default="未命名活动")),
            organizer=str(_pick(row, "organizationName", "orgName", default="") or ""),
            activity_start=_fmt(_pick(row, "startTime", "activityStartTime", default="")),
            activity_end=_fmt(_pick(row, "endTime", "activityEndTime", default="")),
            location=str(_pick(row, "address", "activityAddress", "place", default="") or ""),
            logo=str(_pick(row, "logo", "activityLogo", "coverUrl", default="") or ""),
            status=str(_pick(row, "organizationStatus", "status", "activityStatus", default="") or ""),
            hours=_to_float(_pick(row, "hours", "definedHours", default=0)),
            signup_url=self.signup_url(None, act_id),
        )
        # 学时分类（classifyName）在列表接口里没有，只能等详情回来补。
        # 这里如实留空（未分类），不做标题猜测，避免给用户错误分类。
        return act

    def _apply_detail(self, act: Activity, d: dict[str, Any]) -> Activity:
        """把详情接口的字段合并进活动对象（字段名为实测确认）。"""
        raw_type = str(_pick(d, "classifyName", "classify", default="") or "")
        if raw_type:
            act.credit_type_raw = raw_type
            act.credit_type = normalize_credit_type(raw_type)

        act.title = str(_pick(d, "name", default=act.title) or act.title)
        act.intro = str(_pick(d, "introduce", "content", default=act.intro) or act.intro)

        manager = d.get("manager") if isinstance(d.get("manager"), dict) else {}
        org = str(_pick(d, "organizationName", default="") or "")
        manager_name = str((manager or {}).get("name") or "")
        if org and manager_name and manager_name not in org:
            act.organizer = f"{org}（{manager_name}）"
        else:
            act.organizer = manager_name or org or act.organizer

        act.capacity = _to_int(_pick(d, "peopleLimit", "maxNum", default=0))
        act.enrolled = _to_int(_pick(d, "joinMemberCount", "enrollNum", default=0))
        act.enroll_start = _fmt(_pick(d, "enrollStartTime", default=""))
        act.enroll_end = _fmt(_pick(d, "enrollEndTime", default=""))
        act.activity_start = _fmt(_pick(d, "startTime", default=act.activity_start))
        act.activity_end = _fmt(_pick(d, "endTime", default=act.activity_end))
        act.location = str(_pick(d, "address", default=act.location) or act.location)
        act.logo = str(_pick(d, "logo", default=act.logo) or act.logo)
        act.status = str(_pick(d, "activityStatus", default=act.status) or act.status)

        # 面向范围：详情里是对象数组 [{name:..}]，空数组 = 不限
        act.grade_scope = _to_str_list(d.get("gradeList"))
        act.college_scope = _to_str_list(d.get("collegeList"))
        act.major_scope = _to_str_list(d.get("majorList"))
        # 参与组织（班级级限制）：[{'name':'制药25-1_2025'}]，空数组 = 不限班级
        act.org_scope = _to_str_list(d.get("organizationList"))

        act.hours = _to_float(_pick(d, "hours", "definedHours", default=act.hours))
        return act

    # ------------------------------------------------------------------ #
    # 深链 / 状态
    # ------------------------------------------------------------------ #

    def signup_url(self, activity: Activity | None, act_id: str = "") -> str:
        """生成「一键跳转二课报名页」的深链。

        路由名实测来自前端路由表（app.js）：
          /ActivityShow/:id  name=ActivityShow  —— 学生视角活动详情（未报名时走这里）
        注意：原来的 /actDetail/:id 是不存在的路由（前端路由表里没有 actDetail），
        会掉到 404。正确的详情页有四个变体，按身份分流：
          ActivityShow（普通学生）/ activityShowNormal（已报名）/
          activityShowAdmin（管理员）/ acticvityDetail（报名表单页）
        这里统一用 ActivityShow —— 无论是否已报名，点进去都能看到活动并报名。
        """
        origin = self.settings.web_origin.rstrip("/")
        aid = act_id or (activity.id if activity else "")
        if not aid:
            return f"{origin}/#/actList"
        return f"{origin}/#/ActivityShow/{aid}"

    # ------------------------------------------------------------------ #
    # 登录后可选用的字典接口（用于把「学院 / 年级 / 学时分类」变成下拉框）
    # ------------------------------------------------------------------ #

    async def get_dict(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """调用一个字典接口并返回 data。未登录或失败时返回 None，交由上层回退。"""
        if not self._logged_in:
            return None
        try:
            payload = await self._request("GET", path, params=params or {})
            return payload.get("data")
        except Exception:
            return None

    def status(self) -> dict[str, Any]:
        return {
            "adapter": self.name,
            "logged_in": self._logged_in,
            "display_name": self._account,
            "account_masked": _mask(self._account),
            "school_id": self.settings.school_id,
            "login_count": self.login_count,
            "last_login_at": self.last_login_at,
            "last_error": self._last_error,
        }

    async def aclose(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()


class SessionExpired(RuntimeError):
    """服务端返回 10001，需要重新登录。"""


def _to_int(value: Any, default: int = 0) -> int:
    try:
        if value in (None, ""):
            return default
        return int(float(value))
    except Exception:
        return default


def _to_float(value: Any, default: float = 0.0) -> float:
    try:
        if value in (None, ""):
            return default
        return float(value)
    except Exception:
        return default


def _load_detail_cache() -> dict[str, dict[str, Any]]:
    try:
        if _DETAIL_CACHE.exists():
            raw = json.loads(_DETAIL_CACHE.read_text(encoding="utf-8"))
            data = raw.get("items") if isinstance(raw, dict) else None
            if isinstance(data, dict):
                return {str(k): v for k, v in data.items() if isinstance(v, dict)}
    except Exception:
        pass
    return {}


def _save_detail_cache(cache: dict[str, dict[str, Any]], keep_ids: set[str] | None = None) -> None:
    """落盘详情缓存；keep_ids 用于剪掉已经下架的活动，避免文件无限增长。"""
    try:
        items = cache
        if keep_ids is not None:
            items = {k: v for k, v in cache.items() if k in keep_ids}
        _DETAIL_CACHE.parent.mkdir(parents=True, exist_ok=True)
        _DETAIL_CACHE.write_text(
            json.dumps({"saved_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "count": len(items), "items": items},
                       ensure_ascii=False),
            encoding="utf-8",
        )
    except Exception:
        pass


def _fmt(value: Any) -> str:
    from ..models import fmt_dt
    return fmt_dt(value)


def _mask(s: str) -> str:
    if not s:
        return ""
    return s[0] + "*" * max(0, len(s) - 2) + s[-1] if len(s) > 2 else "*" * len(s)


# --------------------------------------------------------------------------- #
# 学校列表 —— 登录前即可访问，无需任何鉴权
# --------------------------------------------------------------------------- #

_SCHOOLS_CACHE = DATA_DIR / "schools.json"
# 详情缓存落盘：列表接口很瘦，若重启后缓存清空，下一轮就会用空的简介/名额
# 覆盖掉库里已经补全好的数据。持久化后重启也能直接套用，不再丢字段。
_DETAIL_CACHE = DATA_DIR / "detail_cache.json"


async def fetch_all_schools(force: bool = False,
                            base_url: str = "https://win.9xueqi.com/api/app/client/v1/") -> list[dict[str, Any]]:
    """拉取全校列表（id = schoolId）。带本地缓存，避免反复请求对方服务器。"""
    if not force and _SCHOOLS_CACHE.exists():
        try:
            cached = json.loads(_SCHOOLS_CACHE.read_text(encoding="utf-8"))
            if cached.get("schools"):
                return cached["schools"]
        except Exception:
            pass

    url = base_url.rstrip("/") + "/common/all-school"
    async with httpx.AsyncClient(
        timeout=30,
        headers={"User-Agent": _UA, "Referer": "https://win.9xueqi.com/",
                 "Accept": "application/json, text/plain, */*"},
    ) as client:
        resp = await client.get(url)
        payload = resp.json()

    if payload.get("code") != CODE_OK:
        raise RuntimeError(payload.get("msg") or "获取学校列表失败")

    raw = payload.get("data") or []
    schools: list[dict[str, Any]] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "").strip().replace("\r", "").replace("\n", "")
        sid = item.get("id")
        if not name or sid in (None, ""):
            continue
        schools.append({
            "id": str(sid),
            "name": name,
            "first_letter": str(item.get("firstLetter") or "").strip(),
            "logo": str(item.get("logo") or ""),
            "system_name": str(item.get("systemName") or "").strip(),
            "nav_title": str(item.get("appWebsiteNavTitle") or "").strip(),
        })

    _SCHOOLS_CACHE.parent.mkdir(parents=True, exist_ok=True)
    _SCHOOLS_CACHE.write_text(
        json.dumps({"fetched_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "count": len(schools), "schools": schools},
                   ensure_ascii=False, indent=1),
        encoding="utf-8",
    )
    return schools


def search_schools(schools: list[dict[str, Any]], keyword: str = "",
                   limit: int = 40) -> list[dict[str, Any]]:
    kw = (keyword or "").strip()
    if not kw:
        return schools[:limit]
    hits = [s for s in schools if kw in s["name"]]
    if not hits:
        hits = [s for s in schools if kw.lower() in s["name"].lower()]
    hits.sort(key=lambda s: (not s["name"].startswith(kw), len(s["name"])))
    return hits[:limit]
