"""数据源适配器接口。

把「从哪里拿活动」抽象出来，便于：
  - 第一阶段用 demo 数据源直接跑通可视化界面；
  - 后续接入趣拓（9xueqi）真实接口；
  - 未来对接其他学校/厂商的二课系统只需新增一个适配器。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol

from ..models import Activity


@dataclass
class FetchResult:
    activities: list[Activity] = field(default_factory=list)
    ok: bool = True
    message: str = ""
    raw_count: int = 0
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class LoginResult:
    ok: bool
    message: str = ""
    display_name: str = ""
    profile_hint: dict[str, Any] = field(default_factory=dict)


class ActivitySource(Protocol):
    """所有数据源需实现的契约。"""

    name: str

    async def login(self, credential: dict[str, Any]) -> LoginResult:
        ...

    async def fetch_activities(self, *, pages: int = 3, page_size: int = 20) -> FetchResult:
        ...

    async def keepalive(self) -> LoginResult:
        ...

    def signup_url(self, activity: Activity) -> str:
        ...

    def status(self) -> dict[str, Any]:
        ...
