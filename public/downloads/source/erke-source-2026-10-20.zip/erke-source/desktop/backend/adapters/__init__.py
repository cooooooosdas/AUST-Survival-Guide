"""适配器集合。"""

from .base import ActivitySource, FetchResult, LoginResult

__all__ = ["ActivitySource", "FetchResult", "LoginResult"]
