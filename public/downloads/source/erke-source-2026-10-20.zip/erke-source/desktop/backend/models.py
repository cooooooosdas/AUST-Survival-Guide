"""领域模型：活动、用户画像、六类学时。"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field, asdict, fields as dataclass_fields
from datetime import datetime
from typing import Any, Iterable

# --------------------------------------------------------------------------- #
# 六类学时（第二课堂成绩单标准分类）
# --------------------------------------------------------------------------- #

CREDIT_TYPES: list[str] = [
    "思想政治引领",
    "精英锻炼养成",
    "综合素质拓展",
    "创新创业孵化",
    "社会责任担当",
    "实践能力培养",
]

# 各校 classifyName / 分类名 五花八门，这里做归一化映射。
_CREDIT_KEYWORDS: dict[str, tuple[str, ...]] = {
    "思想政治引领": (
        "思想政治", "思想引领", "思政", "党建", "党团", "红色", "理论", "理想信念",
        "道德修养", "法治", "形势政策", "青马", "团课", "主题教育",
    ),
    "精英锻炼养成": (
        # 注意：趣拓系统里写作「菁英锻炼养成」（菁，非精），两个写法都要能命中
        "精英", "菁英", "骨干", "养成", "领导力", "学生干部", "团学骨干", "培训班",
        "青马工程", "素质提升", "能力提升", "训练营",
    ),
    "综合素质拓展": (
        "综合素质", "文体", "文艺", "体育", "美育", "劳育", "心理", "社团", "艺术",
        "文化", "兴趣", "拓展", "健康", "道德", "人文",
    ),
    "创新创业孵化": (
        "创新创业", "创业", "创新", "孵化", "竞赛", "挑战杯", "互联网+", "创青春",
        "科研", "学术科技", "专利", "学科竞赛",
    ),
    "社会责任担当": (
        "社会责任", "志愿", "公益", "服务", "奉献", "帮扶", "支教", "无偿献血",
        "社会实践", "暑期实践", "三下乡", "社区服务", "义工",
    ),
    "实践能力培养": (
        "实践能力", "实践", "实习", "实训", "技能", "职业", "就业", "见习",
        "岗位", "调研", "劳动", "技能培训", "专业实践",
    ),
}

CREDIT_UNKNOWN = "未分类"

_CREDIT_ORDER = {name: i for i, name in enumerate(CREDIT_TYPES)}


def normalize_credit_type(raw: str | None) -> str:
    """把任意分类名归一化到六类之一，匹配不到则返回「未分类」。"""
    if not raw:
        return CREDIT_UNKNOWN
    text = str(raw).strip()
    if text in _CREDIT_ORDER:
        return text
    for canonical, kws in _CREDIT_KEYWORDS.items():
        for kw in kws:
            if kw in text:
                return canonical
    return CREDIT_UNKNOWN


def credit_sort_key(name: str) -> int:
    return _CREDIT_ORDER.get(name, len(CREDIT_TYPES))


# --------------------------------------------------------------------------- #
# 工具
# --------------------------------------------------------------------------- #

_DT_PATTERNS = [
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%d %H:%M",
    "%Y/%m/%d %H:%M:%S",
    "%Y/%m/%d %H:%M",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d",
    "%Y/%m/%d",
]


def parse_dt(value: Any) -> datetime | None:
    if value in (None, "", 0, "0"):
        return None
    if isinstance(value, (int, float)):
        ts = float(value)
        if ts > 1e12:
            ts /= 1000.0
        try:
            return datetime.fromtimestamp(ts)
        except Exception:
            return None
    text = str(value).strip()
    for p in _DT_PATTERNS:
        try:
            return datetime.strptime(text, p)
        except ValueError:
            continue
    m = re.search(r"(\d{4})\D(\d{1,2})\D(\d{1,2})", text)
    if m:
        try:
            return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except Exception:
            return None
    return None


def fmt_dt(value: Any) -> str:
    dt = parse_dt(value)
    return dt.strftime("%Y-%m-%d %H:%M") if dt else ("" if value in (None, "") else str(value))


def to_int(value: Any, default: int = 0) -> int:
    try:
        if value is None or value == "":
            return default
        return int(float(value))
    except Exception:
        return default


def digest_id(*parts: Any) -> str:
    h = hashlib.sha1()
    for p in parts:
        h.update(str(p or "").encode("utf-8"))
        h.update(b"\x1f")
    return h.hexdigest()[:20]


# --------------------------------------------------------------------------- #
# 活动
# --------------------------------------------------------------------------- #


@dataclass
class Activity:
    """一条二课活动。字段对齐需求中「必须展示的关键信息」。"""

    id: str
    title: str = ""
    intro: str = ""                 # 活动简介
    organizer: str = ""             # 组织方
    credit_type: str = CREDIT_UNKNOWN   # 归一化后的六类学时
    credit_type_raw: str = ""       # 系统原始分类名
    capacity: int = 0               # 可报人数
    enrolled: int = 0               # 已报名人数
    enroll_start: str = ""          # 报名开始时间
    enroll_end: str = ""            # 报名截止时间
    activity_start: str = ""        # 活动开始时间
    activity_end: str = ""          # 活动结束时间
    location: str = ""              # 活动地点
    hours: float = 0.0              # 该活动可获得的学时数
    grade_scope: list[str] = field(default_factory=list)
    college_scope: list[str] = field(default_factory=list)
    major_scope: list[str] = field(default_factory=list)
    # 参与组织（班级级限制）：详情 organizationList，如「制药25-1_2025」；空 = 不限班级
    org_scope: list[str] = field(default_factory=list)
    signup_url: str = ""            # 二课报名主页深链
    logo: str = ""
    status: str = ""
    first_seen: str = ""
    last_seen: str = ""
    is_new: bool = False
    match_score: float = 0.0
    match_reasons: list[str] = field(default_factory=list)
    # 硬性不符（年级/学院/专业/班级任一维度被拦），精选器据此直接排除
    hard_blocked: bool = False

    # -- 派生属性 ---------------------------------------------------------- #

    @property
    def seats_left(self) -> int:
        if self.capacity <= 0:
            return -1  # 不限人数
        return max(0, self.capacity - self.enrolled)

    @property
    def enroll_open(self) -> bool:
        now = datetime.now()
        s, e = parse_dt(self.enroll_start), parse_dt(self.enroll_end)
        if s and now < s:
            return False
        if e and now > e:
            return False
        return True

    @property
    def enroll_state(self) -> str:
        now = datetime.now()
        s, e = parse_dt(self.enroll_start), parse_dt(self.enroll_end)
        if s and now < s:
            return "upcoming"
        if e and now > e:
            return "closed"
        if not s and not e:
            return "unknown"
        return "open"

    @classmethod
    def from_dict(cls, d: dict[str, Any] | None) -> "Activity":
        """从 to_dict() 的输出（或任何含多余键的字典）还原 Activity。

        只取 dataclass 自己声明的字段，忽略 seats_left / enroll_state 之类的派生键，
        因此可以安全地「读库 -> 改几个字段 -> 写回」。
        """
        d = d or {}
        names = {f.name for f in dataclass_fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in names})

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d.update(
            seats_left=self.seats_left,
            enroll_state=self.enroll_state,
            credit_sort=credit_sort_key(self.credit_type),
            enroll_start_disp=fmt_dt(self.enroll_start),
            enroll_end_disp=fmt_dt(self.enroll_end),
            activity_start_disp=fmt_dt(self.activity_start),
        )
        return d


# --------------------------------------------------------------------------- #
# 用户画像
# --------------------------------------------------------------------------- #


@dataclass
class Profile:
    grade: str = ""           # 年级，如 "2024"
    college: str = ""         # 学院
    major: str = ""           # 专业
    clazz: str = ""           # 班级，如 "软件工程25-4"（对应学校系统里的学生所属组织）
    credit_types: list[str] = field(default_factory=list)   # 关注/需要的学时类型
    keywords_include: list[str] = field(default_factory=list)
    keywords_exclude: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict | None) -> "Profile":
        d = d or {}
        return cls(
            grade=str(d.get("grade") or ""),
            college=str(d.get("college") or ""),
            major=str(d.get("major") or ""),
            clazz=str(d.get("clazz") or d.get("className") or ""),
            credit_types=list(d.get("credit_types") or []),
            keywords_include=list(d.get("keywords_include") or []),
            keywords_exclude=list(d.get("keywords_exclude") or []),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# --------------------------------------------------------------------------- #
# 匹配
# --------------------------------------------------------------------------- #

_ALL_SCOPE_TOKENS = ("", "全校", "不限", "所有", "全体", "全部", "全校学生")


def _scope_hit(user_value: str, scopes: Iterable[str]) -> bool:
    """受限范围是否覆盖用户。空范围 = 不限。"""
    scopes = [str(s).strip() for s in (scopes or []) if str(s).strip()]
    if not scopes:
        return True
    if not user_value:
        return False
    u = user_value.strip()
    for s in scopes:
        if s in _ALL_SCOPE_TOKENS:
            return True
        if s == u or s in u or u in s:
            return True
    return False


_CLASS_YEAR_SUFFIX = re.compile(r"_\d{4}$")
_CLASS_BAN_SUFFIX = re.compile(r"班$")
_EDGE_CHAR = re.compile(r"[0-9a-z\-]")


def _norm_class(text: str) -> str:
    """班级名归一化：去空白、小写、去末尾「_入学年」「班」。"""
    s = str(text or "").strip().lower().replace(" ", "")
    s = _CLASS_YEAR_SUFFIX.sub("", s)
    return _CLASS_BAN_SUFFIX.sub("", s)


def _boundary_contains(hay: str, needle: str) -> bool:
    """边界感知包含：前后都不能是字母/数字/连字符。

    班级是精确概念，不能像院系那样宽松 contains ——
    「制药25-1」不能命中「制药25-11」，「软件工程」不能命中「软件工程25-4」。
    """
    if not needle or len(needle) > len(hay):
        return False
    idx = hay.find(needle)
    while idx >= 0:
        before_ok = idx == 0 or not _EDGE_CHAR.match(hay[idx - 1])
        after = idx + len(needle)
        after_ok = after >= len(hay) or not _EDGE_CHAR.match(hay[after])
        if before_ok and after_ok:
            return True
        idx = hay.find(needle, idx + 1)
    return False


def org_scope_hit(user_class: str, scopes: Iterable[str]) -> bool:
    """参与组织（班级级限制）命中判断。True = 在名单内或不限班级。"""
    scopes = [str(s).strip() for s in (scopes or []) if str(s).strip()]
    if not scopes:
        return True
    if any(s in _ALL_SCOPE_TOKENS for s in scopes):
        return True
    if not (user_class or "").strip():
        return False  # 没填班级 = 无法证明在名单内
    u = _norm_class(user_class)
    if not u:
        return False
    for s in scopes:
        n = _norm_class(s)
        if not n:
            continue
        if u == n or _boundary_contains(u, n) or _boundary_contains(n, u):
            return True
    return False


def _short_scopes(scopes: Iterable[str]) -> str:
    items = list(scopes)
    shown = items if len(items) <= 3 else items[:3] + ["…"]
    return "/".join(shown)


#: 学时加权的基准与上限。校内活动学时集中在 2~8 个，2 个是「入场价」，
#: 低于基准不给分，8 个封顶 +HOURS_MAX_BONUS —— 免得一门 8 学时讲座
#: 单纯靠学时把「学院/专业都不对口」的活动顶到前面。
HOURS_BASELINE = 2.0
HOURS_PER_UNIT = 2.0
HOURS_MAX_BONUS = 12.0


def hours_bonus(hours: float | int | None) -> float:
    """学时带来的加分：2 学时 0 分，每多 1 学时 +2 分，封顶 +12（8 学时）。"""
    try:
        h = float(hours or 0)
    except (TypeError, ValueError):
        return 0.0
    if h <= HOURS_BASELINE:
        return 0.0
    return round(min(HOURS_MAX_BONUS, (h - HOURS_BASELINE) * HOURS_PER_UNIT), 1)


def match_activity(act: Activity, profile: Profile) -> Activity:
    """按年级 / 学院 / 专业 / 班级 / 学时类型 / 学时数 / 关键词 打分并写入理由。

    打分口径（满分 100）：
      年级契合 +22 / 学院契合 +26（面向全校 +10）/ 专业契合 +20 / 班级契合 +18 /
      学时类型命中 +12 / 关键词命中 +4 / **学时加权 0~+12** / 名额紧张 +4
      硬性排除项（年级/学院/专业/班级 明确不覆盖）会把分数压到 0 以下并标记原因。

    「班级」对应学校系统的「参与组织」（详情 organizationList，如「制药25-1_2025」）：
    活动指定了班级时，只有名单内班级能报名，其他人服务端会直接拒绝。

    学时加权见 hours_bonus()：同等条件下学时越多分越高，
    但上限 12 分，压不过「学院/专业对口」这类硬指标。
    """
    reasons: list[str] = []
    score = 0.0
    blocked: list[str] = []
    scope_missed: list[str] = []   # 范围硬性不符（年级/学院/专业/班级）

    # 年级
    if not act.grade_scope or _scope_hit(profile.grade, act.grade_scope):
        if profile.grade:
            score += 22
            reasons.append("年级符合")
    else:
        blocked.append(f"限年级 {'/'.join(act.grade_scope)}")
        scope_missed.append("年级")

    # 学院
    if not act.college_scope or _scope_hit(profile.college, act.college_scope):
        if profile.college and act.college_scope:
            score += 26
            reasons.append("学院定向")
        elif not act.college_scope:
            score += 10
            reasons.append("面向全校")
    else:
        blocked.append(f"限学院 {'/'.join(act.college_scope)}")
        scope_missed.append("学院")

    # 专业
    if not act.major_scope or _scope_hit(profile.major, act.major_scope):
        if profile.major and act.major_scope:
            score += 20
            reasons.append("专业定向")
    else:
        blocked.append(f"限专业 {'/'.join(act.major_scope)}")
        scope_missed.append("专业")

    # 参与组织（班级级硬限制）
    if not act.org_scope or org_scope_hit(profile.clazz, act.org_scope):
        if profile.clazz.strip() and act.org_scope:
            score += 18
            reasons.append("班级定向")
    elif not profile.clazz.strip():
        blocked.append(f"限指定班级（{_short_scopes(act.org_scope)}），未填班级无法判断")
        scope_missed.append("班级")
    else:
        blocked.append(f"限班级 {_short_scopes(act.org_scope)}")
        scope_missed.append("班级")

    # 学时类型
    if profile.credit_types:
        if act.credit_type in profile.credit_types:
            score += 12
            reasons.append(f"命中关注学时：{act.credit_type}")
        else:
            score -= 5
            reasons.append(f"学时类型不在关注列表（{act.credit_type}）")

    # 关键词
    haystack = f"{act.title} {act.intro} {act.organizer}"
    for kw in profile.keywords_include:
        if kw and kw in haystack:
            score += 4
            reasons.append(f"关键词命中：{kw}")
            break
    for kw in profile.keywords_exclude:
        if kw and kw in haystack:
            score -= 40
            blocked.append(f"命中排除词：{kw}")

    # 学时加权：一次活动拿到的学时越多，性价比越高
    bonus = hours_bonus(act.hours)
    if bonus > 0:
        score += bonus
        reasons.append(f"{act.hours:g} 学时（+{bonus:g}）")

    if blocked:
        score = min(score, 0.0) - 10 * len(blocked)

    # 可报余量做轻微加权，让「还抢得到」的活动更靠前
    if act.seats_left == 0:
        score -= 10
        reasons.append("名额已满")
    elif 0 < act.seats_left <= 5:
        score += 4
        reasons.append("名额紧张")

    act.match_score = round(score, 1)
    act.match_reasons = blocked + reasons
    act.hard_blocked = bool(scope_missed)
    return act
