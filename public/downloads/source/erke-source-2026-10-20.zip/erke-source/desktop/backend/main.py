"""二课提醒小助手 —— 应用入口。

启动：
    python -m backend.main            # 或 python backend/main.py
    # 或使用 run.bat / run.sh
"""

from __future__ import annotations

import asyncio
import threading
import time
import webbrowser
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import api
from .db import Store
from .security import CredentialVault
from .services.engine import PollEngine
from .services.notify import Notifier
from .settings import FRONTEND_DIR, load_config, update_config

_STORE: Store | None = None
_VAULT: CredentialVault | None = None
_ENGINE: PollEngine | None = None


def _auto_select_adapter(store: Store, vault: CredentialVault) -> None:
    """已存凭据却还停在「演示数据」时，自动切到真实数据源。

    新用户装好后最容易卡在这一步：登录成功了，界面却还是演示活动，
    以为"没生效"。这里只在「有凭据 + 库里还没真实数据 + 配置仍是 demo」
    三个条件同时成立时切一次，不会覆盖用户后来的手动选择。
    """
    try:
        cfg = load_config()
        if (cfg.get("source") or {}).get("adapter", "demo") != "demo":
            return
        if not (vault.load() or {}).get("account"):
            return
        if store.has_real_activities():
            return
        update_config({"source": {"adapter": "xueqi9"}})
        store.purge_demo()
    except Exception:
        pass


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _STORE, _VAULT, _ENGINE
    _STORE = Store()
    _VAULT = CredentialVault()
    _auto_select_adapter(_STORE, _VAULT)
    _ENGINE = PollEngine(
        store=_STORE,
        vault=_VAULT,
        config_provider=load_config,
        notifier=Notifier(),
    )
    api.bind(_STORE, _VAULT, _ENGINE)
    await _ENGINE.start()
    try:
        yield
    finally:
        await _ENGINE.stop()
        _STORE.close()


app = FastAPI(title="二课提醒小助手", version="0.2.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    # 不要用 "http://127.0.0.1:*" 这种写法：CORS 的 origin 不支持端口通配，
    # 浏览器会整条规则判为不匹配。用正则才真正生效。
    allow_origin_regex=r"^http://(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$",
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(api.router)


@app.get("/health")
async def health() -> dict:
    return {"ok": True, "ts": int(time.time() * 1000)}


if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")

    @app.get("/")
    async def index() -> FileResponse:
        return FileResponse(str(FRONTEND_DIR / "index.html"))

    @app.get("/favicon.ico", include_in_schema=False)
    async def favicon():
        """浏览器默认会请求 /favicon.ico（不在 /static 下），单独给个路由。"""
        ico = FRONTEND_DIR / "favicon.ico"
        if ico.exists():
            return FileResponse(str(ico), media_type="image/x-icon")
        svg = FRONTEND_DIR / "assets" / "logo.svg"
        if svg.exists():
            return FileResponse(str(svg), media_type="image/svg+xml")
        return JSONResponse(status_code=404, content={"ok": False, "message": "no icon"})


@app.exception_handler(Exception)
async def unhandled(request, exc):  # noqa: ANN001
    return JSONResponse(status_code=500, content={"ok": False, "message": str(exc)})


def _open_browser_later(url: str, delay: float = 1.2) -> None:
    def _worker() -> None:
        time.sleep(delay)
        try:
            webbrowser.open(url)
        except Exception:
            pass
    threading.Thread(target=_worker, daemon=True).start()


def main() -> None:
    import uvicorn

    cfg = load_config()
    host = (cfg.get("app") or {}).get("host", "127.0.0.1")
    port = int((cfg.get("app") or {}).get("port", 8848))
    # 监听 0.0.0.0（局域网共享）时，浏览器无法访问 0.0.0.0，
    # 打印与自动打开都必须换成回环地址，否则用户会以为"服务没起来"。
    display_host = "127.0.0.1" if host in ("0.0.0.0", "::", "", None) else host
    url = f"http://{display_host}:{port}/"

    print("=" * 62)
    print("  二课提醒小助手  ·  已启动")
    print(f"  可视化界面： {url}")
    print(f"  接口文档：   {url}docs")
    if display_host != host:
        print(f"  局域网访问： http://<本机内网IP>:{port}/  （监听 {host}）")
    print("  数据目录：   ./data  （凭据以加密形式保存，可随时一键清除）")
    print("  按 Ctrl+C 退出")
    print("=" * 62)

    if (cfg.get("app") or {}).get("open_browser", True):
        _open_browser_later(url)

    try:
        uvicorn.run(app, host=host, port=port, log_level="info")
    except SystemExit:
        raise
    except OSError as exc:
        # 常见于「双击了两次」：端口已被前一个实例占用。
        # 打包成 exe 后窗口一闪就没了，这里停住把原因说清楚。
        print()
        print(f"[错误] 启动失败：{exc}")
        print(f"       多半是 {port} 端口已被占用（可能已经开着一个本工具）。")
        print(f"       可以直接用浏览器打开 {url} 看看；要重启请先关掉旧窗口。")
        try:
            input("按回车键退出…")
        except EOFError:
            pass
        raise SystemExit(1)


if __name__ == "__main__":
    main()
