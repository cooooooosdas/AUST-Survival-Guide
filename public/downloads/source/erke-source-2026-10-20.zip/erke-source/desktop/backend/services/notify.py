"""提醒通道（第二阶段能力，此处先打好接口与可用实现）。

已实现可直接使用的通道：
  * browser      —— 站内提醒（默认开启，界面角标 + 通知中心）
  * wecom_bot    —— 企业微信群机器人 Webhook（企业微信可转发到个人微信，最稳妥的「微信提醒」）
  * serverchan    —— Server 酱（微信服务号推送）
  * pushplus     —— PushPlus（微信公众号推送）
  * qq_bot       —— 预留：QQ 机器人框架（如 NapCat / OneBot）的 HTTP 接口
  * custom       —— 自定义 Webhook，任何 HTTP 端点

安全约定：通道密钥同样存放在加密保险箱里，不落明文。
"""

from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

import httpx

from ..models import Activity, fmt_dt

_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"\s+")


def _esc(text: Any) -> str:
    """HTML 转义（活动标题里可能出现 & < > "，不转义会撑坏邮件模板）。"""
    if text is None:
        return ""
    return (str(text).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def _plain(text: Any) -> str:
    """把富文本简介压成一行纯文本：去标签、还原常见实体、合并空白。"""
    if not text:
        return ""
    s = _TAG_RE.sub(" ", str(text))
    for a, b in (("&nbsp;", " "), ("&amp;", "&"), ("&lt;", "<"),
                 ("&gt;", ">"), ("&quot;", '"'), ("&#39;", "'")):
        s = s.replace(a, b)
    return _WS_RE.sub(" ", s).strip()


def snippet(text: Any, limit: int = 110) -> str:
    """摘取活动简介的前一小段，尽量在标点处收尾，避免「半句话」。

    真实数据里的简介 80~300 字，直接整段塞进邮件会把排版撑得很长，
    所以只取开头一段（默认 ~110 字），够让人判断「这活动跟我有没有关系」。
    """
    s = _plain(text)
    if len(s) <= limit:
        return s
    head = s[:limit]
    for sep in ("。", "；", "！", "？", ". ", "; ", "，", ", "):
        idx = head.rfind(sep)
        if idx >= limit * 0.5:
            return head[: idx + len(sep)].rstrip("，,；; ") + "…"
    return head.rstrip() + "…"


def hours_text(a: Activity) -> str:
    """学时展示：0 视为未标注。"""
    try:
        h = float(a.hours or 0)
    except (TypeError, ValueError):
        return ""
    if h <= 0:
        return ""
    return f"{h:g} 学时"


CHANNELS = [
    {"id": "browser", "label": "站内提醒", "need": [], "desc": "在本助手界面内提示，无需任何配置"},
    {"id": "wecom_bot", "label": "企业微信机器人", "need": ["webhook"],
     "desc": "企业微信 > 群机器人 > 添加 > 复制 Webhook 地址。企业微信可把消息推送到个人微信，是最稳的「微信提醒」"},
    {"id": "serverchan", "label": "Server 酱", "need": ["send_key"],
     "desc": "sct.ftqq.com 微信扫码登录后获取 SendKey，通过微信服务号推送"},
    {"id": "pushplus", "label": "PushPlus", "need": ["token"],
     "desc": "pushplus.plus 微信扫码登录后获取 token，通过微信公众号推送"},
    {"id": "qq_mail", "label": "QQ 邮箱", "need": ["smtp_user", "smtp_auth_code"],
     "desc": "推荐：不需要任何联系人或注册。用 QQ 邮箱发提醒邮件给自己，邮件里带「去报名」按钮。"
             "QQ邮箱 > 设置 > 账户 > 开启 SMTP 服务 > 生成授权码（填授权码，不是 QQ 密码）"},
    {"id": "qq_bot", "label": "QQ 机器人", "need": ["endpoint", "token", "target"],
     "desc": "进阶：填入 OneBot / NapCat 等框架的 HTTP 接口地址与目标群号，需本地运行机器人框架"},
    {"id": "custom", "label": "自定义 Webhook", "need": ["url"],
     "desc": "以 POST JSON 方式推送到任意 HTTP 端点"},
]


@dataclass
class NotifyResult:
    channel: str
    ok: bool
    message: str = ""


@dataclass
class Notifier:
    config: dict[str, Any] = field(default_factory=dict)
    _client: httpx.AsyncClient | None = None

    def enabled_channels(self) -> list[str]:
        return [c for c in (self.config.get("channels") or []) if c]

    def _cget(self, channel: str, key: str, default: Any = None) -> Any:
        """按通道命名空间取参数，兼容旧的扁平写法。

        键名在不同通道间会撞车（例如 PushPlus 和 QQ 机器人都有 token），
        所以前端统一存成 "<channel>.<key>"。
        """
        return (self.config.get(f"{channel}.{key}")
                or self.config.get(key)
                or default)

    async def _http(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=15, follow_redirects=True)
        return self._client

    # -- 文本渲染 ---------------------------------------------------------- #

    @staticmethod
    def _seats(a: Activity) -> str:
        return "不限" if a.capacity <= 0 else f"{a.seats_left}/{a.capacity}"

    @staticmethod
    def _enroll_window(a: Activity) -> str:
        s = fmt_dt(a.enroll_start) or "—"
        e = fmt_dt(a.enroll_end) or "—"
        return f"{s} ~ {e}"

    @staticmethod
    def subject(activities: list[Activity], mode: str = "new") -> str:
        """邮件主题。推荐模式下把首选活动名放进主题，打开率比「新活动 3 条」高。"""
        if mode == "recommend" and activities:
            head = activities[0].title
            head = head if len(head) <= 26 else head[:25] + "…"
            if len(activities) == 1:
                return f"【二课推荐】{head}"
            return f"【二课推荐】{head}（另 {len(activities) - 1} 条）"
        return f"二课新活动 {len(activities)} 条"

    @staticmethod
    def render_markdown(activities: list[Activity], limit: int = 8,
                        recommend: bool = False) -> str:
        from .curator import explain, tags

        head = ("### 二课推荐" if recommend else "### 二课新活动提醒") + f"（{len(activities)} 条）"
        lines = [head, f"> {datetime.now().strftime('%Y-%m-%d %H:%M')}", ""]
        for i, a in enumerate(activities[:limit]):
            h = hours_text(a)
            brief = snippet(a.intro, 90)
            mark = f"{i + 1}. " if recommend else ""
            badge = ("　" + " ".join(f"[{t}]" for t in tags(a))) if recommend else ""
            lines += [
                f"**{mark}{a.title}**{badge}",
                f"- 学时类型：{a.credit_type}" + (f"　可得 **{h}**" if h else ""),
                f"- 组织方：{a.organizer or '—'}",
                f"- 余量：{Notifier._seats(a)}　报名：{Notifier._enroll_window(a)}",
                f"- 时间地点：{fmt_dt(a.activity_start) or '—'}　{a.location or '—'}",
                (f"> {brief}" if brief else ""),
                (f"- **推荐理由**：{explain(a)}（{a.match_score} 分）" if recommend
                 else f"- 匹配：{'、'.join(a.match_reasons[:3]) or '—'}（{a.match_score} 分）"),
                f"- **直达报名**：[{a.title}]({a.signup_url})" if a.signup_url else "",
                "",
            ]
        if len(activities) > limit:
            lines.append(f"……另有 {len(activities) - limit} 条，请在助手中查看。")
        return "\n".join(x for x in lines if x)

    @staticmethod
    def render_plain(activities: list[Activity], limit: int = 8,
                     recommend: bool = False) -> str:
        """纯文本版：邮件客户端的降级显示，链接直接给裸 URL，方便复制。"""
        from .curator import explain

        head = ("二课推荐" if recommend else "二课新活动提醒") + f"（{len(activities)} 条）"
        lines = [head, datetime.now().strftime("%Y-%m-%d %H:%M"), ""]
        for i, a in enumerate(activities[:limit]):
            h = hours_text(a)
            brief = snippet(a.intro, 120)
            mark = f"{i + 1}. " if recommend else "· "
            lines += [
                f"{mark}{a.title}" + ("　【首选】" if recommend and i == 0 else ""),
                f"  学时类型：{a.credit_type}" + (f"（可得 {h}）" if h else ""),
                f"  组织方：{a.organizer or '—'}",
                f"  余量：{Notifier._seats(a)}",
                f"  报名时间：{Notifier._enroll_window(a)}",
                f"  活动时间：{fmt_dt(a.activity_start) or '—'}",
                f"  活动地点：{a.location or '—'}",
                (f"  推荐理由：{explain(a)}（{a.match_score} 分）" if recommend else ""),
                (f"  简介：{brief}" if brief else ""),
                f"  报名链接：{a.signup_url}",
                "",
            ]
        if len(activities) > limit:
            lines.append(f"……另有 {len(activities) - limit} 条，请在助手中查看。")
        lines.append("—— 二课提醒小助手")
        return "\n".join(x for x in lines if x)

    @staticmethod
    def render_html(activities: list[Activity], limit: int = 8,
                    recommend: bool = False, extra_new: int = 0) -> str:
        """HTML 版邮件。

        邮件客户端只认内联样式（很多会剥掉 <style> 和 class），
        所以这里全部写成 style="..."，并用 table 布局保证 QQ 邮箱 / 手机端一致。

        recommend=True 时切换成「精选推荐」版式：第 1 条打上「首选」标记、
        加一行推荐理由；extra_new 用于提示「本轮还有 N 条没入选」。
        """
        from .curator import explain, tags

        esc = _esc
        rows = []
        for idx, a in enumerate(activities[:limit]):
            seats = Notifier._seats(a)
            tight = a.capacity > 0 and a.seats_left <= 5
            htxt = hours_text(a)
            is_top = recommend and idx == 0
            # 学时徽标：和学时类型并排，一眼能看出「这条值不值」
            hours_chip = (
                f'<span style="display:inline-block;margin-left:6px;background:#e9f7ef;'
                f'color:#1a7f37;border-radius:4px;padding:1px 7px;font-size:12px;">'
                f'{esc(htxt)}</span>' if htxt else ""
            )
            brief = snippet(a.intro, recommend and 140 or 120)
            # 简介摘要：活动描述动辄两三百字，只摘开头一段，够判断要不要点进去
            brief_html = (
                f'<div style="margin-top:9px;padding:8px 11px;background:#f7f8fa;'
                f'border-left:3px solid #dfe3ea;font-size:12.5px;color:#4a515e;'
                f'line-height:1.75;">{esc(brief)}</div>' if brief else ""
            )
            # 推荐理由 + 角标（今天截止 / 只剩 N 个 / 学时丰厚）
            reason_html = ""
            extra_tags = ""
            if recommend:
                reason_html = (
                    f'<div style="margin-top:9px;font-size:12.5px;color:#2b5cff;">'
                    f'推荐理由：{esc(explain(a))}'
                    f'<span style="color:#8a919f;">（匹配 {a.match_score:g} 分）</span></div>'
                )
                extra_tags = "".join(
                    f'<span style="display:inline-block;margin-left:6px;background:#fff4e6;'
                    f'color:#b95c07;border-radius:4px;padding:1px 7px;font-size:12px;">'
                    f'{esc(t)}</span>' for t in tags(a)
                )
            rank_html = (
                f'<span style="display:inline-block;background:#2b5cff;color:#fff;'
                f'border-radius:4px;padding:1px 7px;font-size:12px;margin-right:6px;">'
                f'首选</span>' if is_top else
                (f'<span style="display:inline-block;background:#eef0f4;color:#5b6270;'
                 f'border-radius:4px;padding:1px 7px;font-size:12px;margin-right:6px;">'
                 f'{idx + 1}</span>' if recommend else "")
            )
            border = "1.5px solid #2b5cff" if is_top else "1px solid #e6e8ec"
            rows.append(f"""
      <tr><td style="padding:0 0 14px 0;">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0"
               style="border:{border};border-radius:10px;border-collapse:separate;">
          <tr><td style="padding:14px 16px;">
            <div style="font-size:15px;font-weight:600;color:#1a1d23;line-height:1.45;">
              {rank_html}{esc(a.title)}
            </div>
            <div style="margin-top:8px;font-size:13px;color:#5b6270;line-height:1.9;">
              <span style="display:inline-block;background:#eef4ff;color:#2b5cff;
                    border-radius:4px;padding:1px 7px;font-size:12px;">{esc(a.credit_type)}</span>{hours_chip}{extra_tags}
              <span style="margin-left:8px;">余量
                <b style="color:{'#d9480f' if tight else '#1a7f37'};">{esc(seats)}</b></span>
            </div>
            {reason_html}
            {brief_html}
            <div style="margin-top:6px;font-size:13px;color:#5b6270;line-height:1.9;">
              报名：{esc(Notifier._enroll_window(a))}<br/>
              时间：{esc(fmt_dt(a.activity_start) or '—')}　地点：{esc(a.location or '—')}<br/>
              组织方：{esc(a.organizer or '—')}
            </div>
            <div style="margin-top:12px;">
              <a href="{esc(a.signup_url)}"
                 style="display:inline-block;background:#2b5cff;color:#ffffff;text-decoration:none;
                        font-size:13px;padding:7px 16px;border-radius:6px;">去报名 →</a>
            </div>
          </td></tr>
        </table>
      </td></tr>""")

        more = ""
        if extra_new > 0:
            more = (f'<p style="margin:4px 0 0 0;font-size:13px;color:#8a919f;">'
                    f'本轮另有 {extra_new} 条新活动没入选（名额/时间/匹配度不占优），'
                    f'可在助手里看全量列表。</p>')
        elif len(activities) > limit:
            more = (f'<p style="margin:4px 0 0 0;font-size:13px;color:#8a919f;">'
                    f'另有 {len(activities) - limit} 条未列出，请打开助手查看。</p>')

        heading = (f"为你挑了 {len(activities)} 条" if recommend
                   else f"二课有 {len(activities)} 个新活动")
        sub = ("按你的年级 / 学院 / 专业筛过，分数最高的排在最前" if recommend
               else f"{datetime.now().strftime('%Y-%m-%d %H:%M')} · 二课提醒小助手")

        return f"""<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#f5f6f8;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0"
       style="background:#f5f6f8;padding:20px 12px;">
  <tr><td align="center">
    <table role="presentation" width="640" cellpadding="0" cellspacing="0"
           style="max-width:640px;background:#ffffff;border-radius:12px;
                  font-family:-apple-system,'PingFang SC','Microsoft YaHei',sans-serif;">
      <tr><td style="padding:22px 22px 6px 22px;">
        <div style="font-size:17px;font-weight:700;color:#1a1d23;">
          {heading}
        </div>
        <div style="margin-top:5px;font-size:12px;color:#8a919f;">
          {sub}
        </div>
      </td></tr>
      <tr><td style="padding:16px 22px 8px 22px;">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
          {''.join(rows)}
        </table>
        {more}
      </td></tr>
      <tr><td style="padding:10px 22px 22px 22px;font-size:12px;color:#a0a6b1;line-height:1.7;">
        本邮件由本地运行的小助手发送，仅你本人可见。<br/>
        报名动作请在上方链接里自行完成，本工具不代你抢名额。
      </td></tr>
    </table>
  </td></tr>
</table>
</body></html>"""

    # -- 分发 -------------------------------------------------------------- #

    async def dispatch(self, activities: list[Activity], *,
                       mode: str = "new", extra_new: int = 0) -> list[NotifyResult]:
        if not activities:
            return []
        results: list[NotifyResult] = []
        for ch in self.enabled_channels():
            try:
                results.append(await self._send_one(ch, activities, mode=mode, extra_new=extra_new))
            except Exception as exc:  # 单个通道失败不影响其他通道
                results.append(NotifyResult(ch, False, str(exc)))
        return results

    async def _send_one(self, channel: str, activities: list[Activity],
                        *, mode: str = "new", extra_new: int = 0) -> NotifyResult:
        conf = self.config or {}
        recommend = mode == "recommend"
        title = self.subject(activities, mode)
        md = self.render_markdown(activities, recommend=recommend)
        plain = self.render_plain(activities, recommend=recommend)
        client = await self._http()

        if channel == "browser":
            return NotifyResult(channel, True, "已写入站内通知中心")

        if channel == "wecom_bot":
            url = self._cget(channel, "webhook") or ""
            if not url:
                return NotifyResult(channel, False, "未配置 Webhook")
            body = {"msgtype": "markdown", "markdown": {"content": md[:4000]}}
            r = await client.post(url, json=body)
            return NotifyResult(channel, r.status_code == 200, f"HTTP {r.status_code}")

        if channel == "serverchan":
            key = self._cget(channel, "send_key") or ""
            if not key:
                return NotifyResult(channel, False, "未配置 SendKey")
            r = await client.post(
                f"https://sctapi.ftqq.com/{key}.send",
                data={"title": title, "desp": md[:30000]},
            )
            return NotifyResult(channel, r.status_code == 200, f"HTTP {r.status_code}")

        if channel == "pushplus":
            token = self._cget(channel, "token") or ""
            if not token:
                return NotifyResult(channel, False, "未配置 token")
            r = await client.post(
                "https://www.pushplus.plus/send",
                json={"token": token, "title": title, "content": md, "template": "markdown"},
            )
            return NotifyResult(channel, r.status_code == 200, f"HTTP {r.status_code}")

        if channel == "qq_mail":
            user = self._cget(channel, "smtp_user") or ""
            auth = self._cget(channel, "smtp_auth_code") or ""
            to = self._cget(channel, "to") or user
            if not user or not auth:
                return NotifyResult(channel, False, "未配置 QQ 邮箱或 SMTP 授权码")
            host = self._cget(channel, "smtp_host") or ("smtp.qq.com" if "qq.com" in user.lower()
                                             else "smtp.exmail.qq.com")
            html = self.render_html(activities, recommend=recommend, extra_new=extra_new)
            ok, msg = await asyncio.get_running_loop().run_in_executor(
                None, _smtp_send, host, user, auth, to, title, plain, html
            )
            return NotifyResult(channel, ok, msg)

        if channel == "qq_bot":
            endpoint = self._cget(channel, "endpoint") or ""
            target = self._cget(channel, "target") or ""
            if not endpoint:
                return NotifyResult(channel, False, "未配置接口地址")
            headers = {}
            if self._cget(channel, "token"):
                headers["Authorization"] = f"Bearer {conf['token']}"
            r = await client.post(
                endpoint, headers=headers,
                json={"action": "send_group_msg", "params": {"group_id": target, "message": plain}},
            )
            return NotifyResult(channel, r.status_code == 200, f"HTTP {r.status_code}")

        if channel == "custom":
            url = self._cget(channel, "url") or ""
            if not url:
                return NotifyResult(channel, False, "未配置 URL")
            r = await client.post(url, json={
                "title": title, "text": plain, "markdown": md,
                "count": len(activities),
                "activities": [a.to_dict() for a in activities[:20]],
            })
            return NotifyResult(channel, r.status_code == 200, f"HTTP {r.status_code}")

        return NotifyResult(channel, False, "未知通道")

    async def aclose(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()


def _smtp_send(host: str, user: str, auth: str, to: str,
               subject: str, body: str, html: str | None = None) -> tuple[bool, str]:
    """在阻塞线程里发一封邮件（QQ 邮箱走 465 SSL）。

    用 multipart/alternative 同时带上纯文本与 HTML 两份：
    支持 HTML 的客户端（QQ 邮箱、手机 QQ）显示带按钮的排版，
    不支持的就退化成纯文本 —— 两个版本都带完整报名链接。
    """
    import smtplib
    from email.header import Header
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.utils import formataddr, formatdate, make_msgid

    if html:
        msg = MIMEMultipart("alternative")
        msg.attach(MIMEText(body, "plain", "utf-8"))
        msg.attach(MIMEText(html, "html", "utf-8"))
    else:
        msg = MIMEText(body, "plain", "utf-8")

    msg["Subject"] = Header(subject, "utf-8")
    msg["From"] = formataddr(("二课提醒小助手", user))
    msg["To"] = to
    msg["Date"] = formatdate(localtime=True)
    msg["Message-ID"] = make_msgid(domain="erke-helper.local")

    def _deliver(via_tls: bool) -> None:
        if via_tls:
            # 587 + STARTTLS：465 被网络挡掉时的退路（QQ 邮箱两种都支持）
            with smtplib.SMTP(host, 587, timeout=20) as server:
                server.starttls()
                server.login(user, auth)
                server.sendmail(user, [to], msg.as_string())
        else:
            with smtplib.SMTP_SSL(host, 465, timeout=20) as server:
                server.login(user, auth)
                server.sendmail(user, [to], msg.as_string())

    try:
        try:
            _deliver(via_tls=False)
        except smtplib.SMTPAuthenticationError:
            raise
        except (OSError, smtplib.SMTPConnectError, smtplib.SMTPServerDisconnected):
            # 连不上/被断：换 587 再试一次，失败才向上报错
            _deliver(via_tls=True)
        return True, f"已发送至 {to}"
    except smtplib.SMTPAuthenticationError:
        return False, ("SMTP 认证失败：请确认填的是「授权码」而不是 QQ 密码，"
                       "且已在 QQ邮箱→设置→账户 里开启 SMTP 服务")
    except smtplib.SMTPException as exc:
        return False, f"SMTP 错误：{exc}"
    except Exception as exc:
        return False, f"发送失败：{exc}"


async def test_channel(channel: str, config: dict[str, Any]) -> NotifyResult:
    """给界面上的「测试通道」按钮用。"""
    from ..models import CREDIT_TYPES
    demo = Activity(
        id="test",
        title="【测试】提醒通道连通性检查",
        intro="这是一条测试消息。收到它说明提醒通道已经配好，之后有新活动就会按这个格式发给你。",
        organizer="二课提醒小助手",
        credit_type=CREDIT_TYPES[2],
        capacity=100, enrolled=1,
        enroll_start=datetime.now().strftime("%Y-%m-%d %H:%M"),
        enroll_end=datetime.now().strftime("%Y-%m-%d %H:%M"),
        activity_start=datetime.now().strftime("%Y-%m-%d %H:%M"),
        location="本机",
        hours=4.0,
        signup_url="https://win.9xueqi.com/#/actList",
        match_score=99.0,
        match_reasons=["这是一条测试消息", "通道连通性检查"],
    )
    return await Notifier(config=config)._send_one(channel, [demo])
