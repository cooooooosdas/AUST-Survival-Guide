"""匹配引擎：把「用户画像」与「活动」对上。"""

from __future__ import annotations

from collections import Counter
from typing import Any

from ..models import Activity, Profile, match_activity


def apply_matching(activities: list[Activity], profile: Profile,
                   only_positive: bool = False) -> list[Activity]:
    for act in activities:
        match_activity(act, profile)
    if only_positive:
        activities = [a for a in activities if a.match_score > 0]
    activities.sort(key=lambda a: (-a.match_score, a.enroll_end or "9999"))
    return activities


def summarize(activities: list[Activity], profile: Profile,
              min_score: float = 0.0) -> dict[str, Any]:
    """给界面用的汇总信息。

    口径：基数只算**可报**的活动 —— 年级 / 学院 / 专业 / 班级（参与组织）不符的，
    报了也会被学校系统拒绝，不该进总数，也不该进「报名中 / 匹配」。
    「匹配」按推送门槛 min_score 判定，不再用 score > 0（那样几乎人人命中，
    会和「总数」「报名中」恒等）。
    """
    by_type: Counter[str] = Counter()
    open_cnt = new_cnt = matched = full_cnt = blocked = 0
    total = 0
    for a in activities:
        if a.hard_blocked:
            blocked += 1
            continue
        total += 1
        by_type[a.credit_type] += 1
        if a.enroll_state == "open":
            open_cnt += 1
        if a.is_new:
            new_cnt += 1
        if a.match_score >= min_score:
            matched += 1
        if a.capacity > 0 and a.seats_left == 0:
            full_cnt += 1
    return {
        "total": total,
        "open": open_cnt,
        "new": new_cnt,
        "matched": matched,
        "full": full_cnt,
        "blocked": blocked,
        "by_credit_type": dict(by_type),
        "profile": profile.to_dict(),
    }


def eligible(activities: list[Activity]) -> list[Activity]:
    """可报列表：先剔除不在报名范围的，再按匹配分降序。

    统计、列表、推荐三处都基于它，避免各说各话
    （也就是「匹配 9 个，刷新一下变 46 个」那类跳变）。
    """
    out = [a for a in activities if not a.hard_blocked]
    out.sort(key=lambda a: (-a.match_score, -(a.hours or 0.0), a.enroll_end or "9999"))
    return out
