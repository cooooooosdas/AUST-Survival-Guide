"""「推哪一条」—— 从一整库活动里挑出此刻最值得告诉他的一两条。

分工：`notify` 只管**怎么发**（排版、通道、SMTP），`curator` 只管**发什么**。

口径（按优先级）：

1. **够格**：匹配分 ≥ 阈值；报名未截止（报名中/未开始）；不是已满员；
   距离报名截止还剩 ≥ `MIN_ACTIONABLE_MINUTES` 分钟（剩 10 分钟才推等于没推）；
   详情补全过（没简介没名额的「瘦数据」判断不了值不值得）。
2. **去重**：同一个活动名（去掉标点空格后相同）只留分数最高的一条 ——
   二课经常把同一场活动按「选手通道 / 观众通道」拆成多条。
3. **排序**：匹配分降序 → 学时多的在前 → 报名截止早的在前。
   分数是用户自己定的「最优先」，学时不压过分；截止时间只做同分时的次序。
4. **限量**：最多 3 条，第 1 条就是「首选」。宁缺毋滥 ——
   够格的不足 3 条就只发 1 条，一条都没有就**不发信**。
5. **不重复推**：推过的 id 记在库里（`recommended_ledger`），
   下次不再推，除非用户手动重发。
"""

from __future__ import annotations

import re
from datetime import datetime
from typing import Iterable

from ..models import Activity, parse_dt

DEFAULT_LIMIT = 3
DEFAULT_MIN_SCORE = 35.0

#: 距离报名截止不足这么多分钟的，直接不推 —— 看到了也来不及操作
MIN_ACTIONABLE_MINUTES = 30
#: 剩余时间少于这么多小时，邮件里打「今天截止」标记
URGENT_HOURS = 24

_ELIGIBLE_STATES = ("open", "upcoming")
_TITLE_NOISE = re.compile(r"[\s·\-—_（）()【】\[\]“”\"'，,。.!！?？、:：]+")
_BRACKETS = re.compile(r"[（(【\[][^）)】\]]*[）)】\]]")


def _norm_title(title: str) -> str:
    return _TITLE_NOISE.sub("", (title or "")).lower()


def _base_title(title: str) -> str:
    """去掉括号里的「（选手通道）/（观众通道）/（第二期）」后再比，
    这样同一场活动拆成多个通道时只会留一条。"""
    return _norm_title(_BRACKETS.sub("", title or ""))


def _minutes_left(act: Activity, now: datetime) -> float | None:
    """距报名截止还有多少分钟；没有截止时间返回 None（视为不限时）。"""
    end = parse_dt(act.enroll_end)
    if not end:
        return None
    return (end - now).total_seconds() / 60.0


def reject_reason(act: Activity, *, min_score: float = DEFAULT_MIN_SCORE,
                  now: datetime | None = None) -> str:
    """不合格就返回原因（便于排查「为什么这条没被推」），合格返回空串。"""
    now = now or datetime.now()

    # 范围硬性不符（年级/学院/专业/班级任一被拦）：报了也过不了服务端校验
    if act.hard_blocked:
        miss = [r for r in act.match_reasons if r.startswith("限")]
        return f"不在报名范围：{miss[0]}" if miss else "不在报名范围"

    if act.enroll_state == "closed":
        return "报名已截止"
    if act.enroll_state not in _ELIGIBLE_STATES:
        return "报名状态未知"
    if act.capacity > 0 and act.seats_left <= 0:
        return "名额已满"
    if act.match_score < min_score:
        return f"匹配分 {act.match_score:g} 低于阈值 {min_score:g}"
    if not act.intro and not act.capacity:
        return "详情未补全，无法判断"
    left = _minutes_left(act, now)
    if left is not None and left < MIN_ACTIONABLE_MINUTES:
        return f"距截止仅剩 {int(left)} 分钟"
    act_end = parse_dt(act.activity_end) or parse_dt(act.activity_start)
    if act_end and act_end < now:
        return "活动已结束"
    return ""


def _is_urgent(act: Activity, now: datetime) -> bool:
    left = _minutes_left(act, now)
    return left is not None and 0 <= left <= URGENT_HOURS * 60


def _sort_key(act: Activity) -> tuple:
    end = parse_dt(act.enroll_end) or datetime.max
    return (-act.match_score, -float(act.hours or 0), end)


def pick(activities: Iterable[Activity], *,
         limit: int = DEFAULT_LIMIT,
         min_score: float = DEFAULT_MIN_SCORE,
         exclude_ids: Iterable[str] | None = None,
         now: datetime | None = None) -> list[Activity]:
    """挑出最多 limit 条最值得推荐的，第 1 条即首选。"""
    now = now or datetime.now()
    skip = {str(i) for i in (exclude_ids or ())}

    pool = [a for a in activities
            if str(a.id) not in skip and not reject_reason(a, min_score=min_score, now=now)]
    pool.sort(key=_sort_key)

    # 去过重：同一场活动可能被拆成「选手通道 / 观众通道」多条，只保留最优的那条
    # （同分同时学时，优先留标题更短的 —— 通常就是不带通道后缀的原版）
    def _pref(a: Activity) -> tuple:
        return (a.match_score, float(a.hours or 0), -len(a.title or ""))

    best: dict[str, Activity] = {}
    for a in pool:
        key = _base_title(a.title)
        cur = best.get(key)
        if cur is None or _pref(a) > _pref(cur):
            best[key] = a
    cands = sorted(best.values(), key=_sort_key)
    return cands[: max(1, limit)]


def explain(act: Activity, *, now: datetime | None = None) -> str:
    """一句话说明「凭什么推它」，用于邮件里那行推荐理由。"""
    now = now or datetime.now()
    bits = [r for r in (act.match_reasons or [])
            if r and not re.search(r"限|排除|已满|不在|低于", r)]
    parts = bits[:3]
    # 学时加权的理由（「8 学时（+12）」）已经在 bits 里了，别再重复补一个「8 学时」
    if act.hours and not any("学时" in p for p in parts):
        parts.append(f"{act.hours:g} 学时")
    return " · ".join(parts) or "符合你的年级/学院条件"


def tags(act: Activity, *, now: datetime | None = None) -> list[str]:
    """邮件/界面上那几个小角标。"""
    now = now or datetime.now()
    out: list[str] = []
    if _is_urgent(act, now):
        out.append("今天截止")
    if act.capacity > 0 and 0 < act.seats_left <= 5:
        out.append(f"只剩 {act.seats_left} 个名额")
    if float(act.hours or 0) >= 5:
        out.append(f"{act.hours:g} 学时")
    if act.enroll_state == "upcoming":
        out.append("还未开始报名")
    return out


def ledger_add(store, ids: Iterable[str]) -> dict[str, str]:
    """把推过的活动记进台账（id -> 推送时间），保留最近 500 条。"""
    ledger: dict[str, str] = dict(store.get_meta("recommended_ledger", {}) or {})
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for i in ids:
        ledger[str(i)] = ts
    if len(ledger) > 500:
        keep = sorted(ledger.items(), key=lambda kv: kv[1], reverse=True)[:500]
        ledger = dict(keep)
    store.set_meta("recommended_ledger", ledger)
    return ledger


def ledger_ids(store) -> list[str]:
    return list((store.get_meta("recommended_ledger", {}) or {}).keys())


def ledger_clear(store) -> None:
    store.set_meta("recommended_ledger", {})
