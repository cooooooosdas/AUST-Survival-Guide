"""轮询引擎 —— 持续检索的稳定性核心。

需求中特别点名的问题：「每日多次检索可能引发的账号重登问题」。
这里用四层机制来兜住：

  1. 会话保活（keepalive）—— 每轮先做一次轻量请求，会话没过期就完全不重新登录，
     把登录次数压到最低，避免触发系统的异地/频繁登录风控。
  2. 失效即重登（auto relogin）—— 一旦业务码 10001 出现，立即静默重登一次并
     继续本轮检索，用户无感知。
  3. 登录节流（login cooldown）—— 连续登录失败时进入冷却，最小重试间隔递增
     （60s → 2min → 5min …），杜绝「密码错一次就疯狂重试把账号打锁」。
  4. 退避 + 抖动（backoff + jitter）—— 请求失败按指数退避，且每轮唤醒时间加随机
     抖动，使请求落点分散，不形成规律性高频特征。
"""

from __future__ import annotations

import asyncio
import json
import random
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from typing import Any, Callable

from ..adapters.demo import DemoSource
from ..adapters.xueqi9 import SessionExpired, Xueqi9Source
from ..db import Store
from ..models import Activity, Profile, fmt_dt
from ..security import CredentialVault
from ..settings import PollSettings, RecommendSettings, SourceSettings
from . import curator
from .matcher import apply_matching
from .notify import Notifier, NotifyResult


@dataclass
class EngineState:
    running: bool = False
    adapter: str = "demo"
    logged_in: bool = False
    display_name: str = ""
    last_run_at: str = ""
    next_run_at: str = ""
    last_status: str = "idle"
    last_message: str = ""
    consecutive_failures: int = 0
    relogin_count: int = 0
    login_count: int = 0
    total_runs: int = 0
    last_new_count: int = 0
    last_total: int = 0
    interval_minutes: int = 30
    backoff_seconds: int = 0
    paused: bool = False
    last_error: str = ""
    last_recommend_at: str = ""
    last_recommend: list[dict[str, Any]] = field(default_factory=list)
    recent_events: list[dict[str, Any]] = field(default_factory=list)


_LOGIN_COOLDOWN_STEPS = [60, 120, 300, 900, 1800]


class PollEngine:
    def __init__(
        self,
        store: Store,
        vault: CredentialVault,
        config_provider: Callable[[], dict[str, Any]],
        notifier: Notifier | None = None,
    ) -> None:
        self.store = store
        self.vault = vault
        self.config_provider = config_provider
        self.notifier = notifier or Notifier()
        self.state = EngineState()
        self._adapter: Any = None
        self._task: asyncio.Task | None = None
        self._wake = asyncio.Event()
        self._poll_lock = asyncio.Lock()
        self._login_fail_streak = 0
        self._login_cooldown_until = 0.0
        self._next_run_monotonic = 0.0

    # ------------------------------------------------------------------ #
    # 配置读取
    # ------------------------------------------------------------------ #

    @property
    def cfg(self) -> dict[str, Any]:
        return self.config_provider() or {}

    @property
    def poll_cfg(self) -> PollSettings:
        return PollSettings.from_dict(self.cfg.get("poll") or {})

    @property
    def source_cfg(self) -> SourceSettings:
        return SourceSettings.from_dict(self.cfg.get("source") or {})

    @property
    def profile(self) -> Profile:
        return Profile.from_dict(self.cfg.get("profile") or {})

    @property
    def recommend_cfg(self) -> RecommendSettings:
        return RecommendSettings.from_dict(self.cfg.get("recommend") or {})

    # ------------------------------------------------------------------ #
    # 适配器
    # ------------------------------------------------------------------ #

    def build_adapter(self) -> Any:
        sc = self.source_cfg
        if sc.adapter == "xueqi9":
            self._adapter = Xueqi9Source(sc)
        else:
            self._adapter = DemoSource(sc)
        self.state.adapter = self._adapter.name
        return self._adapter

    @property
    def adapter(self) -> Any:
        if self._adapter is None:
            self.build_adapter()
        return self._adapter

    def reload_adapter(self) -> None:
        """配置变更（如切换数据源）后重建适配器。"""
        self._adapter = None
        self.state.logged_in = False
        self.build_adapter()

    # ------------------------------------------------------------------ #
    # 生命周期
    # ------------------------------------------------------------------ #

    async def start(self) -> None:
        if self.state.running:
            return
        self.state.running = True
        self.state.paused = False
        self.build_adapter()
        self._schedule_next(delay_seconds=3)
        self._task = asyncio.create_task(self._loop(), name="poll-engine")
        self._emit("engine", "轮询引擎已启动")

    async def stop(self) -> None:
        self.state.running = False
        self._wake.set()
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass
            self._task = None
        if self._adapter is not None and hasattr(self._adapter, "aclose"):
            try:
                await self._adapter.aclose()
            except Exception:
                pass
        if self.notifier:
            await self.notifier.aclose()
        self._emit("engine", "轮询引擎已停止")

    def _emit(self, kind: str, message: str, **extra: Any) -> None:
        evt = {"ts": datetime.now().strftime("%H:%M:%S"), "kind": kind, "message": message}
        evt.update(extra)
        self.state.recent_events.insert(0, evt)
        del self.state.recent_events[60:]

    # ------------------------------------------------------------------ #
    # 调度
    # ------------------------------------------------------------------ #

    def _schedule_next(self, delay_seconds: float | None = None) -> None:
        pc = self.poll_cfg
        if delay_seconds is None:
            base = max(1, pc.interval_minutes) * 60
            jitter = random.uniform(0, max(0, pc.jitter_seconds))
            delay_seconds = base + jitter
        self._next_run_monotonic = time.monotonic() + max(5.0, delay_seconds)
        self.state.interval_minutes = pc.interval_minutes
        eta = datetime.now() + timedelta(seconds=max(5.0, delay_seconds))
        self.state.next_run_at = eta.strftime("%Y-%m-%d %H:%M:%S")

    def _in_quiet_hours(self) -> bool:
        windows = self.poll_cfg.quiet_hours or []
        now = datetime.now().time()
        for w in windows:
            try:
                a, b = w.split("-")
                ah, am = [int(x) for x in a.strip().split(":")]
                bh, bm = [int(x) for x in b.strip().split(":")]
                start = ah * 60 + am
                end = bh * 60 + bm
                cur = now.hour * 60 + now.minute
                if start <= end:
                    if start <= cur < end:
                        return True
                else:  # 跨零点，如 22:00-06:30
                    if cur >= start or cur < end:
                        return True
            except Exception:
                continue
        return False

    def _seconds_until_quiet_end(self) -> int:
        windows = self.poll_cfg.quiet_hours or []
        now = datetime.now()
        for w in windows:
            try:
                b = w.split("-")[1].strip()
                bh, bm = [int(x) for x in b.split(":")]
                end = now.replace(hour=bh, minute=bm, second=0, microsecond=0)
                if end <= now:
                    end += timedelta(days=1)
                return int((end - now).total_seconds())
            except Exception:
                continue
        return 3600

    async def _loop(self) -> None:
        while self.state.running:
            try:
                now = time.monotonic()
                due = now >= self._next_run_monotonic
                if due and not self.state.paused:
                    if self._in_quiet_hours() and self._has_any_data():
                        wait = self._seconds_until_quiet_end()
                        self._emit("skip", f"处于免打扰时段，{wait // 60} 分钟后恢复")
                        self._schedule_next(delay_seconds=wait)
                    elif self._in_quiet_hours():
                        # 首次启动恰好落在免打扰时段：库里一条都没有，
                        # 此时"守规矩不抓"只会让新用户看到一个空白页面。
                        # 所以照抓一轮，但把推送关掉（半夜别发邮件）。
                        self._emit("poll", "首次启动且本地无数据，先抓一轮（本次不发提醒）")
                        await self.poll_now(trigger="startup", notify=False)
                    else:
                        await self.poll_now(trigger="auto")
                # 20s 粒度轮询，兼顾「立即刷新」的响应速度与开销
                self._wake.clear()
                try:
                    await asyncio.wait_for(self._wake.wait(), timeout=20)
                except asyncio.TimeoutError:
                    pass
            except asyncio.CancelledError:
                break
            except Exception as exc:
                self._emit("error", f"调度循环异常：{exc}")
                await asyncio.sleep(10)

    def request_wake(self) -> None:
        """外部触发立即执行（配合 poll_now 使用）。"""
        self._wake.set()

    def set_paused(self, paused: bool) -> None:
        self.state.paused = paused
        self._emit("engine", "已暂停自动检索" if paused else "已恢复自动检索")
        if not paused:
            self._schedule_next(delay_seconds=5)

    # ------------------------------------------------------------------ #
    # 登录
    # ------------------------------------------------------------------ #

    def _credentials(self) -> dict[str, Any] | None:
        try:
            return self.vault.load()
        except Exception:
            return None

    async def ensure_login(self, force: bool = False) -> tuple[bool, str]:
        ad = self.adapter
        if ad.name == "demo":
            if not self.state.logged_in:
                res = await ad.login({"account": "演示同学"})
                self.state.logged_in = res.ok
                self.state.display_name = res.display_name
            return True, "演示模式"

        if self.state.logged_in and not force:
            return True, "会话有效"

        now = time.monotonic()
        if now < self._login_cooldown_until:
            wait = int(self._login_cooldown_until - now)
            return False, f"登录冷却中，{wait} 秒后重试"

        cred = self._credentials()
        if not cred or not cred.get("account") or not cred.get("password"):
            self.state.logged_in = False
            self.state.last_error = "尚未配置账号密码"
            return False, "尚未配置账号密码"

        # 学校 ID 以凭据里的为准，回填到运行时配置
        if cred.get("schoolId"):
            self.source_cfg.school_id = str(cred["schoolId"])

        res = await ad.login(cred)
        if res.ok:
            self.state.logged_in = True
            self.state.display_name = res.display_name or cred.get("account", "")
            self.state.login_count = getattr(ad, "login_count", self.state.login_count + 1)
            self._login_fail_streak = 0
            self._login_cooldown_until = 0.0
            self._emit("login", f"登录成功（第 {self.state.login_count} 次）")
            if cred.get("profileHint"):
                try:
                    self.store.set_meta("profile_hint", cred["profileHint"])
                except Exception:
                    pass
            return True, "登录成功"

        self._login_fail_streak += 1
        step = _LOGIN_COOLDOWN_STEPS[min(self._login_fail_streak - 1, len(_LOGIN_COOLDOWN_STEPS) - 1)]
        self._login_cooldown_until = time.monotonic() + step
        self.state.logged_in = False
        self.state.last_error = res.message
        self._emit("login_fail", f"登录失败：{res.message}（{step}s 后重试）")
        return False, res.message

    # ------------------------------------------------------------------ #
    # 单轮检索
    # ------------------------------------------------------------------ #

    def _has_any_data(self) -> bool:
        """本地库里是否已有活动 —— 用来判断是不是「装好后第一次启动」。"""
        try:
            return int(self.store.stats().get("total", 0)) > 0
        except Exception:
            return True

    async def poll_now(self, trigger: str = "manual", *, notify: bool = True) -> dict[str, Any]:
        """执行一次完整检索。trigger ∈ {auto, manual, startup}

        notify=False 时照常抓取入库，但不触发任何推送（免打扰时段的首轮用）。
        """
        if self._poll_lock.locked():
            return {"ok": False, "message": "上一轮检索尚未结束"}

        async with self._poll_lock:
            started = time.monotonic()
            self.state.total_runs += 1
            self.state.last_run_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self._emit("poll", f"{'自动' if trigger == 'auto' else '手动'}检索开始")

            ok, msg = await self.ensure_login(force=False)
            if not ok:
                return self._finish("login_failed", msg, 0, 0, started, retry_after=120)

            pc = self.poll_cfg
            result = await self.adapter.fetch_activities(
                pages=pc.max_pages, page_size=pc.page_size
            )

            # 命中会话失效 —— 静默重登一次后重试（用户无感知）
            if not result.ok and ("10001" in (result.message or "") or
                                  "会话" in (result.message or "") or
                                  "登陆" in (result.message or "")):
                self.state.relogin_count += 1
                self._emit("relogin", f"检测到会话失效，正在静默重登（累计 {self.state.relogin_count} 次）")
                ok2, _ = await self.ensure_login(force=True)
                if ok2:
                    result = await self.adapter.fetch_activities(
                        pages=pc.max_pages, page_size=pc.page_size
                    )

            if not result.ok:
                self.state.consecutive_failures += 1
                backoff = min(300 * (2 ** (self.state.consecutive_failures - 1)), 1800)
                backoff = int(backoff * random.uniform(0.9, 1.15))
                return self._finish("failed", result.message, 0, 0, started, retry_after=backoff)

            # 兜底：列表接口只回 10 个字段，而详情是按预算分批补的。
            # 若详情缓存还没轮到某条（例如刚重启），它的简介/名额/学时分类都是空的，
            # 直接 upsert 会把库里已经补全好的数据覆盖成空。这里用库里的旧值补洞。
            self._fill_missing_from_store(result.activities)

            # 匹配 + 入库（upsert 会标记哪些是首次出现的新活动）
            activities = apply_matching(result.activities, self.profile)
            new_count, updated = self.store.upsert_activities(activities)

            # 本轮确认抓全了（拿到的条数 >= 服务端 total），才能清理「已下架」的活动，
            # 否则分页没抓完会误删。不清的话，用户点开已下架活动会跳到 404。
            total = int(result.raw_count or 0)
            if total and len(activities) >= total:
                removed = self.store.prune_missing([a.id for a in activities])
                if removed:
                    self._emit("cleanup", f"清理 {removed} 条已下架的活动")

            # 精选推荐：从全库里挑「此刻最值得报的 1~3 个」，而不是把新活动全倒给用户。
            # 默认只有本轮真出现新活动才发信（否则每 30 分钟同样的推荐会刷屏），
            # 推过的记台账，不再重复推。
            if notify and (trigger != "startup" or new_count > 0):
                await self.maybe_recommend(new_count=new_count, trigger=trigger)

            self.state.consecutive_failures = 0
            self.state.last_new_count = new_count
            self.state.last_total = len(activities)
            self.state.last_error = ""
            self._finish("ok", result.message, new_count, len(activities), started)
            return {
                "ok": True, "message": result.message,
                "new": new_count, "updated": updated, "total": len(activities),
                "trigger": trigger,
            }

    def _fill_missing_from_store(self, activities: list[Activity]) -> None:
        """用库里已有的完整记录，补齐本轮「瘦数据」里的空字段。

        只补空洞，不覆盖已有值 —— 本轮真实拿到的数据永远优先。
        """
        if not activities:
            return
        try:
            known = {a.get("id"): a for a in self.store.list_activities(limit=3000)}
        except Exception:
            return

        text_fields = ("intro", "organizer", "location", "logo", "status",
                       "enroll_start", "enroll_end", "activity_start", "activity_end")
        for act in activities:
            old = known.get(act.id)
            if not old:
                continue
            for f in text_fields:
                if not getattr(act, f, "") and old.get(f):
                    setattr(act, f, old[f])
            if not act.capacity and old.get("capacity"):
                act.capacity = int(old["capacity"])
            if not act.enrolled and old.get("enrolled"):
                act.enrolled = int(old["enrolled"])
            if not act.hours and old.get("hours"):
                act.hours = float(old["hours"])
            if act.credit_type in ("", "未分类") and old.get("credit_type") \
                    and old["credit_type"] != "未分类":
                act.credit_type = old["credit_type"]
                act.credit_type_raw = old.get("credit_type_raw") or act.credit_type_raw
            for f in ("grade_scope", "college_scope", "major_scope"):
                if not getattr(act, f) and old.get(f):
                    setattr(act, f, list(old[f]))

    # ------------------------------------------------------------------ #
    # 精选推荐
    # ------------------------------------------------------------------ #

    def recommend_pool(self) -> list[Activity]:
        return [Activity.from_dict(r) for r in self.store.list_activities(limit=3000)]

    def preview_recommend(self, *, limit: int | None = None,
                          min_score: float | None = None,
                          ignore_ledger: bool = True) -> list[Activity]:
        """只算不发 —— 给界面展示「如果现在推，会推哪几条」。

        ignore_ledger 默认 True：预览是给人「看看候选池」的，
        如果因为「都推过了」返回空，用户会以为功能坏了。
        """
        rcfg = self.recommend_cfg
        exclude = [] if ignore_ledger else curator.ledger_ids(self.store)
        return curator.pick(
            self.recommend_pool(),
            limit=limit or rcfg.limit,
            min_score=rcfg.min_score if min_score is None else min_score,
            exclude_ids=exclude,
        )

    async def maybe_recommend(self, *, new_count: int = 0, trigger: str = "auto",
                              force: bool = False) -> dict[str, Any]:
        """挑 1~3 个最优活动推一封邮件。

        force=True 用于界面上的「立即推荐」：忽略「本轮无新活动」和「已推过」两个限制，
        但收到后仍然记账，避免连点两次发同一批。
        """
        rcfg = self.recommend_cfg
        if not rcfg.enabled and not force:
            return {"ok": False, "count": 0, "message": "精选推荐已关闭"}
        if not force and rcfg.only_when_new and new_count <= 0:
            return {"ok": False, "count": 0, "message": "本轮没有新活动，跳过推荐"}

        ledger = [] if force else curator.ledger_ids(self.store)
        picks = curator.pick(self.recommend_pool(), limit=rcfg.limit,
                             min_score=rcfg.min_score, exclude_ids=ledger)
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.state.last_recommend_at = stamp

        if not picks:
            self.state.last_recommend = []
            self._emit("recommend", "没有够格的推荐（已满/已截止/分数不够/都推过了）")
            return {"ok": True, "count": 0, "message": "没有够格的推荐", "items": []}

        extra = max(0, new_count - len(picks))
        results = await self._dispatch_notifications(picks, mode="recommend", extra_new=extra)
        delivered = [r for r in results if r.ok]
        if delivered:
            curator.ledger_add(self.store, [a.id for a in picks])

        self.state.last_recommend = [
            {"id": a.id, "title": a.title, "score": a.match_score,
             "hours": a.hours, "credit_type": a.credit_type,
             "enroll_end": fmt_dt(a.enroll_end), "signup_url": a.signup_url}
            for a in picks
        ]
        self._emit("recommend",
                   f"推荐 {len(picks)} 条" + ("（已发信）" if delivered else "（通道未送达）"))

        return {
            "ok": bool(delivered),
            "count": len(picks),
            "message": ("已推送 " + "、".join(r.channel for r in delivered)) if delivered
                       else "推荐已选出，但没有通道送达（检查提醒通道是否开启）",
            "items": [a.to_dict() for a in picks],
            "channels": [{"channel": r.channel, "ok": r.ok, "message": r.message} for r in results],
        }

    async def _dispatch_notifications(self, fresh: list[Activity], *,
                                      mode: str = "new",
                                      extra_new: int = 0) -> list[NotifyResult]:
        ncfg = dict(self.cfg.get("notify") or {})
        if not fresh or not ncfg.get("enabled"):
            return []
        # 通道密钥存放在加密保险箱，运行时合并进来
        try:
            secret = (self.vault.load().get("notify") or {})
            ncfg.update({k: v for k, v in secret.items() if v})
        except Exception:
            pass
        self.notifier.config = ncfg
        results = await self.notifier.dispatch(fresh, mode=mode, extra_new=extra_new)
        for r in results:
            self._emit("notify", f"{r.channel}：{'成功' if r.ok else '失败'} {r.message}",
                       ok=r.ok, channel=r.channel)
        try:
            pending = self.store.get_meta("pending_notifications", []) or []
            pending = ([{"ts": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                         "title": a.title, "credit_type": a.credit_type,
                         "score": a.match_score, "id": a.id} for a in fresh] + pending)[:200]
            self.store.set_meta("pending_notifications", pending)
        except Exception:
            pass
        return results

    def _finish(self, status: str, message: str, new_count: int, total: int,
                started: float, retry_after: float | None = None) -> dict[str, Any]:
        duration = int((time.monotonic() - started) * 1000)
        self.state.last_status = status
        self.state.last_message = message
        self.store.log_poll(status, message, new_count, total, duration)
        self._emit("result", f"[{status}] {message}",
                   new=new_count, total=total, ms=duration)
        self._schedule_next(delay_seconds=retry_after)
        return {
            "ok": status == "ok", "message": message,
            "new": new_count, "total": total, "duration_ms": duration,
            "status": status,
        }

    # ------------------------------------------------------------------ #
    # 对外状态
    # ------------------------------------------------------------------ #

    def state_dict(self) -> dict[str, Any]:
        d = asdict(self.state)
        try:
            d["adapter_status"] = self.adapter.status()
        except Exception:
            d["adapter_status"] = {}
        d["backend"] = self.vault.backend
        return d
