"""HTTP API 层。

隐私约定（贯穿所有接口）：
  * 任何响应都不包含明文密码；
  * 凭据状态只返回「是否已保存 / 加密方式 / 掩码」；
  * 通知通道的密钥同样存放在加密保险箱，接口只返回是否已配置。
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from .models import CREDIT_TYPES, Activity, Profile, match_activity
from .security import VaultError, hint_of, mask
from .services import curator
from .services.notify import CHANNELS, test_channel
from .settings import DEFAULT_CONFIG, load_config, save_config, update_config

router = APIRouter(prefix="/api")


# --------------------------------------------------------------------------- #
# 请求模型
# --------------------------------------------------------------------------- #


class CredentialIn(BaseModel):
    account: str = Field(default="", description="学号 / 登录账号")
    password: str = Field(default="", description="密码，仅在内存中停留")
    school_id: str = Field(default="", description="学校 ID（schoolId）")
    school_name: str = Field(default="", description="学校名称，仅用于展示")
    master_password: str | None = Field(default=None, description="非 Windows 环境下的主密码")


class ConfigIn(BaseModel):
    patch: dict[str, Any] = Field(default_factory=dict)


class NotifyIn(BaseModel):
    enabled: bool = True
    channels: list[str] = Field(default_factory=list)
    settings: dict[str, Any] = Field(default_factory=dict, description="各通道密钥，写入保险箱")


class LoginTestIn(BaseModel):
    account: str = ""
    password: str = ""
    school_id: str = ""
    persist: bool = False


class MasterPasswordIn(BaseModel):
    password: str


# --------------------------------------------------------------------------- #
# 依赖注入（由 main.py 装配）
# --------------------------------------------------------------------------- #

_ctx: dict[str, Any] = {}


def bind(store, vault, engine) -> None:
    _ctx.update(store=store, vault=vault, engine=engine)


def store():
    return _ctx["store"]


def vault():
    return _ctx["vault"]


def engine():
    return _ctx["engine"]


# --------------------------------------------------------------------------- #
# 初始化 / 配置
# --------------------------------------------------------------------------- #


@router.get("/bootstrap")
async def bootstrap() -> dict[str, Any]:
    """前端首屏一次性拉取所需上下文。"""
    cfg = load_config()
    cred = None
    try:
        cred = vault().load()
    except Exception:
        cred = None

    prof = Profile.from_dict(cfg.get("profile"))
    cred_status = vault().status()
    cred_status.update({
        "account_masked": mask((cred or {}).get("account")),
        "account_hint": hint_of((cred or {}).get("password")),
        "school_id": (cred or {}).get("schoolId", ""),
        "school_name": (cred or {}).get("schoolName", ""),
        "has_credentials": bool((cred or {}).get("account")),
    })

    notify_cfg = cfg.get("notify") or {}
    notify_secret = ((cred or {}).get("notify") or {})
    notify_view = {
        "enabled": bool(notify_cfg.get("enabled")),
        "channels": list(notify_cfg.get("channels") or []),
        "available": CHANNELS,
        "configured_keys": sorted([k for k, v in notify_secret.items() if v]),
    }

    return {
        "app": {"version": "0.2.0", "server_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")},
        "config": {
            "app": cfg.get("app"),
            "poll": cfg.get("poll"),
            "source": {k: v for k, v in (cfg.get("source") or {}).items()},
            "profile": prof.to_dict(),
            "recommend": cfg.get("recommend"),
        },
        "credit_types": CREDIT_TYPES,
        "credentials": cred_status,
        "notify": notify_view,
        "engine": engine().state_dict(),
        "stats": store().stats(),
    }


@router.post("/config")
async def set_config(body: ConfigIn) -> dict[str, Any]:
    allowed = {"app", "poll", "source", "profile", "recommend"}
    patch = {k: v for k, v in (body.patch or {}).items() if k in allowed}
    if not patch:
        raise HTTPException(400, "没有可更新的配置项")

    if "poll" in patch:
        interval = int((patch["poll"] or {}).get("interval_minutes", 30))
        if interval not in (30, 60):
            raise HTTPException(400, "检索间隔只支持 30 或 60 分钟")

    if "recommend" in patch:
        # 夹一下范围，避免前端传 0 条或 100 分把推荐彻底关死/开闸
        rc = dict(patch["recommend"] or {})
        if "limit" in rc:
            rc["limit"] = max(1, min(5, int(rc["limit"])))
        if "min_score" in rc:
            rc["min_score"] = max(0.0, min(100.0, float(rc["min_score"])))
        patch["recommend"] = rc

    if "source" in patch and "adapter" in (patch["source"] or {}):
        if patch["source"]["adapter"] not in ("demo", "xueqi9"):
            raise HTTPException(400, "未知数据源")

    cfg = update_config(patch)
    if "source" in patch:
        engine().reload_adapter()
        # 从演示切到真实数据源时，把演示数据清掉，避免真假活动混在一起
        if (patch.get("source") or {}).get("adapter") == "xueqi9":
            try:
                store().purge_demo()
            except Exception:
                pass
    return {"ok": True, "config": {
        "poll": cfg.get("poll"), "source": cfg.get("source"), "profile": cfg.get("profile")
    }}


@router.post("/config/reset")
async def reset_config() -> dict[str, Any]:
    save_config(DEFAULT_CONFIG)
    engine().reload_adapter()
    return {"ok": True}


# --------------------------------------------------------------------------- #
# 凭据
# --------------------------------------------------------------------------- #


@router.post("/credentials")
async def save_credentials(body: CredentialIn) -> dict[str, Any]:
    if not body.account or not body.password:
        raise HTTPException(400, "账号与密码均不能为空")

    v = vault()
    if body.master_password:
        v.set_master_password(body.master_password)
    elif v.backend != "dpapi" and not v.has_master_password():
        raise HTTPException(400, "当前系统需要主密码才能加密保存凭据，请填写主密码")

    old = {}
    try:
        old = v.load()
    except Exception:
        old = {}

    payload = {
        **old,
        "account": body.account.strip(),
        "password": body.password,
        "schoolId": body.school_id.strip() or old.get("schoolId", ""),
        "schoolName": body.school_name.strip() or old.get("schoolName", ""),
        "savedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    try:
        v.save(payload)
    except VaultError as exc:
        raise HTTPException(400, str(exc))

    # 同步学校 ID 到配置（非敏感，方便界面显示）
    if payload["schoolId"]:
        update_config({"source": {"school_id": payload["schoolId"],
                                  "school_name": payload["schoolName"]}})
        engine().reload_adapter()

    # 首次保存凭据后若仍停在演示数据源，直接切真实数据源并清掉假数据：
    # 否则用户登录成功了，界面还在放演示活动，会以为"没生效"。
    auto_switched = False
    try:
        if (load_config().get("source") or {}).get("adapter", "demo") == "demo" \
                and not store().has_real_activities():
            update_config({"source": {"adapter": "xueqi9"}})
            store().purge_demo()
            engine().reload_adapter()
            auto_switched = True
    except Exception:
        auto_switched = False

    return {"ok": True, "auto_switched": auto_switched, "credentials": {
        "account_masked": mask(payload["account"]),
        "has_credentials": True,
        "school_id": payload["schoolId"],
        "school_name": payload["schoolName"],
    }}


@router.delete("/credentials")
async def clear_credentials() -> dict[str, Any]:
    vault().clear()
    engine().state.logged_in = False
    return {"ok": True, "message": "本地凭据已彻底删除"}


@router.post("/credentials/master-password")
async def set_master_password(body: MasterPasswordIn) -> dict[str, Any]:
    vault().set_master_password(body.password)
    return {"ok": True, "has_master_password": True}


@router.post("/login/test")
async def test_login(body: LoginTestIn) -> dict[str, Any]:
    """验证登录流程（不落盘、仅内存）。用真实测试账号验证时使用。"""
    ad = engine().adapter
    if ad.name == "demo":
        return {"ok": True, "message": "当前为演示数据源，无需登录", "display_name": "演示同学"}

    cred = None
    if body.account and body.password:
        cred = {"account": body.account, "password": body.password}
    else:
        try:
            cred = vault().load()
        except VaultError:
            cred = None
    if not cred:
        raise HTTPException(400, "请先填写账号密码，或先在设置中保存凭据")

    if body.school_id:
        engine().source_cfg.school_id = body.school_id

    res = await ad.login(cred)
    return {
        "ok": res.ok,
        "message": res.message,
        "display_name": res.display_name,
        "profile_hint": res.profile_hint,
    }


# --------------------------------------------------------------------------- #
# 学校列表（登录前即可用，用于把 schoolId 从「手填」变成「搜索选择」）
# --------------------------------------------------------------------------- #


@router.get("/schools")
async def list_schools(q: str = "", limit: int = 40, refresh: bool = False) -> dict[str, Any]:
    from .adapters.xueqi9 import fetch_all_schools, search_schools

    try:
        schools = await fetch_all_schools(force=refresh, base_url=engine().source_cfg.base_url)
    except Exception as exc:
        raise HTTPException(502, f"获取学校列表失败：{exc}")
    return {"total": len(schools), "items": search_schools(schools, q, limit)}


@router.get("/dict/{name}")
async def get_dict(name: str) -> dict[str, Any]:
    """代理「学院 / 年级 / 活动分类」等字典接口，未登录或失败时返回空列表。

    前端在这三种情况下回退成手动输入，不影响使用。
    """
    # 全部为 2026-10-17 用真实账号逐个实测确认过的路径：
    #   dict/college/list          -> 学院列表 ✅
    #   dict/grade/partake/list    -> 参与年级列表 ✅（回 2017级…）
    #   dict/activity/choice-sort  -> 排序 + 分类树 ✅（六类学时的权威来源）
    # 已废弃的错误路径（实测报错，勿再使用）：
    #   dict/activity/classify/list -> code 10000「出现未知数据错误」
    #   dict/grade/list             -> 404
    #   dict/organization/list      -> 10002「参数缺失」（需要额外参数）
    allowed = {
        "colleges": "dict/college/list",
        "grades": "dict/grade/partake/list",
        "classify": "dict/activity/choice-sort",
    }
    if name not in allowed:
        raise HTTPException(400, f"未知字典：{name}")

    ad = engine().adapter
    if ad.name == "demo":
        return {"items": [], "source": "demo",
                "note": "演示数据源没有真实字典，请手动填写。"}
    if not getattr(ad, "_logged_in", False):
        return {"items": [], "source": "anonymous",
                "note": "尚未登录，暂时无法读取学校的字典数据。"}

    data = await ad.get_dict(allowed[name])
    items = _flatten_dict(data)
    return {"items": items, "source": "xueqi9", "count": len(items)}


def _flatten_dict(data: Any) -> list[dict[str, Any]]:
    """把各种形态的字典返回体压平成 [{id, name}]。

    已适配两种形态：
      1. 平铺列表        [{id, name}, ...]                （学院 / 年级）
      2. choice-sort     {sortArray:[…], filterArray:[…]} （活动分类树）
         分类树里 level=0 是「全部」占位，level>=1 才是真正的六类学时，
         这里丢掉 level=0，避免前端把「全部」也当成一个学时类型。
    """
    if not data:
        return []

    if isinstance(data, dict) and ("filterArray" in data or "sortArray" in data):
        out: list[dict[str, Any]] = []
        for row in (data.get("filterArray") or []):
            if isinstance(row, dict) and int(row.get("level") or 0) >= 1 and row.get("name"):
                out.append({"id": str(row.get("id", "")), "name": str(row["name"]).strip()})
        return out

    rows = data if isinstance(data, list) else (
        data.get("list") or data.get("records") or data.get("data") or []
    )
    out = []
    for row in rows:
        if isinstance(row, str):
            out.append({"id": row, "name": row})
        elif isinstance(row, dict):
            name = row.get("name") or row.get("collegeName") or row.get("gradeName") \
                or row.get("classifyName") or row.get("label") or row.get("value")
            if name:
                out.append({"id": str(row.get("id") or row.get("value") or name),
                            "name": str(name).strip()})
    return out


# --------------------------------------------------------------------------- #
# 活动
# --------------------------------------------------------------------------- #


@router.get("/activities")
async def list_activities(
    credit_types: list[str] | None = Query(default=None),
    enroll_state: str | None = None,
    only_new: bool = False,
    only_matchable: bool = False,
    keyword: str = "",
    sort: str = "match",
    limit: int = 500,
) -> dict[str, Any]:
    items = store().list_activities(
        credit_types=credit_types or None,
        enroll_state=enroll_state,
        only_new=only_new,
        only_matchable=only_matchable,
        keyword=keyword,
        sort=sort,
        limit=limit,
    )
    return {"items": items, "count": len(items)}


@router.get("/activities/{act_id}")
async def get_activity(act_id: str) -> dict[str, Any]:
    item = store().get_activity(act_id)
    if not item:
        raise HTTPException(404, "活动不存在")
    return item


@router.post("/activities/{act_id}/refresh")
async def refresh_activity(act_id: str) -> dict[str, Any]:
    """按需补全单条活动的详情（用户点开某条活动时调用）。

    列表接口只给名称/时间/主办方；报名起止时间、人数上限、六类学时归属、
    活动简介都要靠详情接口。轮询时是分批补的，用户主动点开时这里再补一次，
    保证「打开就有完整信息」。
    """
    ad = engine().adapter
    if ad.name != "xueqi9" or not getattr(ad, "_logged_in", False):
        item = store().get_activity(act_id)
        if not item:
            raise HTTPException(404, "活动不存在")
        return {"ok": False, "message": "当前数据源无法补全详情", "item": item}

    detail = await ad.fetch_detail(act_id)
    if not detail:
        item = store().get_activity(act_id)
        if not item:
            raise HTTPException(404, "活动不存在")
        return {"ok": False, "message": "详情获取失败", "item": item}

    stored = store().get_activity(act_id)
    act = Activity.from_dict(stored) if stored else Activity(id=str(act_id))
    ad._apply_detail(act, detail)
    if not act.signup_url:
        act.signup_url = ad.signup_url(act, act.id)
    act = match_activity(act, engine().profile)
    store().upsert_activities([act])

    item = store().get_activity(act_id) or act.to_dict()
    return {"ok": True, "message": "已补全详情", "item": item}


@router.post("/activities/mark-seen")
async def mark_seen(act_id: str | None = None) -> dict[str, Any]:
    if act_id:
        store().mark_seen(act_id)
        return {"ok": True}
    n = store().mark_all_seen()
    return {"ok": True, "marked": n}


@router.get("/stats")
async def stats() -> dict[str, Any]:
    return store().stats()


# --------------------------------------------------------------------------- #
# 引擎
# --------------------------------------------------------------------------- #


@router.get("/engine/state")
async def engine_state() -> dict[str, Any]:
    return engine().state_dict()


@router.post("/engine/poll")
async def engine_poll(trigger: str = "manual") -> dict[str, Any]:
    return await engine().poll_now(trigger=trigger)


@router.post("/engine/pause")
async def engine_pause(paused: bool = True) -> dict[str, Any]:
    engine().set_paused(paused)
    return {"ok": True, "paused": paused}


@router.post("/engine/restart")
async def engine_restart() -> dict[str, Any]:
    eng = engine()
    await eng.stop()
    eng.state = type(eng.state)()
    await eng.start()
    return {"ok": True}


@router.get("/logs")
async def logs(limit: int = 40) -> dict[str, Any]:
    return {"items": store().list_poll_log(limit)}


# --------------------------------------------------------------------------- #
# 通知
# --------------------------------------------------------------------------- #


@router.post("/notify")
async def save_notify(body: NotifyIn) -> dict[str, Any]:
    """通道开关写 config.json；通道密钥写加密保险箱。"""
    update_config({"notify": {"enabled": body.enabled, "channels": body.channels}})

    v = vault()
    try:
        payload = v.load()
    except VaultError:
        payload = {}
    secret = dict(payload.get("notify") or {})
    secret.update({k: v for k, v in (body.settings or {}).items() if v})
    # 只保留启用通道相关的字段，减少敏感面
    payload["notify"] = secret
    try:
        v.save(payload)
    except VaultError as exc:
        raise HTTPException(400, str(exc))

    return {"ok": True, "enabled": body.enabled, "channels": body.channels,
            "configured_keys": sorted([k for k, val in secret.items() if val])}


@router.post("/notify/test")
async def notify_test(channel: str) -> dict[str, Any]:
    try:
        payload = vault().load()
    except VaultError:
        payload = {}
    secret = (payload.get("notify") or {})
    secret = {**secret, "channels": [channel]}
    res = await test_channel(channel, secret)
    return {"ok": res.ok, "channel": res.channel, "message": res.message}


# --------------------------------------------------------------------------- #
# 精选推荐
# --------------------------------------------------------------------------- #


@router.get("/recommend")
async def recommend_preview(limit: int = 3, min_score: float | None = None) -> dict[str, Any]:
    """只算不发：现在推的话会推哪几条（界面上「看看会推什么」用）。

    预览忽略推荐台账，否则「都推过了」会返回空，看起来像功能坏了；
    已经推过的条目用 already_recommended 标出来，让用户自己判断。
    """
    eng = engine()
    st = store()
    sent = set(curator.ledger_ids(st))
    picks = eng.preview_recommend(limit=limit, min_score=min_score, ignore_ledger=True)
    items = []
    for a in picks:
        d = a.to_dict()
        d["already_recommended"] = str(a.id) in sent
        items.append(d)
    return {
        "ok": True,
        "count": len(items),
        "min_score": eng.recommend_cfg.min_score if min_score is None else min_score,
        "items": items,
        "ledger_size": len(sent),
    }


@router.post("/recommend/send")
async def recommend_send(limit: int | None = None) -> dict[str, Any]:
    """立刻挑最好的 1~3 条发一封邮件（不受「本轮无新活动」限制）。"""
    eng = engine()
    if limit:
        update_config({"recommend": {"limit": max(1, min(5, int(limit)))}})
    return await eng.maybe_recommend(force=True, trigger="manual")


@router.post("/recommend/reset")
async def recommend_reset() -> dict[str, Any]:
    """清空推荐台账 —— 想让已经推过的活动重新参与推荐时用。"""
    curator.ledger_clear(store())
    return {"ok": True, "message": "已清空推荐记录，下次会重新推当前最优的几条"}
