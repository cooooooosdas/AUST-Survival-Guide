"""SQLite 存储层。

只存活动数据与运行状态 —— **不存任何明文凭据**。
"""

from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime
from pathlib import Path
from typing import Any

from .models import Activity
from .settings import DB_PATH, ensure_dirs

_SCHEMA = """
CREATE TABLE IF NOT EXISTS activities (
    id            TEXT PRIMARY KEY,
    payload       TEXT NOT NULL,
    first_seen    TEXT NOT NULL,
    last_seen     TEXT NOT NULL,
    is_new        INTEGER NOT NULL DEFAULT 1,
    match_score   REAL NOT NULL DEFAULT 0,
    enroll_state  TEXT NOT NULL DEFAULT 'unknown',
    credit_type   TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_act_score  ON activities(match_score DESC);
CREATE INDEX IF NOT EXISTS idx_act_seen   ON activities(last_seen DESC);
CREATE INDEX IF NOT EXISTS idx_act_new    ON activities(is_new);

CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS poll_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    ts         TEXT NOT NULL,
    status     TEXT NOT NULL,
    message    TEXT,
    new_count  INTEGER DEFAULT 0,
    total_count INTEGER DEFAULT 0,
    duration_ms INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_log_ts ON poll_log(ts DESC);
"""


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


class Store:
    def __init__(self, path: Path | None = None) -> None:
        ensure_dirs()
        self.path = Path(path or DB_PATH)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.executescript(_SCHEMA)
            self._conn.commit()

    # -- 活动 -------------------------------------------------------------- #

    def upsert_activities(self, activities: list[Activity]) -> tuple[int, int]:
        """写入活动，返回 (新增数, 更新数)。已存在的活动会保留 first_seen。"""
        new_count = updated = 0
        now = _now()
        with self._lock:
            cur = self._conn.cursor()
            for act in activities:
                row = cur.execute(
                    "SELECT first_seen FROM activities WHERE id=?", (act.id,)
                ).fetchone()
                if row is None:
                    act.first_seen = act.first_seen or now
                    act.last_seen = now
                    act.is_new = True
                    new_count += 1
                else:
                    act.first_seen = row["first_seen"]
                    act.last_seen = now
                    act.is_new = False
                    updated += 1
                cur.execute(
                    """INSERT INTO activities
                       (id, payload, first_seen, last_seen, is_new, match_score, enroll_state, credit_type)
                       VALUES (?,?,?,?,?,?,?,?)
                       ON CONFLICT(id) DO UPDATE SET
                         payload=excluded.payload,
                         last_seen=excluded.last_seen,
                         match_score=excluded.match_score,
                         enroll_state=excluded.enroll_state,
                         credit_type=excluded.credit_type""",
                    (
                        act.id, json.dumps(act.to_dict(), ensure_ascii=False),
                        act.first_seen, act.last_seen, int(act.is_new),
                        act.match_score, act.enroll_state, act.credit_type,
                    ),
                )
            self._conn.commit()
        return new_count, updated

    def list_activities(
        self,
        *,
        credit_types: list[str] | None = None,
        enroll_state: str | None = None,
        only_new: bool = False,
        only_matchable: bool = False,
        keyword: str = "",
        sort: str = "match",
        limit: int = 500,
    ) -> list[dict[str, Any]]:
        sql = "SELECT payload, is_new, match_score, enroll_state, credit_type, first_seen, last_seen FROM activities WHERE 1=1"
        args: list[Any] = []
        if credit_types:
            sql += f" AND credit_type IN ({','.join('?' * len(credit_types))})"
            args += credit_types
        if enroll_state:
            sql += " AND enroll_state=?"
            args.append(enroll_state)
        if only_new:
            sql += " AND is_new=1"
        if only_matchable:
            sql += " AND match_score > 0"
        order = {
            "match": "match_score DESC, last_seen DESC",
            "new": "first_seen DESC",
            "enroll_end": "enroll_state='open' DESC, last_seen DESC",
        }.get(sort, "match_score DESC")
        sql += f" ORDER BY {order} LIMIT ?"
        args.append(limit)
        with self._lock:
            rows = self._conn.execute(sql, args).fetchall()

        out: list[dict[str, Any]] = []
        kw = (keyword or "").strip()
        for r in rows:
            item = json.loads(r["payload"])
            item["is_new"] = bool(r["is_new"])
            item["first_seen"] = r["first_seen"]
            item["last_seen"] = r["last_seen"]
            if kw:
                hay = f"{item.get('title','')}{item.get('intro','')}{item.get('organizer','')}"
                if kw not in hay:
                    continue
            out.append(item)
        return out

    def get_activity(self, act_id: str) -> dict[str, Any] | None:
        with self._lock:
            r = self._conn.execute(
                "SELECT payload FROM activities WHERE id=?", (act_id,)
            ).fetchone()
        return json.loads(r["payload"]) if r else None

    def mark_all_seen(self) -> int:
        with self._lock:
            cur = self._conn.execute("UPDATE activities SET is_new=0 WHERE is_new=1")
            self._conn.commit()
            return cur.rowcount

    def mark_seen(self, act_id: str) -> None:
        with self._lock:
            self._conn.execute("UPDATE activities SET is_new=0 WHERE id=?", (act_id,))
            self._conn.commit()

    def purge_demo(self) -> int:
        """清掉「演示数据源」遗留的活动。

        判别依据：真实二课活动的 id 是纯数字（如 572270），演示数据源的 id 是
        20 位十六进制摘要（digest_id("demo", title)）。从演示切到真实数据源后，
        这些假数据混在列表里只会让人困惑，所以切换时自动清理。
        """
        with self._lock:
            rows = self._conn.execute("SELECT id FROM activities").fetchall()
            demo_ids = [r["id"] for r in rows if not str(r["id"]).isdigit()]
            if demo_ids:
                self._conn.executemany(
                    "DELETE FROM activities WHERE id=?", [(i,) for i in demo_ids]
                )
                self._conn.commit()
            return len(demo_ids)

    def has_real_activities(self) -> bool:
        """库里是否已有真实二课活动（id 为纯数字）；仅演示数据时返回 False。"""
        with self._lock:
            rows = self._conn.execute("SELECT id FROM activities").fetchall()
        return any(str(r["id"]).isdigit() for r in rows)

    def prune_missing(self, keep_ids: list[str]) -> int:
        """删掉「本轮完整抓取里不存在的活动」。

        只应在**确认抓全了**的时候调用（收到的条数 >= 服务端 total），
        否则分页没抓完会把仍然有效的活动误删。
        """
        keep = set(keep_ids)
        with self._lock:
            rows = self._conn.execute("SELECT id FROM activities").fetchall()
            gone = [r["id"] for r in rows if r["id"] not in keep]
            if gone:
                self._conn.executemany(
                    "DELETE FROM activities WHERE id=?", [(i,) for i in gone]
                )
                self._conn.commit()
            return len(gone)

    def purge_stale(self, days: int = 45) -> int:
        with self._lock:
            cur = self._conn.execute(
                "DELETE FROM activities WHERE julianday('now') - julianday(last_seen) > ?",
                (days,),
            )
            self._conn.commit()
            return cur.rowcount

    def stats(self) -> dict[str, Any]:
        with self._lock:
            total = self._conn.execute("SELECT COUNT(*) c FROM activities").fetchone()["c"]
            new = self._conn.execute(
                "SELECT COUNT(*) c FROM activities WHERE is_new=1"
            ).fetchone()["c"]
            open_cnt = self._conn.execute(
                "SELECT COUNT(*) c FROM activities WHERE enroll_state='open'"
            ).fetchone()["c"]
            matched = self._conn.execute(
                "SELECT COUNT(*) c FROM activities WHERE match_score > 0"
            ).fetchone()["c"]
            full_cnt = self._conn.execute(
                "SELECT COUNT(*) c FROM activities WHERE json_extract(payload,'$.capacity') > 0"
                " AND json_extract(payload,'$.enrolled') >= json_extract(payload,'$.capacity')"
            ).fetchone()["c"]
            by_type = {
                r["credit_type"]: r["c"]
                for r in self._conn.execute(
                    "SELECT credit_type, COUNT(*) c FROM activities GROUP BY credit_type"
                ).fetchall()
            }
        return {
            "total": total, "new": new, "open": open_cnt,
            "matched": matched, "full": full_cnt, "by_credit_type": by_type,
        }

    # -- meta -------------------------------------------------------------- #

    def set_meta(self, key: str, value: Any) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, json.dumps(value, ensure_ascii=False)),
            )
            self._conn.commit()

    def get_meta(self, key: str, default: Any = None) -> Any:
        with self._lock:
            r = self._conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        if not r:
            return default
        try:
            return json.loads(r["value"])
        except Exception:
            return default

    def all_meta(self) -> dict[str, Any]:
        with self._lock:
            rows = self._conn.execute("SELECT key, value FROM meta").fetchall()
        out = {}
        for r in rows:
            try:
                out[r["key"]] = json.loads(r["value"])
            except Exception:
                out[r["key"]] = r["value"]
        return out

    # -- 轮询日志 ---------------------------------------------------------- #

    def log_poll(self, status: str, message: str = "", new_count: int = 0,
                 total_count: int = 0, duration_ms: int = 0) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT INTO poll_log(ts,status,message,new_count,total_count,duration_ms) VALUES(?,?,?,?,?,?)",
                (_now(), status, message[:500], new_count, total_count, duration_ms),
            )
            self._conn.execute(
                "DELETE FROM poll_log WHERE id NOT IN (SELECT id FROM poll_log ORDER BY id DESC LIMIT 300)"
            )
            self._conn.commit()

    def list_poll_log(self, limit: int = 40) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM poll_log ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in rows]

    def close(self) -> None:
        try:
            self._conn.close()
        except Exception:
            pass
