"""全局配置与路径管理。

配置分两层：
  1. config.json   —— 非敏感配置（轮询间隔、适配器选择、学校 ID 等），明文存储，可随项目分发。
  2. data/         —— 运行时目录，存放 SQLite 数据库与「加密后的」凭据密文，绝不进版本库。
"""

from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any


def _is_frozen() -> bool:
    """是否运行在 PyInstaller 打出的 exe 里。"""
    return bool(getattr(sys, "frozen", False))


def _app_root() -> Path:
    """可写根目录：config.json 与 data/ 放这里。

    打包成单文件 exe 后，`__file__` 指向临时解压目录（每次退出即删），
    在那里读写配置会导致"重启后配置全丢"，所以必须落到 exe 所在目录。
    """
    if _is_frozen():
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def _resource_root() -> Path:
    """只读资源根目录：前端静态文件（打包后被塞进 _MEIPASS）。"""
    if _is_frozen():
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).resolve().parent))
    return Path(__file__).resolve().parent.parent


ROOT = _app_root()
RESOURCE_ROOT = _resource_root()
CONFIG_PATH = ROOT / "config.json"
DATA_DIR = ROOT / "data"
DB_PATH = DATA_DIR / "erke.db"
SECRET_PATH = DATA_DIR / "credentials.bin"
FRONTEND_DIR = RESOURCE_ROOT / "frontend"

DEFAULT_CONFIG: dict[str, Any] = {
    "app": {"host": "127.0.0.1", "port": 8848, "open_browser": True},
    "poll": {
        "interval_minutes": 30,
        "interval_options": [30, 60],
        "page_size": 20,
        "max_pages": 5,
        "jitter_seconds": 90,
        "quiet_hours": ["00:00-06:30"],
    },
    "source": {
        "adapter": "demo",
        "base_url": "https://win.9xueqi.com/api/app/client/v1/",
        "web_origin": "https://win.9xueqi.com",
        "platform_version": "2.0.5",
        "platform": 3,
        "device_id": "FAAE6E21-013F-42D1-B722-599DE3DC340F",
        "school_id": "",
        "school_name": "",
        "request_timeout": 20,
        "min_interval_between_requests": 1.2,
        "enrich_detail": True,
        "enrich_limit": 20,
        "sort_type": 2,
    },
    "profile": {
        "grade": "",
        "college": "",
        "major": "",
        "credit_types": [],
        "keywords_include": [],
        "keywords_exclude": [],
    },
    # 「精选推荐」——不是把所有新活动倒给你，而是挑 1~3 个最值得报的发一封邮件
    "recommend": {
        "enabled": True,
        "limit": 3,            # 最多推荐几条（第 1 条即首选）
        "min_score": 35,       # 低于此分不推，宁缺毋滥
        "only_when_new": True,  # 只有本轮出现新活动才发信，避免同样推荐反复刷屏
    },
}


def _deep_merge(base: dict, override: dict) -> dict:
    out = dict(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> dict[str, Any]:
    ensure_dirs()
    if not CONFIG_PATH.exists():
        save_config(DEFAULT_CONFIG)
        return json.loads(json.dumps(DEFAULT_CONFIG))
    try:
        raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        raw = {}
    return _deep_merge(DEFAULT_CONFIG, raw)


def save_config(cfg: dict[str, Any]) -> None:
    ensure_dirs()
    CONFIG_PATH.write_text(
        json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def update_config(patch: dict[str, Any]) -> dict[str, Any]:
    cfg = _deep_merge(load_config(), patch)
    save_config(cfg)
    return cfg


@dataclass
class PollSettings:
    interval_minutes: int = 30
    interval_options: list[int] = field(default_factory=lambda: [30, 60])
    page_size: int = 20
    max_pages: int = 5
    jitter_seconds: int = 90
    quiet_hours: list[str] = field(default_factory=lambda: ["00:00-06:30"])

    @classmethod
    def from_dict(cls, d: dict) -> "PollSettings":
        d = d or {}
        return cls(
            interval_minutes=int(d.get("interval_minutes", 30)),
            interval_options=list(d.get("interval_options", [30, 60])),
            page_size=int(d.get("page_size", 20)),
            max_pages=int(d.get("max_pages", 5)),
            jitter_seconds=int(d.get("jitter_seconds", 90)),
            quiet_hours=list(d.get("quiet_hours", [])),
        )


@dataclass
class SourceSettings:
    adapter: str = "demo"
    base_url: str = "https://win.9xueqi.com/api/app/client/v1/"
    web_origin: str = "https://win.9xueqi.com"
    platform_version: str = "2.0.5"
    platform: int = 3
    device_id: str = "FAAE6E21-013F-42D1-B722-599DE3DC340F"
    school_id: str = ""
    school_name: str = ""
    request_timeout: int = 20
    min_interval_between_requests: float = 1.2
    # 列表接口很「瘦」（只有名称/时间/主办方/学时），报名时间、人数上限、
    # 六类学时归属都在详情接口里。下面两个参数控制每轮补全多少条详情。
    enrich_detail: bool = True
    enrich_limit: int = 20
    sort_type: int = 2  # 1=最热 2=最新 3=最快开始 4=最高学时（用「最新」便于发现新活动）

    @classmethod
    def from_dict(cls, d: dict) -> "SourceSettings":
        d = d or {}
        return cls(**{k: d[k] for k in cls.__dataclass_fields__ if k in d})


@dataclass
class RecommendSettings:
    """精选推荐的三个旋钮。"""

    enabled: bool = True
    limit: int = 3
    min_score: float = 35.0
    only_when_new: bool = True

    @classmethod
    def from_dict(cls, d: dict) -> "RecommendSettings":
        d = d or {}
        return cls(
            enabled=bool(d.get("enabled", True)),
            limit=int(d.get("limit", 3) or 3),
            min_score=float(d.get("min_score", 35) or 0),
            only_when_new=bool(d.get("only_when_new", True)),
        )


def env_flag(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


def asdict_safe(obj: Any) -> dict:
    try:
        return asdict(obj)
    except Exception:
        return {}
