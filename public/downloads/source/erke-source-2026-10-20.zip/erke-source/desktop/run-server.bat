@echo off
rem 后台常驻用的启动器（不给计划任务弹窗、不自动开浏览器）。
rem 日常使用请双击 start.bat，那个会开浏览器窗口。
chcp 65001 >nul
cd /d "%~dp0"

set "PY=.venv\Scripts\python.exe"
if not exist "%PY%" set "PY=%USERPROFILE%\.workbuddy\binaries\python\envs\default\Scripts\python.exe"
if not exist "%PY%" set "PY=python"

"%PY%" -m uvicorn backend.main:app --host 127.0.0.1 --port 8848 --log-level info >> "%~dp0data\server.log" 2>&1
