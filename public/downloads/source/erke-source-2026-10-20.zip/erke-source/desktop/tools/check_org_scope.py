"""参与组织（班级级限制）校验 —— 桌面版与移动版共用同一套口径。

运行：python tools/check_org_scope.py
退出码 0 = 全过。

口径来源：活动详情 organizationList（前端产物 chunk_35.js 里「参与组织」渲染的就是它，
[{name:'制药25-1_2025'}]，空数组 = 不限）。不在名单内的班级，服务端会直接拒绝报名。
"""

import sys

sys.path.insert(0, ".")

from backend.models import Activity, Profile, org_scope_hit, match_activity  # noqa: E402

FAILED = []


def ok(label, cond, extra=""):
    print(("  [\u2713] " if cond else "  [\u2717] ") + label + ("" if cond else "  " + str(extra)))
    if not cond:
        FAILED.append(label)


def me(**kw):
    base = dict(grade="2025", college="计算机科学与工程学院", major="软件工程",
                clazz="软件工程25-4")
    base.update(kw)
    return Profile(**base)


def act(orgs, **kw):
    base = dict(id="x1", title="班级团日活动", hours=4.0,
                credit_type="思想政治引领", org_scope=orgs,
                intro="班级内部活动", enroll_end="2099-01-01 10:00")
    base.update(kw)
    return Activity(**base)


def main():
    print("参与组织命中判断")
    ok("不限组织 → 放行", org_scope_hit("软件工程25-4", []))
    ok("名单含「全校」→ 放行", org_scope_hit("软件工程25-4", ["全校"]))
    ok("同班命中（带 _入学年 后缀）", org_scope_hit("软件工程25-4", ["软件工程25-4_2025"]))
    ok("别的班级 → 拦截", not org_scope_hit("软件工程25-4", ["制药25-1_2025"]))
    ok("未填班级 → 拦截", not org_scope_hit("", ["制药25-1_2025"]))

    print("边界情况")
    ok("25-1 不命中 25-11", not org_scope_hit("制药25-11", ["制药25-1_2025"]))
    ok("25-11 不命中 25-1", not org_scope_hit("制药25-1", ["制药25-11_2025"]))
    ok("只填专业不算命中班级", not org_scope_hit("制药", ["制药25-1_2025"]))
    ok("末尾「班」不影响命中", org_scope_hit("软件工程25-4班", ["软件工程25-4_2025"]))
    ok("前后空格不影响命中", org_scope_hit(" 软件工程25-4 ", ["软件工程25-4"]))
    ok("多班级命中其一即可",
       org_scope_hit("软件工程25-4", ["制药25-1_2025", "软件工程25-4_2025"]))

    print("打分与精选")
    a = match_activity(act(["制药25-1_2025"]), me())
    ok("别班 → 硬性不符", a.hard_blocked, a.match_reasons)
    ok("别班 → 分数为负", a.match_score < 0, a.match_score)
    ok("别班 → 原因写明班级限制",
       a.match_reasons[0].startswith("限班级") and "制药25-1" in a.match_reasons[0],
       a.match_reasons[0])

    b = match_activity(act(["软件工程25-4_2025"]), me())
    ok("本班 → 不算硬性不符", not b.hard_blocked)
    ok("本班 → 记「班级定向」", "班级定向" in b.match_reasons, b.match_reasons)

    c = match_activity(act(["制药25-1_2025"]), me(clazz=""))
    ok("未填班级 → 提示补填", "未填班级" in c.match_reasons[0], c.match_reasons[0])

    print("序列化")
    d = match_activity(act(["制药25-1_2025"]), me())
    ok("org_scope 落 dict", d.to_dict()["org_scope"] == ["制药25-1_2025"])
    ok("hard_blocked 落 dict", d.to_dict()["hard_blocked"] is True)
    ok("clazz 落 dict", me().to_dict()["clazz"] == "软件工程25-4")

    print("统计口径：基数只算可报的")
    from backend.services.matcher import eligible, summarize

    all_acts = [
        act(["软件工程25-4_2025"], hours=8.0),          # 可报，高分（班级定向 +18）
        act([], hours=2.0),                              # 可报但分数低（无班级定向）
        act(["制药25-1_2025"]),                          # 不可报（别班）
        act(["化工25-3_2025"]),                          # 不可报（别班）
    ]
    scored_acts = [match_activity(a, me()) for a in all_acts]
    s = summarize(scored_acts, me(), min_score=35)
    ok("总数只算可报的", s["total"] == 2, s)
    ok("不可报的计入被排除", s["blocked"] == 2, s)
    ok("匹配按门槛算，不再和总数恒等", s["matched"] == 1, s)

    only_blocked = [match_activity(act(["制药25-1_2025"]), me())]
    ok("全部不符 → 总数 0", summarize(only_blocked, me(), min_score=35)["total"] == 0)

    ok("可报列表按匹配分降序",
       [a.match_score for a in eligible(scored_acts)]
       == sorted([a.match_score for a in eligible(scored_acts)], reverse=True))
    ok("可报列表不含不可报的", all(not a.hard_blocked for a in eligible(scored_acts)))

    print()
    if FAILED:
        print("失败 %d 项：" % len(FAILED))
        for f in FAILED:
            print("  - " + f)
        return 1
    print("全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
