"""离线自检脚本 —— 不需要 Web 服务器，直接验证核心逻辑。

运行：
    python tools/smoke.py
"""

from __future__ import annotations

import asyncio
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from backend.db import Store                      # noqa: E402
from backend.models import (                      # noqa: E402
    CREDIT_TYPES, Activity, Profile, hours_bonus, match_activity, normalize_credit_type,
)
from backend.security import CredentialVault, hint_of, mask  # noqa: E402
from backend.services.engine import PollEngine    # noqa: E402
from backend.services.matcher import apply_matching, summarize  # noqa: E402

TMP = ROOT / "data" / "_smoke"
PASS, FAIL = [], []


def check(name: str, cond: bool, detail: str = "") -> None:
    (PASS if cond else FAIL).append(name)
    print(f"  {'✓' if cond else '✗'} {name}{('  → ' + detail) if detail else ''}")


# --------------------------------------------------------------------------- #

def t_credit_normalize() -> None:
    print("\n[1] 六类学时归一化")
    cases = [
        ("思想政治引领", "思想政治引领"),
        ("思想引领与理论武装", "思想政治引领"),
        ("志愿服务与社会实践", "社会责任担当"),
        ("创新创业孵化", "创新创业孵化"),
        ("文体艺术活动", "综合素质拓展"),
        ("学生骨干培训班", "精英锻炼养成"),
        ("莫名其妙的分类", "未分类"),
        ("", "未分类"),
    ]
    for raw, want in cases:
        got = normalize_credit_type(raw)
        check(f"{raw or '(空)'} → {got}", got == want, f"期望 {want}")


def t_matching() -> None:
    print("\n[2] 匹配打分")
    prof = Profile(grade="2024", college="计算机学院", major="软件工程",
                   credit_types=["创新创业孵化"], keywords_include=["竞赛"])

    a = Activity(id="a1", title="程序设计竞赛", credit_type="创新创业孵化",
                 college_scope=["计算机学院"], major_scope=["软件工程"],
                 grade_scope=["2024"], capacity=100, enrolled=50,
                 hours=8.0, enroll_end="2099-01-01 00:00")
    match_activity(a, prof)
    check("定向活动得分高", a.match_score >= 90, f"score={a.match_score}")
    check("命中关键词加分", any("关键词" in r for r in a.match_reasons), str(a.match_reasons))
    check("学时加权计入理由", any("学时（+" in r for r in a.match_reasons), str(a.match_reasons))

    # 学时加权：同样的活动，学时越多分越高（2 学时起算，8 学时封顶 +12）
    a_low = Activity(id="a2", title="程序设计竞赛", credit_type="创新创业孵化",
                     college_scope=["计算机学院"], major_scope=["软件工程"],
                     grade_scope=["2024"], capacity=100, enrolled=50,
                     hours=2.0, enroll_end="2099-01-01 00:00")
    match_activity(a_low, prof)
    check("学时多则分数高", a.match_score - a_low.match_score == 12.0,
          f"{a.match_score} vs {a_low.match_score}")
    check("学时加权封顶 12 分", hours_bonus(20.0) == 12.0, f"hours_bonus(20)={hours_bonus(20.0)}")

    b = Activity(id="b1", title="外国语学院英语角", credit_type="综合素质拓展",
                 college_scope=["外国语学院"], capacity=0, enrolled=10)
    match_activity(b, prof)
    check("学院不符被排除", b.match_score <= 0, f"score={b.match_score}")
    check("记录排除原因", any("限学院" in r for r in b.match_reasons), str(b.match_reasons))

    c = Activity(id="c1", title="校级大讲堂", credit_type="综合素质拓展",
                 capacity=200, enrolled=200)
    match_activity(c, prof)
    check("满员被扣分", any("已满" in r for r in c.match_reasons), str(c.match_reasons))

    d = Activity(id="d1", title="乡村支教", credit_type="社会责任担当", capacity=10, enrolled=1)
    prof2 = Profile(grade="2024", college="计算机学院", keywords_exclude=["支教"])
    match_activity(d, prof2)
    check("排除词压到负分", d.match_score < 0, f"score={d.match_score}")


def t_recommend() -> None:
    """精选推荐：只挑够格的，且第 1 条一定是最优。"""
    print("\n[2b] 精选推荐")
    from datetime import datetime, timedelta

    from backend.services import curator

    now = datetime(2026, 10, 17, 12, 0)
    def mk(i, title, score, *, hours=0, cap=50, enrolled=0, state="open",
           end=None, intro="简介内容", credit="综合素质拓展"):
        return Activity(id=str(i), title=title, match_score=score, hours=hours,
                        capacity=cap, enrolled=enrolled, intro=intro,
                        credit_type=credit,
                        enroll_end=(end or now + timedelta(days=3)).strftime("%Y-%m-%d %H:%M"))

    good_hi = mk(1, "甲活动", 60, hours=8)
    good_lo = mk(2, "乙活动", 45, hours=2)
    full = mk(3, "满了的", 90, cap=10, enrolled=10)
    closed = mk(4, "截止了", 99, end=now - timedelta(days=1))
    low = mk(5, "分不够", 20)
    soon = mk(6, "马上截止", 88, end=now + timedelta(minutes=10))
    dup = mk(7, "甲活动（观众通道）", 60, hours=8)

    picked = curator.pick([good_lo, full, closed, low, soon, dup, good_hi],
                          limit=3, min_score=35, now=now)
    ids = [a.id for a in picked]
    check("首选是分最高的", picked and picked[0].match_score == 60, f"ids={ids}")
    check("已满员的不推", "3" not in ids, f"ids={ids}")
    check("已截止的不推", "4" not in ids, f"ids={ids}")
    check("分数不够的不推", "5" not in ids, f"ids={ids}")
    check("马上就要截止的不推", "6" not in ids, f"ids={ids}")
    check("同活动多通道只留一条", not ("1" in ids and "7" in ids), f"ids={ids}")
    check("去重时留不带后缀的原版", "1" in ids, f"ids={ids}")
    check("不足 3 条就少推", len(picked) == 2, f"count={len(picked)}")

    check("推过的会被排除",
          curator.pick([good_hi, good_lo], limit=3, min_score=35,
                       exclude_ids=["1"], now=now)[0].id == "2")
    check("没有够格的就不推",
          curator.pick([low], limit=3, min_score=35, now=now) == [])
    check("推荐理由不含负面项",
          "限" not in curator.explain(good_hi), curator.explain(good_hi))
    print(f"  举例理由：{curator.explain(good_hi)}  ｜ 角标：{curator.tags(good_hi, now=now)}")


def t_security() -> None:
    print("\n[3] 凭据加密（Vault）")
    TMP.mkdir(parents=True, exist_ok=True)
    path = TMP / "cred.bin"
    v = CredentialVault(path)
    print(f"  加密后端：{v.backend}  ({v.mode_label})")

    payload = {"account": "20240001", "password": "MyS3cret!密码",
               "schoolId": "12861", "schoolName": "示例大学"}
    v.save(payload)
    raw = path.read_bytes()

    check("密文文件已生成", path.exists() and len(raw) > 0)
    check("明文密码未出现在密文中", b"MyS3cret" not in raw and "MyS3cret".encode() not in raw,
          "未在文件字节中找到明文")
    ok_json = False
    try:
        env = json.loads(raw.decode("utf-8"))
        ok_json = env.get("backend") in ("dpapi", "scrypt-aesgcm")
    except Exception:
        pass
    check("落盘是合法信封结构", ok_json)

    back = v.load()
    check("能正确解密回原文", back == payload, f"account={back.get('account')}")
    check("掩码不泄露原文", mask("20240001") == "2******1", mask("20240001"))
    check("密码提示只给量级", hint_of("MyS3cret!密码").startswith("已设置"), hint_of("MyS3cret!密码"))

    v.clear()
    check("clear() 后文件被删除", not path.exists())


def t_demo_and_engine() -> None:
    print("\n[4] 演示数据源 + 轮询引擎 + 增量识别")
    TMP.mkdir(parents=True, exist_ok=True)
    db = TMP / "smoke.db"
    if db.exists():
        db.unlink()

    store = Store(db)
    vault = CredentialVault(TMP / "cred2.bin")
    cfg = {
        "poll": {"interval_minutes": 30, "max_pages": 5, "page_size": 20,
                 "jitter_seconds": 90, "quiet_hours": []},
        "source": {"adapter": "demo", "web_origin": "https://win.9xueqi.com"},
        "profile": {"grade": "2024", "college": "计算机学院", "major": "软件工程",
                    "credit_types": ["创新创业孵化", "综合素质拓展"]},
        "notify": {"enabled": False, "channels": ["browser"]},
    }
    engine = PollEngine(store=store, vault=vault, config_provider=lambda: cfg)

    async def run() -> None:
        engine.build_adapter()
        engine.state.running = True
        r1 = await engine.poll_now(trigger="startup")
        check("首轮检索成功", r1.get("ok"), str(r1))
        st = store.stats()
        check("活动已入库", st["total"] > 0, f"total={st['total']}")
        check("识别出六类学时", len([k for k in st["by_credit_type"] if k != "未分类"]) >= 5,
              str(st["by_credit_type"]))
        check("有可报名活动", st["open"] > 0, f"open={st['open']}")
        check("有匹配到我的活动", st["matched"] > 0, f"matched={st['matched']}")

        r2 = await engine.poll_now(trigger="auto")
        check("重复轮询不重复计新", r2.get("new") == 0, f"new={r2.get('new')}")

        items = store.list_activities(sort="match", limit=5)
        check("列表按匹配度排序", items[0]["match_score"] >= items[-1]["match_score"],
              f"{items[0]['match_score']} >= {items[-1]['match_score']}")
        top = items[0]
        for field in ("title", "intro", "organizer", "credit_type", "capacity",
                      "enrolled", "enroll_start", "enroll_end", "signup_url"):
            check(f"字段 {field} 存在", field in top and top[field] is not None,
                  str(top.get(field))[:60])

        s = summarize([a for a in [Activity(**{k: v for k, v in it.items()
                                               if k in Activity.__dataclass_fields__})
                                   for it in items]], Profile())
        check("汇总统计可用", s["total"] == len(items), json.dumps(s, ensure_ascii=False)[:120])

        check("引擎状态可导出", isinstance(engine.state_dict(), dict))
        await engine.stop()

    asyncio.run(run())
    store.close()


def t_activity_states() -> None:
    print("\n[5] 报名状态与名额计算")
    import datetime as dt
    now = dt.datetime.now()
    f = lambda **kw: Activity(**kw)
    past = (now - dt.timedelta(days=2)).strftime("%Y-%m-%d %H:%M")
    future = (now + dt.timedelta(days=2)).strftime("%Y-%m-%d %H:%M")

    a = f(id="x", enroll_start=past, enroll_end=future)
    check("进行中 → open", a.enroll_state == "open", a.enroll_state)
    b = f(id="y", enroll_start=future, enroll_end=future)
    check("未开始 → upcoming", b.enroll_state == "upcoming", b.enroll_state)
    c = f(id="z", enroll_start=past, enroll_end=past)
    check("已截止 → closed", c.enroll_state == "closed", c.enroll_state)
    d = f(id="w", capacity=0, enrolled=99)
    check("不限人数 → seats_left = -1", d.seats_left == -1, str(d.seats_left))
    e = f(id="v", capacity=10, enrolled=13)
    check("超员 → seats_left 不为负", e.seats_left == 0, str(e.seats_left))


# --------------------------------------------------------------------------- #

def main() -> int:
    print("=" * 62)
    print("  二课提醒小助手 · 离线自检")
    print("=" * 62)
    t_credit_normalize()
    t_matching()
    t_recommend()
    t_security()
    t_activity_states()
    t_demo_and_engine()

    print("\n" + "=" * 62)
    print(f"  通过 {len(PASS)} 项，失败 {len(FAIL)} 项")
    if FAIL:
        print("  失败项：")
        for f in FAIL:
            print("    -", f)
    print("=" * 62)

    shutil.rmtree(TMP, ignore_errors=True)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
