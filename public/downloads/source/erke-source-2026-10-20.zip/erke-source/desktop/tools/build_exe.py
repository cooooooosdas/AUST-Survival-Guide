"""把项目打成单文件 exe（Windows），产物在 dist/ 下。

用法（在项目根目录）：
    .build-venv\\Scripts\\python.exe tools\\build_exe.py

为什么用脚本而不是直接敲命令：`--add-data` 的分隔符是 `;`，在 bash 里要转义，
在 cmd 里又和引号打架；写成 Python 列表最省事，也方便复现。
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"
NAME = "二课提醒小助手"

# 每次构建用一个全新的工作目录：
#   1) PyInstaller 不会去删上一次的中间产物（受限环境里删除动作可能被安全策略拦），
#   2) 也就不会因为复用半成品而出现莫名其妙的构建错误。
# 想固定目录可设 ERKE_BUILD_WORK=<path>（但那时需要自己保证目录可清空）。
_work_env = os.environ.get("ERKE_BUILD_WORK", "").strip()
WORK = Path(_work_env) if _work_env else ROOT / ".build" / f"w{time.strftime('%m%d-%H%M%S')}"
STAGE = WORK / "dist"


def main() -> int:
    entry = ROOT / "app_launcher.py"
    if not entry.exists():
        print(f"[x] 找不到入口文件：{entry}")
        return 1

    icon = ROOT / "frontend" / "favicon.ico"
    DIST.mkdir(parents=True, exist_ok=True)
    WORK.mkdir(parents=True, exist_ok=True)

    args = [
        sys.executable, "-m", "PyInstaller",
        "--noconfirm",
        "--onefile", "--console",
        "--name", NAME,
        "--distpath", str(STAGE),
        "--workpath", str(WORK),
        "--specpath", str(WORK),
        "--add-data", f"{ROOT / 'frontend'};frontend",
        # uvicorn 的子模块是按字符串动态加载的，静态分析扫不到，必须显式收集
        "--collect-submodules", "uvicorn",
        "--hidden-import", "uvicorn.logging",
        "--hidden-import", "uvicorn.loops.auto",
        "--hidden-import", "uvicorn.protocols.http.auto",
        "--hidden-import", "uvicorn.protocols.websockets.auto",
        "--hidden-import", "uvicorn.lifespan.on",
    ]
    if icon.exists():
        args += ["--icon", str(icon)]
    args.append(str(entry))

    print("[1/2] PyInstaller 开始打包…")
    proc = subprocess.run(args, cwd=str(ROOT))
    if proc.returncode != 0:
        print("[x] 打包失败")
        return proc.returncode

    exe = STAGE / f"{NAME}.exe"
    if not exe.exists():
        print("[x] 没有生成 exe")
        return 1
    final = DIST / f"{NAME}.exe"
    shutil.copy2(exe, final)   # 覆盖写，不删文件
    size_mb = final.stat().st_size / 1024 / 1024
    print(f"[2/2] 完成：{final}  ({size_mb:.1f} MB)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
