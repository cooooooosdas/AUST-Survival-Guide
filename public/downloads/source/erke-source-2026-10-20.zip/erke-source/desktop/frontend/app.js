/* ================= 二课提醒小助手 · 前端逻辑 ================= */
/* 纯原生 JS，无构建步骤。与后端 REST 接口通信。 */

const API = '';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

const CREDIT_TYPES = [
  '思想政治引领', '精英锻炼养成', '综合素质拓展',
  '创新创业孵化', '社会责任担当', '实践能力培养',
];
const CT_INDEX = Object.fromEntries(CREDIT_TYPES.map((t, i) => [t, i]));

const state = {
  boot: null,
  items: [],
  filters: {
    credit: '', state: '', keyword: '', sort: 'match',
    onlyMatchable: false, onlyNew: false,
  },
  countdown: 0,
  timer: null,
  engine: null,
};

/* ----------------------------- 工具 ----------------------------- */

function toast(msg, kind = '') {
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity .25s';
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 260);
  }, 3600);
}

async function api(path, options = {}) {
  const opt = { headers: { 'Content-Type': 'application/json' }, ...options };
  if (opt.body && typeof opt.body !== 'string') opt.body = JSON.stringify(opt.body);
  const res = await fetch(API + path, opt);
  let data = null;
  try { data = await res.json(); } catch (_) { /* 非 JSON */ }
  if (!res.ok) {
    const msg = (data && (data.message || data.detail || data.msg)) || `请求失败 HTTP ${res.status}`;
    throw new Error(typeof msg === 'string' ? msg : JSON.stringify(msg));
  }
  return data;
}

function debounce(fn, ms) {
  let t = null;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

function escapeHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function seatsHtml(a) {
  if (a.capacity <= 0) return '<span class="seats-inf">不限人数</span>';
  const left = a.seats_left;
  const cls = left === 0 ? 'seats-full' : left <= 5 ? 'seats-low' : 'seats-ok';
  return `<span class="${cls}">余 ${left} / ${a.capacity}</span>`;
}

/** 学时显示：8.0 -> "8"，2.5 -> "2.5"；0 视为未标注。 */
function fmtHours(h) {
  const n = Number(h || 0);
  if (!n) return '';
  return Number.isInteger(n) ? String(n) : String(Number(n.toFixed(1)));
}

function hoursBadge(a) {
  const t = fmtHours(a.hours);
  return t ? `<span class="badge hours">${t} 学时</span>` : '';
}

function fmtCountdown(sec) {
  if (sec == null || sec < 0) return '—';
  const m = Math.floor(sec / 60), s = sec % 60;
  if (m >= 60) {
    const h = Math.floor(m / 60);
    return `${h} 小时 ${m % 60} 分`;
  }
  return `${m}:${String(s).padStart(2, '0')}`;
}

/* ----------------------------- 卡片渲染 ----------------------------- */

function cardHtml(a) {
  const ctIdx = CT_INDEX[a.credit_type];
  const ctCls = ctIdx === undefined ? '' : `ct-${ctIdx}`;
  const stateLabel = { open: '报名中', upcoming: '未开始', closed: '已截止', unknown: '状态未知' }[a.enroll_state] || '';
  const reasons = (a.match_reasons || []).slice(0, 4);
  const reasonHtml = reasons.map((r) => {
    const neg = /限|排除|已满|不在/.test(r);
    return `<span class="reason${neg ? ' neg' : ''}">${escapeHtml(r)}</span>`;
  }).join('');

  return `
  <article class="card ${a.is_new ? 'is-new' : ''} ${ctCls}" data-id="${escapeHtml(a.id)}">
    <div class="card-top">
      <span class="badge ${ctCls}">${escapeHtml(a.credit_type || '未分类')}</span>
      ${hoursBadge(a)}
      <span class="badge state-${a.enroll_state}">${stateLabel}</span>
      ${a.is_new ? '<span class="badge new">NEW</span>' : ''}
      ${a.capacity > 0 && a.seats_left === 0 ? '<span class="badge state-closed">已满员</span>' : ''}
    </div>

    <h3 class="card-title">${escapeHtml(a.title)}</h3>
    <div class="card-org">🏛 ${escapeHtml(a.organizer || '组织方未标注')}</div>
    <p class="card-intro">${escapeHtml(a.intro || '暂无活动简介')}</p>

    <div class="card-grid">
      <div class="kv-item"><span class="k">可报人数</span><span class="v">${seatsHtml(a)}</span></div>
      <div class="kv-item"><span class="k">可得学时</span><span class="v mono">${fmtHours(a.hours) ? fmtHours(a.hours) + ' 个' : '未标注'}</span></div>
      <div class="kv-item"><span class="k">报名开始</span><span class="v mono">${escapeHtml(a.enroll_start_disp || '—')}</span></div>
      <div class="kv-item"><span class="k">报名截止</span><span class="v mono">${escapeHtml(a.enroll_end_disp || '—')}</span></div>
    </div>

    ${reasonHtml ? `<div class="reasons">${reasonHtml}</div>` : ''}

    <div class="card-foot">
      <span class="score">匹配度 <b>${a.match_score}</b> 分</span>
      <div class="card-actions">
        <button class="btn btn-ghost btn-sm" data-act="detail">详情</button>
        <button class="btn btn-primary btn-sm" data-act="signup">去二课报名 ↗</button>
      </div>
    </div>
  </article>`;
}

function renderCards() {
  const box = $('#cards');
  const { items } = state;
  box.innerHTML = items.map(cardHtml).join('');
  $('#empty').hidden = items.length > 0;
  $('#resultCount').textContent = items.length
    ? `共 ${items.length} 条活动${state.filters.onlyNew ? '（仅新发布）' : ''}`
    : (isFirstRunPending() ? '正在首次检索…' : '没有符合当前筛选条件的活动');
  if (!items.length) renderEmptyState();
}

/* 首次启动：库里还一条都没有，且引擎还没跑完第一轮。
   这时显示"还没有可展示的活动"会让人以为坏了，改成进度提示并自动重试。 */
let firstRunTries = 0;

function isFirstRunPending() {
  const f = state.filters;
  const filtering = f.credit || f.state || f.keyword || f.onlyNew || f.onlyMatchable;
  if (filtering) return false;
  const ran = state.engine && state.engine.last_run_at;
  return !ran;
}

function renderEmptyState() {
  const h = $('#empty h3');
  const p = $('#empty p');
  const btn = $('#btnEmptyRefresh');
  if (!h || !p || !btn) return;

  if (isFirstRunPending()) {
    h.textContent = '正在首次检索活动…';
    p.textContent = '第一次启动要把这一轮活动抓回来，通常 10–30 秒，完成后这里会自动刷新。';
    btn.hidden = true;
    if (firstRunTries < 10) {
      firstRunTries += 1;
      setTimeout(() => { refreshAll().catch(() => {}); }, 4000);
    }
    return;
  }

  h.textContent = '还没有可展示的活动';
  p.textContent = '点击右上角「立即刷新」拉取一次；或进入「设置」切换到演示数据源，先看看界面效果。';
  btn.hidden = false;
}

/* ----------------------------- 拉数据 ----------------------------- */

async function loadActivities() {
  const p = new URLSearchParams();
  if (state.filters.credit) p.append('credit_types', state.filters.credit);
  if (state.filters.state) p.set('enroll_state', state.filters.state);
  if (state.filters.keyword) p.set('keyword', state.filters.keyword);
  if (state.filters.onlyNew) p.set('only_new', 'true');
  if (state.filters.onlyMatchable) p.set('only_matchable', 'true');
  p.set('sort', state.filters.sort);

  const data = await api(`/api/activities?${p.toString()}`);
  state.items = data.items || [];
  renderCards();
}

async function loadStats() {
  const s = await api('/api/stats');
  $('#stTotal').textContent = s.total;
  $('#stOpen').textContent = s.open;
  $('#stNew').textContent = s.new;
  $('#stMatched').textContent = s.matched;
  $('#stFull').textContent = s.full != null ? s.full : 0;
}

async function loadEngineState() {
  const st = await api('/api/engine/state');
  state.engine = st;
  renderEngineBadges(st);
  renderEnginePanel(st);
  // 空列表时，空态文案依赖引擎是否已跑过；引擎状态晚到就补一次重绘
  if (!state.items.length) renderCards();
  return st;
}

function renderEngineBadges(st) {
  const adapterLabel = { demo: '演示数据', xueqi9: '趣拓二课' }[st.adapter] || st.adapter;
  const pillSrc = $('#pillSource');
  // 窄屏省掉「数据源：」，把一行留给真正在变的三条状态
  pillSrc.textContent = window.innerWidth < 420 ? adapterLabel : `数据源：${adapterLabel}`;
  pillSrc.className = 'pill' + (st.adapter === 'demo' ? ' warn' : ' ok');

  const pill = $('#pillLogin');
  if (st.logged_in) {
    pill.textContent = `已登录${st.display_name ? '：' + st.display_name : ''}`;
    pill.className = 'pill ok';
  } else {
    pill.textContent = st.adapter === 'demo' ? '演示模式' : '未登录';
    pill.className = 'pill warn';
  }

  $('#footEngine').textContent =
    `引擎${st.running ? '运行中' : '已停止'} · 累计 ${st.total_runs} 次检索 · 重登 ${st.relogin_count} 次 · 状态 ${st.last_status}`;
}

function renderEnginePanel(st) {
  const rows = [
    ['运行状态', st.running ? (st.paused ? '已暂停' : '运行中') : '已停止'],
    ['数据源', st.adapter],
    ['登录状态', st.logged_in ? '已登录' : '未登录'],
    ['登录总次数', st.login_count],
    ['静默重登次数', st.relogin_count],
    ['累计检索次数', st.total_runs],
    ['上次检索', st.last_run_at || '—'],
    ['下次检索', st.next_run_at || '—'],
    ['检索间隔', `${st.interval_minutes} 分钟`],
    ['连续失败', st.consecutive_failures],
    ['当前退避', st.backoff_seconds ? `${st.backoff_seconds} 秒` : '无'],
    ['最近结果', `${st.last_status} · 新增 ${st.last_new_count} / 共 ${st.last_total}`],
    ['最近消息', st.last_message || '—'],
    ['凭据加密', st.backend === 'dpapi' ? 'Windows DPAPI' : '主密码 AES-GCM'],
  ];
  $('#engineKv').innerHTML = rows
    .map(([k, v]) => `<div><span class="k">${k}</span><span class="v">${escapeHtml(String(v))}</span></div>`)
    .join('');

  $('#eventList').innerHTML = (st.recent_events || []).slice(0, 30)
    .map((e) => `<li><span class="t">${escapeHtml(e.ts)}</span><span class="k">${escapeHtml(e.kind)}</span><span>${escapeHtml(e.message)}</span></li>`)
    .join('') || '<li>暂无事件</li>';

  startCountdown(st.next_run_at);
}

async function loadLogs() {
  const data = await api('/api/logs?limit=40');
  const rows = (data.items || []).map((r) => `
    <tr>
      <td>${escapeHtml(r.ts)}</td>
      <td class="tag-${escapeHtml(r.status)}">${escapeHtml(r.status)}</td>
      <td>${r.new_count}</td>
      <td>${r.total_count}</td>
      <td>${r.duration_ms} ms</td>
      <td class="msg">${escapeHtml(r.message || '')}</td>
    </tr>`).join('');
  $('#logTable').innerHTML =
    `<thead><tr><th>时间</th><th>状态</th><th>新增</th><th>总数</th><th>耗时</th><th>说明</th></tr></thead>
     <tbody>${rows || '<tr><td colspan="6">暂无日志</td></tr>'}</tbody>`;
}

/* ----------------------------- 倒计时 ----------------------------- */

function startCountdown(nextRunAt) {
  if (state.timer) clearInterval(state.timer);
  const target = nextRunAt ? new Date(nextRunAt.replace(/-/g, '/')).getTime() : NaN;
  if (Number.isNaN(target)) { $('#pillCountdown').textContent = '下次检索 —'; return; }
  const tick = () => {
    const sec = Math.round((target - Date.now()) / 1000);
    const el = $('#pillCountdown');
    if (sec <= 0) {
      el.textContent = '即将检索…';
      el.className = 'pill countdown ok';
    } else {
      // 窄屏上省掉「检索」二字，否则三个胶囊加起来会超过一行，被截断
      const prefix = window.innerWidth < 420 ? '下次' : '下次检索';
      el.textContent = `${prefix} ${fmtCountdown(sec)}`;
      el.className = 'pill countdown';
    }
  };
  tick();
  state.timer = setInterval(tick, 1000);
}

/* ----------------------------- 详情 ----------------------------- */

/** 列表接口很「瘦」，只有名称/时间/主办方。若这条活动还没被补全过详情，就现场去补一次。 */
function needsDetail(a) {
  return !a.intro && !a.capacity && !(a.college_scope && a.college_scope.length)
    && a.credit_type === '未分类';
}

async function openDetail(id) {
  let a = await api(`/api/activities/${encodeURIComponent(id)}`);
  paintDetail(a);

  if (needsDetail(a)) {
    setDetailLoading(true);
    try {
      const r = await api(`/api/activities/${encodeURIComponent(id)}/refresh`, { method: 'POST' });
      if (r.item) { a = r.item; paintDetail(a); }
      if (!r.ok) toast(r.message || '详情补全失败', 'err');
    } catch (err) {
      toast('详情补全失败：' + err.message, 'err');
    } finally {
      setDetailLoading(false);
    }
  }
}

function setDetailLoading(on) {
  const el = document.getElementById('detailLoading');
  if (el) el.hidden = !on;
}

function paintDetail(a) {
  const ctIdx = CT_INDEX[a.credit_type];
  const ctCls = ctIdx === undefined ? '' : `ct-${ctIdx}`;
  const stateLabel = { open: '报名中', upcoming: '未开始', closed: '已截止', unknown: '状态未知' }[a.enroll_state] || '';
  const pct = a.capacity > 0 ? Math.min(100, Math.round((a.enrolled / a.capacity) * 100)) : 0;
  const barCls = pct >= 100 ? 'danger' : pct >= 80 ? 'warn' : '';

  const scopeRow = (label, arr) => arr && arr.length
    ? `<tr><td>${label}</td><td>${escapeHtml(arr.join('、'))}</td></tr>` : '';

  $('#drawerBody').innerHTML = `
    <div class="detail-loading" id="detailLoading" hidden>正在向二课系统补全该活动的报名时间、名额与简介…</div>
    <span class="detail-credit badge ${ctCls}">${escapeHtml(a.credit_type || '未分类')}</span>
    ${hoursBadge(a)}
    <span class="badge state-${a.enroll_state}">${stateLabel}</span>
    <h2 class="detail-title">${escapeHtml(a.title)}</h2>
    <div class="detail-org">🏛 ${escapeHtml(a.organizer || '组织方未标注')}</div>

    <div class="detail-section">
      <h4>活动简介</h4>
      <div class="detail-body">${escapeHtml(a.intro || '暂无简介')}</div>
    </div>

    <div class="detail-section">
      <h4>报名与名额</h4>
      <table class="detail-table">
        <tr><td>可得学时</td><td>${fmtHours(a.hours) ? fmtHours(a.hours) + ' 学时' : '未标注'}</td></tr>
        <tr><td>可报人数</td><td>${a.capacity > 0 ? a.capacity + ' 人' : '不限'}</td></tr>
        <tr><td>已报名</td><td>${a.enrolled} 人${a.capacity > 0 ? `（剩余 ${a.seats_left}）` : ''}</td></tr>
        <tr><td>报名开始</td><td>${escapeHtml(a.enroll_start_disp || '—')}</td></tr>
        <tr><td>报名截止</td><td>${escapeHtml(a.enroll_end_disp || '—')}</td></tr>
      </table>
      ${a.capacity > 0 ? `<div class="progress ${barCls}"><i style="width:${pct}%"></i></div>` : ''}
    </div>

    <div class="detail-section">
      <h4>时间与地点</h4>
      <table class="detail-table">
        <tr><td>活动时间</td><td>${escapeHtml(a.activity_start_disp || '—')}${a.activity_end ? ' 至 ' + escapeHtml(a.activity_end) : ''}</td></tr>
        <tr><td>活动地点</td><td>${escapeHtml(a.location || '—')}</td></tr>
      </table>
    </div>

    <div class="detail-section">
      <h4>报名范围</h4>
      <table class="detail-table">
        <tr><td>年级</td><td>${a.grade_scope && a.grade_scope.length ? escapeHtml(a.grade_scope.join('、')) : '不限'}</td></tr>
        <tr><td>学院</td><td>${a.college_scope && a.college_scope.length ? escapeHtml(a.college_scope.join('、')) : '全校'}</td></tr>
        <tr><td>专业</td><td>${a.major_scope && a.major_scope.length ? escapeHtml(a.major_scope.join('、')) : '不限'}</td></tr>
        <tr><td>参与组织</td><td>${a.org_scope && a.org_scope.length ? escapeHtml(a.org_scope.join('、')) : '不限'}</td></tr>
      </table>
    </div>

    <div class="detail-section">
      <h4>匹配分析（匹配度 ${a.match_score} 分）</h4>
      <div class="reasons">${(a.match_reasons || []).map((r) => `<span class="reason">${escapeHtml(r)}</span>`).join('') || '<span class="reason">—</span>'}</div>
    </div>

    <div class="detail-section">
      <table class="detail-table">
        <tr><td>首次发现</td><td>${escapeHtml(a.first_seen || '—')}</td></tr>
        <tr><td>最近刷新</td><td>${escapeHtml(a.last_seen || '—')}</td></tr>
        <tr><td>活动 ID</td><td>${escapeHtml(a.id)}</td></tr>
      </table>
    </div>

    <div class="btn-row">
      <button class="btn btn-primary" id="btnGoSignup">前往二课报名主页 ↗</button>
      <button class="btn btn-ghost" id="btnCopyLink">复制报名链接</button>
    </div>
  `;

  $('#drawer').hidden = false;
  $('#btnGoSignup').onclick = () => {
    markSeen(a.id);
    window.open(a.signup_url, '_blank', 'noopener');
  };
  $('#btnCopyLink').onclick = async () => {
    try {
      await navigator.clipboard.writeText(a.signup_url);
      toast('报名链接已复制', 'ok');
    } catch (_) { toast('复制失败，请手动复制：' + a.signup_url, 'err'); }
  };
}

async function markSeen(id) {
  try {
    await api(`/api/activities/mark-seen${id ? '?act_id=' + encodeURIComponent(id) : ''}`, { method: 'POST' });
    const item = state.items.find((x) => x.id === id);
    if (item) item.is_new = false;
  } catch (_) { /* 静默 */ }
}

/* ----------------------------- 设置面板 ----------------------------- */

function renderProfilePane() {
  const p = (state.boot.config.profile) || {};
  $('#pfGrade').value = p.grade || '';
  $('#pfCollege').value = p.college || '';
  $('#pfMajor').value = p.major || '';
  $('#pfClazz').value = p.clazz || '';
  $('#pfInclude').value = (p.keywords_include || []).join(', ');
  $('#pfExclude').value = (p.keywords_exclude || []).join(', ');

  const sel = new Set(p.credit_types || []);
  $('#pfCredits').innerHTML = CREDIT_TYPES
    .map((t) => `<button class="chip ${sel.has(t) ? 'active' : ''}" data-credit="${t}">${t}</button>`)
    .join('');
  $$('#pfCredits .chip').forEach((c) => c.addEventListener('click', () => c.classList.toggle('active')));
}

function renderAccountPane() {
  const c = state.boot.credentials || {};
  $('#vaultMode').textContent = c.mode_label || '—';
  $('#mpWrap').hidden = !c.needs_master_password;
  restorePickedSchool();
  $('#credStatus').innerHTML = c.has_credentials
    ? `当前已保存凭据：账号 <b>${escapeHtml(c.account_masked)}</b>　密码 <b>${escapeHtml(c.account_hint)}</b>　加密方式 <b>${escapeHtml(c.mode_label)}</b>`
    : '尚未保存凭据。选好学校、填入学号密码后点击「加密保存凭据」。';
}

function renderPollPane() {
  const s = state.boot.config.source || {};
  const p = state.boot.config.poll || {};
  $('#srcAdapter').value = s.adapter || 'demo';
  $('#pollInterval').value = String(p.interval_minutes || 30);
  $('#pollPages').value = p.max_pages || 5;
  $('#pollPageSize').value = p.page_size || 20;
  $('#pollJitter').value = p.jitter_seconds != null ? p.jitter_seconds : 90;
  $('#pollQuiet').value = (p.quiet_hours || []).join(', ');
}

function renderNotifyPane() {
  const n = state.boot.notify || {};
  $('#ntEnabled').checked = !!n.enabled;
  const enabled = new Set(n.channels || []);
  const avail = (n.available || []).filter((c) => c.id !== 'browser');
  $('#ntChannels').innerHTML = avail
    .map((c) => `<button class="chip ${enabled.has(c.id) ? 'active' : ''}" data-ch="${c.id}" title="${escapeHtml(c.desc)}">${escapeHtml(c.label)}</button>`)
    .join('');
  $$('#ntChannels .chip').forEach((c) => c.addEventListener('click', () => {
    c.classList.toggle('active');
    renderNotifyFields();
  }));
  renderNotifyFields();
  renderRecommendPane();
  renderNotifyStatus();
}

const NOTIFY_REQUIRED = {
  qq_mail: ['smtp_user', 'smtp_auth_code'],
  qq_bot: ['endpoint', 'target'],
  wecom_bot: ['webhook'],
  serverchan: ['send_key'],
  pushplus: ['token'],
  custom: ['url'],
};

function renderNotifyStatus() {
  const n = state.boot.notify || {};
  const have = {};
  (n.configured_keys || []).forEach((k) => {
    const [ch, key] = k.split('.');
    (have[ch] = have[ch] || []).push(key);
  });
  const labelOf = (ch) => {
    const meta = (n.available || []).find((x) => x.id === ch);
    return (meta && meta.label) || ch;
  };
  const ready = Object.keys(NOTIFY_REQUIRED).filter((ch) =>
    (NOTIFY_REQUIRED[ch] || []).every((k) => (have[ch] || []).includes(k)));

  const el = $('#ntConfigured');
  if (!ready.length) {
    el.innerHTML = '状态：<b>还没有可用的外部通道</b>。照上面的教程走一遍，配好后这里会显示「已配好」。';
    return;
  }
  const names = ready.map(labelOf).join('、');
  el.innerHTML = $('#ntEnabled').checked
    ? `状态：<b style="color:var(--green)">已配好</b> ${escapeHtml(names)}，下一轮检索有新活动就会自动发给你。`
    : `状态：<b style="color:var(--amber)">已配好</b> ${escapeHtml(names)}，但「启用外部提醒」没打开，现在不会真的发信。`;
}

const NOTIFY_FIELD_DEFS = {
  wecom_bot: [['webhook', '企业微信机器人 Webhook 地址']],
  serverchan: [['send_key', 'Server 酱 SendKey']],
  pushplus: [['token', 'PushPlus token']],
  qq_mail: [['smtp_user', 'QQ 邮箱地址（如 123456@qq.com）'],
            ['smtp_auth_code', 'SMTP 授权码（不是 QQ 密码）'],
            ['to', '收件邮箱（留空即发给自己）']],
  qq_bot: [['endpoint', 'OneBot / NapCat HTTP 接口地址'], ['token', '接口 Token（可选）'], ['target', '目标群号']],
  custom: [['url', '自定义 Webhook URL']],
};

function renderNotifyFields() {
  const chosen = $$('#ntChannels .chip.active').map((c) => c.dataset.ch);
  const avail = ((state.boot && state.boot.notify && state.boot.notify.available) || []);
  const box = $('#ntFields');
  const rows = [];
  chosen.forEach((ch) => {
    const meta = avail.find((x) => x.id === ch) || {};
    if (meta.desc) rows.push(`<p class="hint chan-hint"><b>${escapeHtml(meta.label || ch)}</b>：${escapeHtml(meta.desc)}</p>`);
    (NOTIFY_FIELD_DEFS[ch] || []).forEach(([key, label]) => {
      rows.push(`<label class="field"><span>${escapeHtml(label)}</span>
        <input data-ch="${ch}" data-key="${key}" placeholder="粘贴后点击下方保存" autocomplete="off" /></label>`);
    });
  });
  box.innerHTML = rows.join('') || '<p class="hint chan-hint">请先在上方选择至少一个通道。</p>';
}

/* ----------------------------- 学校搜索选择器 ----------------------------- */

let schoolSearchSeq = 0;

async function searchSchools(q) {
  const box = $('#schoolResults');
  const seq = ++schoolSearchSeq;
  box.hidden = false;
  box.innerHTML = '<div class="empty-opt">搜索中…</div>';
  try {
    const d = await api(`/api/schools?q=${encodeURIComponent(q)}&limit=40`);
    if (seq !== schoolSearchSeq) return;
    if (!d.items || !d.items.length) {
      box.innerHTML = '<div class="empty-opt">没有匹配的学校，换个关键词试试（如只输入「安徽」）</div>';
      return;
    }
    box.innerHTML = d.items.map((s) => `
      <div class="opt" data-id="${escapeHtml(s.id)}" data-name="${escapeHtml(s.name)}">
        <span>${escapeHtml(s.name)}</span>
        <span class="sid">schoolId ${escapeHtml(s.id)}</span>
      </div>`).join('');
    $$('#schoolResults .opt').forEach((el) => el.addEventListener('click', () => {
      pickSchool(el.dataset.id, el.dataset.name);
    }));
  } catch (e) {
    if (seq !== schoolSearchSeq) return;
    box.innerHTML = `<div class="empty-opt">拉取学校列表失败：${escapeHtml(e.message)}</div>`;
  }
}

function pickSchool(id, name) {
  $('#acSchoolId').value = id;
  $('#acSchoolSearch').value = name;
  $('#schoolResults').hidden = true;
  const box = $('#schoolPicked');
  box.hidden = false;
  box.textContent = `已选择：${name}（schoolId ${id}）`;
}

function restorePickedSchool() {
  const c = state.boot.credentials || {};
  const id = c.school_id || (state.boot.config.source || {}).school_id || '';
  if (!id) return;
  const name = c.school_name || (state.boot.config.source || {}).school_name || '';
  $('#acSchoolId').value = id;
  if (name) $('#acSchoolSearch').value = name;
  const box = $('#schoolPicked');
  box.hidden = false;
  box.textContent = `已选择：${name || '(未记录名称)'}（schoolId ${id}）`;
}

/* ----------------------------- 学院 / 年级候选 ----------------------------- */

async function loadDictSuggestions() {
  const fill = async (name, target) => {
    try {
      const d = await api(`/api/dict/${name}`);
      const items = d.items || [];
      $(target).innerHTML = items
        .map((i) => `<option value="${escapeHtml(i.name)}"></option>`).join('');
      return items.length;
    } catch (_) {
      return 0;
    }
  };
  const [nc, ng] = await Promise.all([fill('colleges', '#collegeOptions'), fill('grades', '#gradeOptions')]);
  const hint = $('#dictHint');
  if (nc || ng) {
    hint.textContent = `已从你所在学校的字典载入 ${nc} 个学院、${ng} 个年级，输入时会自动补全。`;
  } else {
    hint.textContent = '登录成功后，这里会自动载入你所在学校的学院 / 年级候选，届时输入即可下拉选择。';
  }
}

function openSettings(tab = 'profile') {
  $$('.tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === tab));
  $$('.tab-pane').forEach((p) => p.classList.toggle('active', p.dataset.pane === tab));
  renderProfilePane(); renderAccountPane(); renderPollPane(); renderNotifyPane();
  $('#settingsDrawer').hidden = false;
  loadEngineState().catch(() => {});
  loadLogs().catch(() => {});
  loadDictSuggestions().catch(() => {});
}

/* ----------------------------- 保存动作 ----------------------------- */

async function saveProfile() {
  const patch = {
    profile: {
      grade: $('#pfGrade').value.trim(),
      college: $('#pfCollege').value.trim(),
      major: $('#pfMajor').value.trim(),
      clazz: $('#pfClazz').value.trim(),
      credit_types: $$('#pfCredits .chip.active').map((c) => c.dataset.credit),
      keywords_include: $('#pfInclude').value.split(/[,，]/).map((s) => s.trim()).filter(Boolean),
      keywords_exclude: $('#pfExclude').value.split(/[,，]/).map((s) => s.trim()).filter(Boolean),
    },
  };
  await api('/api/config', { method: 'POST', body: { patch } });
  state.boot.config.profile = patch.profile;
  toast('画像已保存，下一轮检索按新条件匹配', 'ok');
  await api('/api/engine/poll?trigger=manual', { method: 'POST' }).catch(() => {});
  await refreshAll();
}

async function saveCredential() {
  const schoolId = $('#acSchoolId').value.trim();
  const body = {
    account: $('#acAccount').value.trim(),
    password: $('#acPassword').value,
    school_id: schoolId,
    school_name: schoolId ? $('#acSchoolSearch').value.trim() : '',
    master_password: $('#acMaster').value || null,
  };
  if (!schoolId) return toast('请先搜索并选择你的学校', 'warn');
  if (!body.account || !body.password) return toast('请填写学号与密码', 'warn');
  const r = await api('/api/credentials', { method: 'POST', body });
  $('#acPassword').value = '';
  $('#acMaster').value = '';
  toast('凭据已加密保存', 'ok');
  await refreshBootstrap();
  renderAccountPane();

  // 后端会顺手把「演示数据源」切成真实数据源，这里直接补一次抓取
  if (r && r.auto_switched) {
    toast('已自动切到「趣拓二课系统」并清掉演示数据，正在抓取真实活动…', 'ok');
    api('/api/engine/poll?trigger=manual', { method: 'POST' })
      .then(() => refreshAll())
      .catch(() => {});
    return;
  }

  const adapter = (state.boot.config.source || {}).adapter;
  if (adapter === 'demo') {
    toast('凭据已就绪。切到「检索策略」把数据源改成「趣拓二课系统」即可真实抓取。', 'warn');
  }
}

async function testLogin() {
  const schoolId = $('#acSchoolId').value.trim();
  if (!schoolId) return toast('请先搜索并选择你的学校', 'warn');
  const body = {
    account: $('#acAccount').value.trim(),
    password: $('#acPassword').value,
    school_id: schoolId,
  };
  const r = await api('/api/login/test', { method: 'POST', body });
  toast(r.ok ? `登录成功${r.display_name ? '：' + r.display_name : ''}` : `登录失败：${r.message}`, r.ok ? 'ok' : 'err');
  if (r.ok) {
    await refreshBootstrap();
    renderAccountPane();
    loadDictSuggestions();
  }
}

async function clearCredential() {
  if (!confirm('确定要彻底删除本地保存的账号密码吗？此操作不可撤销。')) return;
  await api('/api/credentials', { method: 'DELETE' });
  toast('本地凭据已彻底删除', 'ok');
  await refreshBootstrap();
  renderAccountPane();
}

async function savePoll() {
  const patch = {
    source: { adapter: $('#srcAdapter').value },
    poll: {
      interval_minutes: parseInt($('#pollInterval').value, 10),
      max_pages: parseInt($('#pollPages').value, 10) || 5,
      page_size: parseInt($('#pollPageSize').value, 10) || 20,
      jitter_seconds: parseInt($('#pollJitter').value, 10) || 0,
      quiet_hours: $('#pollQuiet').value.split(/[,，]/).map((s) => s.trim()).filter(Boolean),
    },
  };
  await api('/api/config', { method: 'POST', body: { patch } });
  toast('检索策略已保存', 'ok');
  await refreshBootstrap();
  await api('/api/engine/poll?trigger=manual', { method: 'POST' }).catch(() => {});
  await refreshAll();
}

async function saveNotify() {
  const chosen = $$('#ntChannels .chip.active').map((c) => c.dataset.ch);
  const settings = {};
  $$('#ntFields input').forEach((i) => {
    if (i.value.trim()) settings[`${i.dataset.ch}.${i.dataset.key}`] = i.value.trim();
  });
  // 站内提醒是内置通道、不需要任何密钥，必须始终保留，
  // 否则保存一次就会把它从 channels 里挤掉，界面上再也收不到提示。
  const channels = ['browser', ...chosen.filter((c) => c !== 'browser')];
  await api('/api/notify', {
    method: 'POST',
    body: { enabled: $('#ntEnabled').checked, channels, settings },
  });
  $$('#ntFields input').forEach((i) => { i.value = ''; });
  toast('提醒通道已保存（密钥存于加密保险箱）', 'ok');
  await refreshBootstrap();
  renderNotifyPane();
}

async function testNotify() {
  const chosen = $$('#ntChannels .chip.active').map((c) => c.dataset.ch);
  if (!chosen.length) return toast('请先选择一个通道', 'warn');
  const r = await api(`/api/notify/test?channel=${encodeURIComponent(chosen[0])}`, { method: 'POST' });
  toast(`${r.channel}：${r.ok ? '发送成功' : '发送失败 ' + r.message}`, r.ok ? 'ok' : 'err');
}

/* ----------------------------- 精选推荐 ----------------------------- */

function renderRecommendPane() {
  const rc = ((state.boot && state.boot.config && state.boot.config.recommend) || {});
  $('#rcEnabled').checked = rc.enabled !== false;
  $('#rcLimit').value = String(rc.limit || 3);
  $('#rcMinScore').value = rc.min_score != null ? rc.min_score : 35;
  $('#rcOnlyNew').checked = rc.only_when_new !== false;
}

function saveRecommend() {
  const patch = {
    recommend: {
      enabled: $('#rcEnabled').checked,
      limit: parseInt($('#rcLimit').value, 10) || 3,
      min_score: parseFloat($('#rcMinScore').value) || 0,
      only_when_new: $('#rcOnlyNew').checked,
    },
  };
  return api('/api/config', { method: 'POST', body: { patch } }).then(async () => {
    toast('推荐设置已保存', 'ok');
    await refreshBootstrap();
    renderRecommendPane();
  });
}

function rcItemHtml(a, i) {
  // 和后端 curator.explain 同一口径：过滤掉「限/排除/已满/不在/低于」这类负面理由
  const reasons = (a.match_reasons || []).filter((r) => r && !/限|排除|已满|不在|低于/.test(r)).slice(0, 3);
  const seats = a.capacity > 0 ? `余 ${a.seats_left}/${a.capacity}` : '不限人数';
  return `
    <div class="rc-item ${i === 0 ? 'top' : ''}">
      <div class="rc-head">
        <span class="rc-rank">${i === 0 ? '首选' : i + 1}</span>
        <b>${escapeHtml(a.title)}</b>
        ${a.already_recommended ? '<span class="rc-sent">已推过</span>' : ''}
      </div>
      <div class="rc-meta">
        ${escapeHtml(a.credit_type || '未分类')} · ${a.hours ? a.hours + ' 学时' : '学时未标注'} ·
        ${escapeHtml(seats)} · 报名截止 ${escapeHtml(a.enroll_end_disp || '—')} ·
        匹配 <b>${a.match_score}</b> 分
      </div>
      <div class="rc-why">${escapeHtml(reasons.join(' · ') || '符合你的年级/学院条件')}</div>
    </div>`;
}

async function previewRecommend() {
  const box = $('#rcPreview');
  box.innerHTML = '<p class="hint">正在计算…</p>';
  const r = await api('/api/recommend');
  if (!r.items || !r.items.length) {
    box.innerHTML = '<p class="hint">现在没有够格的活动：可能都满员/已截止了，或者匹配分低于门槛。'
      + '把「匹配分门槛」调低一点再看看。</p>';
    return;
  }
  const sent = r.items.filter((x) => x.already_recommended).length;
  box.innerHTML = r.items.map(rcItemHtml).join('')
    + `<p class="hint">门槛 ${r.min_score} 分 · 已推过 ${r.ledger_size} 条`
    + `${sent ? '（标「已推过」的不会再自动发，想重发点「立即发一封推荐」）' : '（这批都是没推过的）'}</p>`;
}

async function sendRecommend() {
  const btn = $('#btnRcSend');
  btn.disabled = true;
  btn.textContent = '发送中…';
  try {
    const r = await api('/api/recommend/send', { method: 'POST' });
    toast(r.message || (r.ok ? '已发送' : '发送失败'), r.ok ? 'ok' : 'warn');
    await previewRecommend();
  } finally {
    btn.disabled = false;
    btn.textContent = '立即发一封推荐';
  }
}

async function resetRecommend() {
  if (!confirm('清空推荐记录？清空后已经推送过的活动会重新参与推荐。')) return;
  const r = await api('/api/recommend/reset', { method: 'POST' });
  toast(r.message || '已清空', 'ok');
  await previewRecommend();
}

/* ----------------------------- 刷新流程 ----------------------------- */

async function refreshBootstrap() {
  state.boot = await api('/api/bootstrap');
  state.boot.config.poll = Object.assign(
    { interval_minutes: 30, interval_options: [30, 60], max_pages: 5, page_size: 20, jitter_seconds: 90, quiet_hours: [] },
    state.boot.config.poll || {},
  );
  renderSetupBar();
}

const SETUP_DISMISS_KEY = 'erke.setup.dismissed';

function renderSetupBar() {
  const bar = $('#setupBar');
  if (!bar || !state.boot) return;
  if (localStorage.getItem(SETUP_DISMISS_KEY) === '1') { bar.hidden = true; return; }

  const cred = state.boot.credentials || {};
  const n = state.boot.notify || {};
  const src = (state.boot.config && state.boot.config.source) || {};

  const todo = [];
  if (!cred.has_credentials) todo.push('登录账号');
  if ((src.adapter || 'demo') === 'demo') todo.push('把数据源切到「趣拓二课」');
  const hasChannel = (n.channels || []).some((c) => c && c !== 'browser');
  if (!hasChannel || !n.enabled) todo.push('一个提醒通道');

  if (!todo.length) { bar.hidden = true; return; }
  bar.hidden = false;
  $('#setupBarText').innerHTML =
    `还差 ${todo.length} 步就能自动收提醒：<b>${todo.map(escapeHtml).join('</b>、<b>')}</b>`;
  $('#btnSetupGo').textContent = cred.has_credentials ? '去配置提醒' : '去配置';
}

async function refreshAll() {
  await Promise.all([loadActivities(), loadStats(), loadEngineState()]);
}

async function manualRefresh() {
  const spin = $('#refreshSpin');
  spin.classList.add('on');
  $('#btnRefresh').disabled = true;
  try {
    const r = await api('/api/engine/poll?trigger=manual', { method: 'POST' });
    if (r.ok) {
      toast(`检索完成：新增 ${r.new ?? 0} 条，共 ${r.total ?? 0} 条${r.duration_ms != null ? `（${r.duration_ms} ms）` : ''}`, 'ok');
    } else {
      toast(`检索未完成：${r.message}`, 'warn');
    }
    await refreshAll();
  } catch (e) {
    toast('刷新失败：' + e.message, 'err');
  } finally {
    spin.classList.remove('on');
    $('#btnRefresh').disabled = false;
  }
}

/* ----------------------------- 事件绑定 ----------------------------- */

function bindEvents() {
  // 筛选
  $('#search').addEventListener('input', debounce((e) => {
    state.filters.keyword = e.target.value.trim();
    loadActivities().catch((err) => toast(err.message, 'err'));
  }, 280));
  $('#sortSelect').addEventListener('change', (e) => {
    state.filters.sort = e.target.value;
    loadActivities().catch(() => {});
  });
  $('#onlyMatchable').addEventListener('change', (e) => {
    state.filters.onlyMatchable = e.target.checked;
    loadActivities().catch(() => {});
  });
  $('#onlyNew').addEventListener('change', (e) => {
    state.filters.onlyNew = e.target.checked;
    loadActivities().catch(() => {});
  });

  $$('#creditChips [data-credit]').forEach((c) => c.addEventListener('click', () => {
    $$('#creditChips [data-credit]').forEach((x) => x.classList.remove('active'));
    c.classList.add('active');
    state.filters.credit = c.dataset.credit;
    loadActivities().catch(() => {});
  }));
  $$('#creditChips [data-state]').forEach((c) => c.addEventListener('click', () => {
    $$('#creditChips [data-state]').forEach((x) => x.classList.remove('active'));
    c.classList.add('active');
    state.filters.state = c.dataset.state;
    loadActivities().catch(() => {});
  }));

  // 卡片交互（事件委托）
  $('#cards').addEventListener('click', (e) => {
    const card = e.target.closest('.card');
    if (!card) return;
    const id = card.dataset.id;
    const act = e.target.closest('[data-act]');
    if (!act || act.dataset.act === 'detail') {
      openDetail(id).catch((err) => toast(err.message, 'err'));
      return;
    }
    if (act.dataset.act === 'signup') {
      const item = state.items.find((x) => x.id === id);
      if (item) {
        markSeen(id);
        window.open(item.signup_url, '_blank', 'noopener');
      }
    }
  });

  // 顶栏
  $('#btnRefresh').addEventListener('click', manualRefresh);
  $('#btnEmptyRefresh').addEventListener('click', manualRefresh);
  $('#btnSettings').addEventListener('click', () => openSettings('profile'));
  $('#btnSetupGo').addEventListener('click', () => {
    const cred = (state.boot && state.boot.credentials) || {};
    openSettings(cred.has_credentials ? 'notify' : 'account');
  });
  $('#btnSetupHide').addEventListener('click', () => {
    try { localStorage.setItem(SETUP_DISMISS_KEY, '1'); } catch (e) { /* 隐私模式下忽略 */ }
    $('#setupBar').hidden = true;
  });
  $('#btnMarkSeen').addEventListener('click', async () => {
    await api('/api/activities/mark-seen', { method: 'POST' });
    toast('已全部标记为已读', 'ok');
    await refreshAll();
  });

  // 抽屉关闭
  $$('[data-close]').forEach((el) => el.addEventListener('click', () => {
    $('#drawer').hidden = true;
    $('#settingsDrawer').hidden = true;
  }));

  // 设置页签
  $$('.tab').forEach((t) => t.addEventListener('click', () => {
    $$('.tab').forEach((x) => x.classList.remove('active'));
    t.classList.add('active');
    $$('.tab-pane').forEach((p) => p.classList.toggle('active', p.dataset.pane === t.dataset.tab));
    if (t.dataset.tab === 'runtime') { loadEngineState().catch(() => {}); loadLogs().catch(() => {}); }
  }));

  // 学校搜索选择器
  $('#acSchoolSearch').addEventListener('input', debounce((e) => {
    searchSchools(e.target.value.trim());
  }, 260));
  $('#acSchoolSearch').addEventListener('focus', () => {
    if (!$('#schoolResults').children.length) searchSchools($('#acSchoolSearch').value.trim());
  });
  $('#btnSchoolRefresh').addEventListener('click', async () => {
    try {
      const d = await api('/api/schools?refresh=true&limit=40');
      toast(`学校列表已刷新，共 ${d.total} 所`, 'ok');
      searchSchools($('#acSchoolSearch').value.trim());
    } catch (e) {
      toast('刷新失败：' + e.message, 'err');
    }
  });
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.picker')) $('#schoolResults').hidden = true;
  });

  // 保存按钮
  const guard = (fn, ok) => async () => {
    try { await fn(); } catch (e) { toast(e.message, 'err'); }
  };
  $('#btnSaveProfile').addEventListener('click', guard(saveProfile));
  $('#btnSaveCred').addEventListener('click', guard(saveCredential));
  $('#btnTestLogin').addEventListener('click', guard(testLogin));
  $('#btnClearCred').addEventListener('click', guard(clearCredential));
  $('#btnSavePoll').addEventListener('click', guard(savePoll));
  $('#btnSaveNotify').addEventListener('click', guard(saveNotify));
  $('#btnTestNotify').addEventListener('click', guard(testNotify));
  $('#ntEnabled').addEventListener('change', () => { renderNotifyFields(); renderNotifyStatus(); });
  $('#btnRcSave').addEventListener('click', guard(saveRecommend));
  $('#btnRcPreview').addEventListener('click', guard(previewRecommend));
  $('#btnRcSend').addEventListener('click', guard(sendRecommend));
  $('#btnRcReset').addEventListener('click', guard(resetRecommend));

  // 配置向导：点「用这个通道 →」直接帮你选中并滚到参数区
  document.addEventListener('click', (e) => {
    const pick = e.target.closest('[data-guide-pick]');
    if (pick) { pickGuideChannel(pick.dataset.guidePick); return; }
    const thumb = e.target.closest('.gfig img');
    if (thumb) { openImgViewer(thumb.src, thumb.alt); return; }
    if (e.target.closest('[data-imgclose]')) closeImgViewer();
  });

  // ESC 关闭（先关图片，再关抽屉）
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (!$('#imgViewer').hidden) { closeImgViewer(); return; }
      $('#drawer').hidden = true;
      $('#settingsDrawer').hidden = true;
    }
    // Ctrl/⌘ + , 随时打开设置
    if ((e.ctrlKey || e.metaKey) && e.key === ',') {
      e.preventDefault();
      openSettings('profile');
    }
  });
}

/* ----------------------------- 教程联动 ----------------------------- */

const GUIDE_CHANNEL_LABEL = { qq_mail: 'QQ 邮箱', qq_bot: 'QQ 机器人' };

function pickGuideChannel(ch) {
  const chips = $$('#ntChannels .chip');
  if (!chips.length) return toast('通道列表还没加载完，稍等一下再点', 'warn');
  chips.forEach((c) => c.classList.toggle('active', c.dataset.ch === ch));
  renderNotifyFields();

  const anchor = $('#ntChannels');
  anchor.scrollIntoView({ behavior: 'smooth', block: 'center' });
  anchor.classList.remove('flash');
  void anchor.offsetWidth;
  anchor.classList.add('flash');

  const first = $('#ntFields input');
  if (first) setTimeout(() => first.focus({ preventScroll: true }), 340);

  const label = GUIDE_CHANNEL_LABEL[ch] || ch;
  if ($('#ntEnabled').checked) {
    toast(`已选中「${label}」，填好下面两项后点「保存通道」`, 'ok');
  } else {
    toast(`已选中「${label}」，别忘了勾上「启用外部提醒」再保存`, 'warn');
  }
}

function openImgViewer(src, alt) {
  const box = $('#imgViewer');
  const img = $('#imgViewerSrc');
  img.src = src;
  img.alt = alt || '配置示意图';
  box.hidden = false;
  document.body.style.overflow = 'hidden';
}

function closeImgViewer() {
  $('#imgViewer').hidden = true;
  $('#imgViewerSrc').removeAttribute('src');
  document.body.style.overflow = '';
}

/* ----------------------------- 启动 ----------------------------- */

async function boot() {
  bindEvents();
  try {
    await refreshBootstrap();
    renderEngineBadges((await loadEngineState()) || { adapter: 'demo', running: false });
    await refreshAll();
    loadLogs().catch(() => {});
    toast('已连接本机助手服务', 'ok');
  } catch (e) {
    toast('初始化失败：' + e.message, 'err');
  }
  // 每 60 秒自动刷新一次界面数据（与后端检索节奏解耦）
  setInterval(() => { refreshAll().catch(() => {}); }, 60000);
  setInterval(() => { if (!$('#settingsDrawer').hidden) loadLogs().catch(() => {}); }, 30000);
}

document.addEventListener('DOMContentLoaded', boot);
