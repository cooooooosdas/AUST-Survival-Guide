"""Desktop launcher entry point for bilibili-fav-classifier.

Thin shim: environment setup + delegate to the ui package.
"""
from __future__ import annotations

import sys
from pathlib import Path

# Allow running both as `python launcher.py` and as a frozen exe
sys.path.insert(0, str(Path(__file__).parent))

from bilibili_fav_classifier import paths
from bilibili_fav_classifier.collect import setup_frozen_env

paths.migrate_legacy_data()


def main():
    from ui.app import main as ui_main

    ui_main()


if __name__ == "__main__":
    setup_frozen_env()
    main()
