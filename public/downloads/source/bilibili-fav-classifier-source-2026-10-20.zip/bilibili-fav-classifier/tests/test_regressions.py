"""Regression tests for bugs fixed in the v2.0 refactor.

Covers:
- apply: dry-run (move=False / missing) must NOT call any move/create API
- apply: corrupted plan.json handled gracefully (no traceback)
- apply: videos without numeric ids are skipped, not sent as "BVxxxx:2"
- session: HttpClient.get returns error dict on network failure
- plan: load_plan validation and safe defaults
- config: save_user_config merges (preserves DeepSeek key etc.)
"""
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from bilibili_fav_classifier.apply import apply
from bilibili_fav_classifier.plan import PlanError, load_plan
from bilibili_fav_classifier.session import HttpClient


class _FakeHttp:
    def __init__(self, responses=None):
        self.responses = responses or {}
        self.calls: list[dict] = []

    def get(self, url):
        self.calls.append({"method": "get", "url": url})
        return self.responses.get(url, {"data": {"list": []}})

    def post(self, url, data):
        self.calls.append({"method": "post", "url": url, "data": data})
        return self.responses.get(url, {"code": 0, "data": {"id": 1}})


def _write_plan(tmp_path, plan) -> Path:
    p = tmp_path / "plan.json"
    p.write_text(json.dumps(plan, ensure_ascii=False), encoding="utf-8")
    return p


class TestApplyDryRun:
    def test_move_false_makes_no_post_calls(self, tmp_path):
        """Preview mode must be a real dry-run (was: still POSTed moves)."""
        plan_file = _write_plan(tmp_path, {
            "move": False,
            "groups": {"AI与编程技术": [{"id": 1, "bvid": "BV1"}]},
        })
        http = _FakeHttp()
        apply(http, "csrf", plan_path=plan_file, log_path=tmp_path / "log.json")
        assert not any(c["method"] == "post" for c in http.calls)

    def test_missing_move_defaults_to_preview(self, tmp_path):
        """Missing 'move' key must default to preview (was: True)."""
        plan_file = _write_plan(tmp_path, {
            "groups": {"音乐": [{"id": 1, "bvid": "BV1"}]},
        })
        http = _FakeHttp()
        apply(http, "csrf", plan_path=plan_file, log_path=tmp_path / "log.json")
        assert not any(c["method"] == "post" for c in http.calls)


class TestApplyRobustness:
    def test_corrupted_plan_returns_empty_log(self, tmp_path, capsys):
        plan_file = tmp_path / "plan.json"
        plan_file.write_text("{not valid json", encoding="utf-8")
        http = _FakeHttp()
        result = apply(http, "csrf", plan_path=plan_file,
                       log_path=tmp_path / "log.json")
        assert result == []
        assert "错误" in capsys.readouterr().out

    def test_missing_plan_returns_empty_log(self, tmp_path):
        http = _FakeHttp()
        result = apply(http, "csrf", plan_path=tmp_path / "nope.json",
                       log_path=tmp_path / "log.json")
        assert result == []

    def test_invalid_ids_are_skipped(self, tmp_path):
        """Entries without numeric ids must not be sent as 'BVxxxx:2'."""
        plan_file = _write_plan(tmp_path, {
            "move": True,
            "groups": {"音乐": [
                {"id": 123, "bvid": "BV1"},
                {"id": None, "bvid": "BV2"},   # no usable id
                {"bvid": "BV3"},                # missing id entirely
            ]},
        })
        http = _FakeHttp({
            "https://api.bilibili.com/x/v3/fav/folder/add": {"code": 0, "data": {"id": 7}},
        })
        apply(http, "csrf", plan_path=plan_file, log_path=tmp_path / "log.json")
        move_calls = [c for c in http.calls
                      if c["method"] == "post" and "resource/move" in c["url"]]
        assert len(move_calls) == 1
        assert move_calls[0]["data"]["resources"] == "123:2"
        log = json.loads((tmp_path / "log.json").read_text(encoding="utf-8"))
        assert log[0]["skipped"] == 2
        assert log[0]["moved"] == 1


class TestHttpClientGet:
    def test_get_network_error_returns_error_dict(self, monkeypatch):
        """HttpClient.get must not raise (was: bare requests.get)."""
        def _boom(url, **kw):
            raise ConnectionError("no network")

        monkeypatch.setattr("requests.get", _boom)
        result = HttpClient(cookies={}).get("https://api.example.com/x")
        assert result.get("_error") is True

    def test_get_non_json_returns_waf_dict(self, monkeypatch):
        class _Resp:
            headers = {"content-type": "text/html"}
            status_code = 412

        monkeypatch.setattr("requests.get", lambda url, **kw: _Resp())
        result = HttpClient(cookies={}).get("https://api.example.com/x")
        assert result.get("_waf_html") is True


class TestLoadPlan:
    def test_missing_raises_plan_error(self, tmp_path):
        with pytest.raises(PlanError):
            load_plan(tmp_path / "missing.json")

    def test_corrupted_raises_plan_error(self, tmp_path):
        p = tmp_path / "plan.json"
        p.write_text("###", encoding="utf-8")
        with pytest.raises(PlanError):
            load_plan(p)

    def test_missing_move_defaults_false(self, tmp_path):
        p = _write_plan(tmp_path, {"groups": {}})
        assert load_plan(p)["move"] is False


class TestConfigMerge:
    def test_save_user_config_preserves_other_keys(self, tmp_path, monkeypatch):
        import bilibili_fav_classifier.config as config_mod

        cfg_file = tmp_path / "config.json"
        cfg_file.write_text(json.dumps({
            "USER_MID": "old", "DEFAULT_FAV_ID": 1,
            "DEEPSEEK_API_KEY": "sk-secret", "CLASSIFY_MODE": "ai",
        }, ensure_ascii=False), encoding="utf-8")
        monkeypatch.setattr(config_mod, "CONFIG_FILE", cfg_file)

        config_mod.save_user_config("new_mid", 42)
        cfg = json.loads(cfg_file.read_text(encoding="utf-8"))
        assert cfg["USER_MID"] == "new_mid"
        assert cfg["DEFAULT_FAV_ID"] == 42
        assert cfg["DEEPSEEK_API_KEY"] == "sk-secret"  # preserved
        assert cfg["CLASSIFY_MODE"] == "ai"            # preserved

    def test_invalid_mode_falls_back_to_local(self, tmp_path, monkeypatch):
        import bilibili_fav_classifier.config as config_mod

        cfg_file = tmp_path / "config.json"
        cfg_file.write_text(json.dumps({"CLASSIFY_MODE": "bogus"}),
                            encoding="utf-8")
        monkeypatch.setattr(config_mod, "CONFIG_FILE", cfg_file)
        assert config_mod.load_config()["CLASSIFY_MODE"] == "local"


class TestPlanPathResolution:
    """plan.py must resolve paths through config at call time.

    Freezing PLAN_JSON at import time silently ignored later overrides
    (test fixtures, dev tools), so results pages read the real file.
    """

    def test_load_plan_follows_config_override(self, tmp_path, monkeypatch):
        import bilibili_fav_classifier.config as config_mod
        from bilibili_fav_classifier.plan import load_plan

        plan_file = tmp_path / "plan.json"
        plan_file.write_text(json.dumps({
            "move": True, "groups": {"音乐": [{"id": 1, "bvid": "BV1"}]},
        }, ensure_ascii=False), encoding="utf-8")
        monkeypatch.setattr(config_mod, "PLAN_JSON", plan_file)

        assert load_plan()["groups"]["音乐"][0]["bvid"] == "BV1"

    def test_load_favs_follows_config_override(self, tmp_path, monkeypatch):
        import bilibili_fav_classifier.config as config_mod
        from bilibili_fav_classifier.plan import load_favs

        favs_file = tmp_path / "favs.json"
        favs_file.write_text(json.dumps({
            "videos": [{"bvid": "BV9", "title": "标题"}],
        }, ensure_ascii=False), encoding="utf-8")
        monkeypatch.setattr(config_mod, "FAVS_JSON", favs_file)

        assert load_favs()["videos"][0]["title"] == "标题"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
