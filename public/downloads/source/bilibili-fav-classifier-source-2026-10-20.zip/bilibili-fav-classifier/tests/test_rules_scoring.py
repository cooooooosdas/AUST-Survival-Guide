"""Tests for the v2 scoring matcher and mixed-text word boundaries.

v1 behavior being fixed:
- Word-boundary protection only applied to pure-English text; any Chinese
  character in the title downgraded ALL keywords to substring matching,
  so "ai" matched "again" in "again again 再来一次".
- First-hit-wins let one weak keyword override multiple strong signals.
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from bilibili_fav_classifier.rules import (
    ALL_FOLDERS,
    KEYWORD_RULES,
    TAG_RULES,
    keyword_classify,
    tag_match,
)


class TestMixedTextBoundaries:
    """ASCII keywords in Chinese-mixed text must keep word boundaries."""

    def test_ai_not_in_again_mixed(self):
        assert keyword_classify("again 我们再见面") is None

    def test_ai_not_in_available_mixed(self):
        assert keyword_classify("available 可用性测试") is None

    def test_ai_matches_standalone_mixed(self):
        assert keyword_classify("这个AI太聪明了") == "AI与编程技术"

    def test_go_not_in_good_mixed(self):
        assert keyword_classify("good 好书推荐") is None

    def test_mc_not_in_music_mixed(self):
        assert keyword_classify("music 音乐现场") == "音乐"  # via 音乐 kw

    def test_rag_not_in_dragons_mixed(self):
        assert keyword_classify("dragons 驯龙高手") is None

    def test_mv_matches_standalone(self):
        assert keyword_classify("全新MV首发") == "音乐"

    def test_mv_not_in_random_substring(self):
        # "mv" inside a longer ascii token must not match
        assert keyword_classify("amvp 测试") is None


class TestScoring:
    """Multiple keyword hits should beat a single weak hit."""

    def test_multi_hit_beats_single_hit(self):
        """A title with 3 sports keywords beats 1 stray keyword."""
        # "健身 跑步 马拉松" = 3 sports hits; "记录" = 1 life hit
        title = "健身跑步马拉松训练记录"
        assert keyword_classify(title) == "体育"

    def test_multi_tags_vote(self):
        """Tags voting 2-vs-1: majority folder wins."""
        # 篮球 + 健身 -> 体育 (2), 记录 -> 生活与社会 (1)
        assert tag_match(["篮球", "健身", "记录"]) == "体育"

    def test_tie_broken_by_rule_order(self):
        """Equal scores -> earlier TAG_RULE wins (regression guard)."""
        assert tag_match(["美食", "Python"]) == "AI与编程技术"

    def test_single_hit_still_works(self):
        assert tag_match(["Python"]) == "AI与编程技术"

    def test_no_match_returns_none(self):
        assert keyword_classify("哈哈哈哈哈哈") is None
        assert tag_match(["xyzabc"]) is None


class TestRuleHygiene:
    """Structural checks on the rule data itself."""

    def test_no_duplicate_keywords_within_tag_rules(self):
        seen: dict[str, str] = {}
        dups = []
        for rule_str, folder in TAG_RULES:
            for kw in rule_str.split("/"):
                kw = kw.strip().lower()
                if kw and kw in seen:
                    dups.append((kw, seen[kw], folder))
                seen.setdefault(kw, folder)
        assert dups == [], f"duplicate tag keywords: {dups}"

    def test_no_duplicate_keywords_within_keyword_rules(self):
        seen: dict[str, str] = {}
        dups = []
        for rule_str, folder in KEYWORD_RULES:
            for kw in rule_str.split("/"):
                kw = kw.strip().lower()
                if kw and kw in seen:
                    dups.append((kw, seen[kw], folder))
                seen.setdefault(kw, folder)
        assert dups == [], f"duplicate title keywords: {dups}"

    def test_no_empty_keywords(self):
        for rule_str, _folder in TAG_RULES + KEYWORD_RULES:
            assert all(kw.strip() for kw in rule_str.split("/"))

    def test_all_rule_folders_are_known(self):
        known = set(ALL_FOLDERS)
        for _rule_str, folder in TAG_RULES + KEYWORD_RULES:
            assert folder in known, f"unknown folder: {folder}"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
