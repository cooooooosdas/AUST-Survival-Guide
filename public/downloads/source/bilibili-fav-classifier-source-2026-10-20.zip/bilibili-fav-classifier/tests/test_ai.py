"""Tests for ai.py: DeepSeek client, batch classification, result merging.

Network is mocked throughout — these tests run fully offline.
"""
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from bilibili_fav_classifier import ai
from bilibili_fav_classifier.ai import (
    AIAuthError,
    AINetworkError,
    AIResponseError,
    DeepSeekClient,
    ai_classify_videos,
    apply_ai_results,
    merge_ai_results,
)
from bilibili_fav_classifier.classify_core import ClassifyResult


# ── HTTP mocking helpers ─────────────────────────────────────────

class _Resp:
    def __init__(self, status=200, payload=None):
        self.status_code = status
        self._payload = payload or {}

    def json(self):
        return self._payload


def _ok_payload(results):
    return {
        "choices": [{
            "message": {"content": json.dumps({"results": results},
                                              ensure_ascii=False)}
        }]
    }


def _patch_http(monkeypatch, handler):
    monkeypatch.setattr(ai.requests, "post", handler)


# ── DeepSeekClient ───────────────────────────────────────────────

class TestDeepSeekClient:
    def test_chat_success(self, monkeypatch):
        captured = {}

        def _post(url, headers=None, json=None, timeout=None):
            captured["url"] = url
            captured["key"] = headers["Authorization"]
            return _Resp(200, _ok_payload([{"bvid": "BV1", "folder": "音乐",
                                            "clean_title": "x", "summary": "y"}]))

        _patch_http(monkeypatch, _post)
        client = DeepSeekClient("sk-test")
        out = client.chat([{"role": "user", "content": "hi"}], json_mode=True)
        assert "BV1" in out
        assert captured["key"] == "Bearer sk-test"
        assert captured["url"] == "https://api.deepseek.com/chat/completions"

    def test_401_raises_auth_error(self, monkeypatch):
        _patch_http(monkeypatch, lambda *a, **kw: _Resp(401, {}))
        with pytest.raises(AIAuthError):
            DeepSeekClient("bad-key").chat([{"role": "user", "content": "x"}])

    def test_network_error_raises(self, monkeypatch):
        import requests as rq

        def _boom(*a, **kw):
            raise rq.exceptions.ConnectionError("no network")

        _patch_http(monkeypatch, _boom)
        with pytest.raises(AINetworkError):
            DeepSeekClient("k").chat([{"role": "user", "content": "x"}])

    def test_500_raises_response_error(self, monkeypatch):
        _patch_http(monkeypatch, lambda *a, **kw: _Resp(500, {}))
        with pytest.raises(AIResponseError):
            DeepSeekClient("k").chat([{"role": "user", "content": "x"}])

    def test_malformed_payload_raises(self, monkeypatch):
        _patch_http(monkeypatch, lambda *a, **kw: _Resp(200, {"unexpected": 1}))
        with pytest.raises(AIResponseError):
            DeepSeekClient("k").chat([{"role": "user", "content": "x"}])

    def test_verify_key_success(self, monkeypatch):
        _patch_http(monkeypatch, lambda *a, **kw: _Resp(200, _ok_payload([])))
        ok, msg = DeepSeekClient("sk-good").verify_key()
        assert ok is True

    def test_verify_key_invalid(self, monkeypatch):
        _patch_http(monkeypatch, lambda *a, **kw: _Resp(401, {}))
        ok, msg = DeepSeekClient("sk-bad").verify_key()
        assert ok is False
        assert "无效" in msg

    def test_verify_key_no_network(self, monkeypatch):
        import requests as rq

        def _boom(*a, **kw):
            raise rq.exceptions.Timeout("timeout")

        _patch_http(monkeypatch, _boom)
        ok, msg = DeepSeekClient("k").verify_key()
        assert ok is False
        assert "网络" in msg

    def test_verify_key_empty(self):
        ok, _msg = DeepSeekClient("").verify_key()
        assert ok is False


# ── ai_classify_videos ───────────────────────────────────────────

def _videos(n):
    return [{"bvid": f"BV{i}", "title": f"视频{i}", "upper": "UP",
             "tname": "", "tags": []} for i in range(n)]


class TestAiClassifyVideos:
    def test_happy_path(self, monkeypatch):
        monkeypatch.setattr(ai, "BATCH_SIZE", 2)
        results = [
            {"bvid": f"BV{i}", "folder": "音乐",
             "clean_title": f"干净标题{i}", "summary": f"摘要{i}"}
            for i in range(4)
        ]
        _patch_http(monkeypatch, lambda *a, **kw: _Resp(200, _ok_payload(results)))
        ai_map, errors = ai_classify_videos(_videos(4), DeepSeekClient("k"))
        assert errors == []
        assert len(ai_map) == 4
        assert ai_map["BV0"]["folder"] == "音乐"
        assert ai_map["BV0"]["clean_title"] == "干净标题0"

    def test_invalid_folder_coerced_to_other(self, monkeypatch):
        results = [{"bvid": "BV0", "folder": "不存在的分类",
                    "clean_title": "x", "summary": "y"}]
        _patch_http(monkeypatch, lambda *a, **kw: _Resp(200, _ok_payload(results)))
        ai_map, _ = ai_classify_videos(_videos(1), DeepSeekClient("k"))
        assert ai_map["BV0"]["folder"] == "其他"

    def test_auth_error_aborts_immediately(self, monkeypatch):
        monkeypatch.setattr(ai, "BATCH_SIZE", 1)
        calls = []

        def _post(*a, **kw):
            calls.append(1)
            return _Resp(401, {})

        _patch_http(monkeypatch, _post)
        monkeypatch.setattr(ai.time, "sleep", lambda s: None)
        ai_map, errors = ai_classify_videos(_videos(3), DeepSeekClient("k"))
        assert ai_map == {}
        assert any("无效" in e for e in errors)
        assert len(calls) == 1  # no retries on auth failure

    def test_batch_failure_isolated(self, monkeypatch):
        """One failing batch must not kill the rest."""
        monkeypatch.setattr(ai, "BATCH_SIZE", 1)
        state = {"n": 0}

        def _post(*a, **kw):
            state["n"] += 1
            if state["n"] <= 2:  # first batch fails twice (retry+fail)
                return _Resp(500, {})
            return _Resp(200, _ok_payload([
                {"bvid": "BV1", "folder": "音乐", "clean_title": "t", "summary": "s"}
            ]))

        _patch_http(monkeypatch, _post)
        monkeypatch.setattr(ai.time, "sleep", lambda s: None)
        monkeypatch.setattr(ai, "MAX_RETRIES", 1)
        ai_map, errors = ai_classify_videos(_videos(2), DeepSeekClient("k"))
        assert "BV1" in ai_map          # second batch still succeeded
        assert any("批次 1" in e for e in errors)

    def test_dirty_json_tolerated(self, monkeypatch):
        """Model wrapping JSON in markdown fences is tolerated."""
        payload = {"choices": [{"message": {"content":
            "```json\n{\"results\": [{\"bvid\": \"BV0\", \"folder\": \"体育\","
            " \"clean_title\": \"t\", \"summary\": \"s\"}]}\n```"}}]}
        _patch_http(monkeypatch, lambda *a, **kw: _Resp(200, payload))
        ai_map, errors = ai_classify_videos(_videos(1), DeepSeekClient("k"))
        assert ai_map["BV0"]["folder"] == "体育"

    def test_unparseable_response_reported(self, monkeypatch):
        payload = {"choices": [{"message": {"content": "完全不是JSON"}}]}
        _patch_http(monkeypatch, lambda *a, **kw: _Resp(200, payload))
        ai_map, errors = ai_classify_videos(_videos(1), DeepSeekClient("k"))
        assert ai_map == {}
        assert any("解析失败" in e for e in errors)

    def test_stop_event_halts(self, monkeypatch):
        import threading
        monkeypatch.setattr(ai, "BATCH_SIZE", 1)
        stop = threading.Event()
        stop.set()
        ai_map, errors = ai_classify_videos(_videos(5), DeepSeekClient("k"),
                                            stop_event=stop)
        assert ai_map == {}
        assert any("停止" in e for e in errors)


# ── apply_ai_results ─────────────────────────────────────────────

class TestApplyAiResults:
    def _local_result(self):
        return ClassifyResult(
            groups={
                "音乐": [{"bvid": "BV1", "title": "a"}],
                "其他": [{"bvid": "BV2", "title": "b"}],
            },
            layer_counts={"tag": 1, "fallback": 1},
            unmatched_ups={"UP": ["b"]},
            duplicate_ups={},
            total=2,
        )

    def test_ai_moves_video_and_counts_layer(self):
        result = self._local_result()
        merged = apply_ai_results(result, {
            "BV2": {"folder": "体育", "clean_title": "b", "summary": "s"},
        })
        assert [v["bvid"] for v in merged.groups["体育"]] == ["BV2"]
        assert merged.groups.get("其他") in (None, [])
        assert merged.layer_counts == {"ai": 1, "local": 1}
        assert merged.total == 2

    def test_videos_without_ai_result_keep_local_folder(self):
        result = self._local_result()
        merged = apply_ai_results(result, {})
        assert merged.groups["音乐"][0]["bvid"] == "BV1"
        assert merged.groups["其他"][0]["bvid"] == "BV2"
        assert merged.layer_counts["local"] == 2


# ── cache ────────────────────────────────────────────────────────

class TestAiResultCache:
    def test_merge_persists_and_keeps_old(self, tmp_path):
        p = tmp_path / "ai_results.json"
        merge_ai_results({"BV1": {"folder": "音乐", "clean_title": "a",
                                  "summary": "s"}}, p)
        merged = merge_ai_results({"BV2": {"folder": "体育", "clean_title": "b",
                                           "summary": "s"}}, p)
        assert set(merged) == {"BV1", "BV2"}
        on_disk = json.loads(p.read_text(encoding="utf-8"))
        assert set(on_disk) == {"BV1", "BV2"}


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
