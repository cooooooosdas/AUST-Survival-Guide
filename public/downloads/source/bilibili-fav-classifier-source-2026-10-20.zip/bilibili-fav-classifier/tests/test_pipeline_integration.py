"""Integration tests for bilibili_fav_classifier.pipeline.Pipeline.

These tests verify the unified pipeline orchestrator:
- Executes all 4 steps in order
- Emits exactly ONE terminal 'done' event (no state overwrite)
- Aborts on collect/classify failure (fatal steps)
- Continues past enrich failure (non-fatal, accuracy-only step)
- Stops cleanly on user interrupt
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from bilibili_fav_classifier.pipeline import Pipeline


def _make_pipeline(monkeypatch, **step_overrides):
    """Create a Pipeline with all steps replaced by recorders.

    step_overrides: step_name -> callable(self) returning bool/None
    or raising. Default steps succeed and record execution.
    """
    events = []
    executed = []
    pipe = Pipeline(lambda kind, payload: events.append((kind, payload)))

    for name in ("collect", "enrich", "classify", "apply"):
        attr = f"_step_{name}"
        override = step_overrides.get(name)
        if override is None:
            def _default(self, _name=name):
                executed.append(_name)
                return True
            monkeypatch.setattr(Pipeline, attr, _default)
        else:
            def _wrap(self, _name=name, _fn=override):
                executed.append(_name)
                return _fn(self)
            monkeypatch.setattr(Pipeline, attr, _wrap)

    return pipe, executed, events


def _terminal_events(events):
    return [p for k, p in events if k == "done"]


class TestStepOrder:
    def test_all_four_steps_execute_in_order(self, monkeypatch):
        pipe, executed, events = _make_pipeline(monkeypatch)
        outcome = pipe.run()
        assert executed == ["collect", "enrich", "classify", "apply"]
        assert outcome.status == "success"

    def test_exactly_one_terminal_event(self, monkeypatch):
        """Regression: v1.x emitted done('error') then done('success'),
        causing the GUI to show 'error' then overwrite with 'success'."""
        pipe, _executed, events = _make_pipeline(monkeypatch)
        pipe.run()
        terminal = _terminal_events(events)
        assert terminal == ["success"]


class TestFatalSteps:
    def test_collect_failure_aborts_pipeline(self, monkeypatch):
        """Regression: v1.x continued to enrich/classify/apply after a
        collect failure and finally reported success over the error."""
        pipe, executed, events = _make_pipeline(
            monkeypatch, collect=lambda self: False,
        )
        outcome = pipe.run()
        assert executed == ["collect"]
        assert outcome.status == "error"
        assert _terminal_events(events) == ["error"]

    def test_classify_failure_aborts_before_apply(self, monkeypatch):
        pipe, executed, events = _make_pipeline(
            monkeypatch, classify=lambda self: False,
        )
        outcome = pipe.run()
        assert executed == ["collect", "enrich", "classify"]
        assert outcome.status == "error"
        assert _terminal_events(events) == ["error"]

    def test_apply_failure_reports_error(self, monkeypatch):
        pipe, _executed, events = _make_pipeline(
            monkeypatch, apply=lambda self: False,
        )
        outcome = pipe.run()
        assert outcome.status == "error"
        assert _terminal_events(events) == ["error"]

    def test_unexpected_exception_becomes_error(self, monkeypatch):
        def _boom(self):
            raise RuntimeError("unexpected")

        pipe, executed, events = _make_pipeline(monkeypatch, collect=_boom)
        outcome = pipe.run()
        assert outcome.status == "error"
        assert _terminal_events(events) == ["error"]


class TestEnrichNonFatal:
    def test_enrich_failure_pipeline_continues(self, monkeypatch):
        """Enrich only boosts accuracy; its failure must not abort the
        pipeline (regression guard for v1.2.1)."""
        def _enrich_fails(self):
            raise RuntimeError("enrich boom")

        pipe, executed, events = _make_pipeline(
            monkeypatch, enrich=_enrich_fails,
        )
        outcome = pipe.run()
        assert executed == ["collect", "enrich", "classify", "apply"]
        assert outcome.status == "success"
        assert _terminal_events(events) == ["success"]


class TestUserStop:
    def test_stop_after_collect(self, monkeypatch):
        pipe, executed, events = _make_pipeline(monkeypatch)

        real_step = Pipeline._step_enrich  # not used; stop before enrich

        def _collect_and_stop(self):
            executed.append("collect")
            self.stop()
            return True

        monkeypatch.setattr(Pipeline, "_step_collect", _collect_and_stop)
        outcome = pipe.run()
        assert executed == ["collect"]
        assert outcome.status == "stopped"
        assert _terminal_events(events) == ["stopped"]

    def test_do_apply_false_skips_apply(self, monkeypatch):
        events = []
        executed = []
        pipe = Pipeline(lambda k, p: events.append((k, p)), do_apply=False)
        for name in ("collect", "enrich", "classify"):
            def _ok(self, _name=name):
                executed.append(_name)
                return True
            monkeypatch.setattr(Pipeline, f"_step_{name}", _ok)
        def _apply(self):
            executed.append("apply")
            return True
        monkeypatch.setattr(Pipeline, "_step_apply", _apply)

        outcome = pipe.run()
        assert "apply" not in executed
        assert outcome.status == "success"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
