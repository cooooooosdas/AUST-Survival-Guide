"""Tests for server.py: LAN web server API (loopback HTTP, offline).

Uses a real ThreadingHTTPServer on an ephemeral port; no external
network access involved.
"""
import json
import sys
import urllib.request
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from bilibili_fav_classifier.controller import PipelineController
from bilibili_fav_classifier.server import LanServer


@pytest.fixture()
def server(tmp_path, monkeypatch):
    """Running LanServer with isolated config/seed files."""
    import bilibili_fav_classifier.config as config_mod

    monkeypatch.setattr(config_mod, "CONFIG_FILE", tmp_path / "config.json")
    monkeypatch.setattr(config_mod, "SEED_FILE", tmp_path / "seed.json")
    # server.py imported the functions directly; patch module attrs too
    import bilibili_fav_classifier.server as server_mod
    monkeypatch.setattr(server_mod, "load_config", config_mod.load_config)
    monkeypatch.setattr(server_mod, "save_config", config_mod.save_config)

    srv = LanServer(PipelineController(), port=0, host="127.0.0.1")
    ok, _ = srv.start()
    assert ok
    yield srv
    srv.stop()


def _get(srv, path):
    with urllib.request.urlopen(f"http://127.0.0.1:{srv.port}{path}") as r:
        return json.loads(r.read().decode("utf-8"))


def _post(srv, path, body=None):
    req = urllib.request.Request(
        f"http://127.0.0.1:{srv.port}{path}",
        data=json.dumps(body or {}).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode("utf-8"))


class TestStaticAndStatus:
    def test_index_served(self, server):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{server.port}/") as r:
            html = r.read().decode("utf-8")
        assert "收藏夹智能分类" in html

    def test_status_shape(self, server):
        s = _get(server, "/api/status")
        assert s["running"] is False
        assert s["step_names"] == ["拉取", "补充", "分类", "应用"]
        assert "progress" in s and "detail" in s

    def test_logs_incremental(self, server):
        server.controller._handle_event("log", "第一行")
        server.controller._handle_event("log", "第二行")
        r1 = _get(server, "/api/logs?since=0")
        assert r1["logs"] == ["第一行", "第二行"]
        r2 = _get(server, f"/api/logs?since={r1['next']}")
        assert r2["logs"] == []

    def test_404(self, server):
        with pytest.raises(urllib.error.HTTPError) as exc:
            _get(server, "/api/nope")
        assert exc.value.code == 404


class TestConfigApi:
    def test_get_masks_api_key(self, server, monkeypatch):
        import bilibili_fav_classifier.config as config_mod
        config_mod.save_config({"DEEPSEEK_API_KEY": "sk-1234567890abcd"})
        cfg = _get(server, "/api/config")
        assert "DEEPSEEK_API_KEY" not in cfg          # never leaks raw key
        assert cfg["has_api_key"] is True
        assert "..." in cfg["DEEPSEEK_API_KEY_MASKED"]

    def test_post_saves_valid_keys(self, server):
        code, r = _post(server, "/api/config", {
            "CLASSIFY_MODE": "hybrid", "DEEPSEEK_API_KEY": "sk-x",
            "EVIL_KEY": "ignored",
        })
        assert code == 200 and r["ok"]
        import bilibili_fav_classifier.config as config_mod
        cfg = config_mod.load_config()
        assert cfg["CLASSIFY_MODE"] == "hybrid"
        assert cfg["DEEPSEEK_API_KEY"] == "sk-x"
        assert "EVIL_KEY" not in cfg

    def test_post_rejects_bad_mode(self, server):
        code, r = _post(server, "/api/config", {"CLASSIFY_MODE": "bogus"})
        assert code == 400

    def test_post_rejects_bad_port(self, server):
        code, _ = _post(server, "/api/config", {"SERVER_PORT": 80})
        assert code == 400


class TestSeedMappingsApi:
    def test_roundtrip(self, server, monkeypatch):
        import bilibili_fav_classifier.server as server_mod
        import bilibili_fav_classifier.config as config_mod
        monkeypatch.setattr(server_mod, "load_seed_mappings",
                            config_mod.load_seed_mappings)
        monkeypatch.setattr(server_mod, "save_seed_mappings",
                            config_mod.save_seed_mappings)
        _post(server, "/api/seed_mappings", {"音乐": ["UP主甲"]})
        assert _get(server, "/api/seed_mappings") == {"音乐": ["UP主甲"]}


class TestStartStop:
    def test_start_conflict_returns_409(self, server):
        server.controller._running = True  # simulate running pipeline
        code, r = _post(server, "/api/start", {})
        assert code == 409
        assert r["ok"] is False

    def test_stop_when_idle(self, server):
        code, r = _post(server, "/api/stop", {})
        assert code == 200
        assert r["ok"] is False


class TestController:
    def test_start_twice_rejected(self, monkeypatch):
        from bilibili_fav_classifier.pipeline import Pipeline

        monkeypatch.setattr(Pipeline, "run", lambda self: None)
        c = PipelineController()
        ok1, _ = c.start()
        ok2, msg = c.start()
        assert ok1 and not ok2
        assert "运行中" in msg

    def test_stop_without_start(self):
        c = PipelineController()
        ok, _ = c.stop()
        assert not ok


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
