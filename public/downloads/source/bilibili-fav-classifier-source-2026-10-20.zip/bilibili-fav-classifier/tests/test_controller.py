"""Tests for controller.py: results_summary data assembly."""
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from bilibili_fav_classifier.controller import results_summary


@pytest.fixture()
def data_dir(tmp_path, monkeypatch):
    import bilibili_fav_classifier.config as config_mod

    # plan.py resolves PLAN_JSON / FAVS_JSON through config at call time,
    # so patching config is enough for both.
    monkeypatch.setattr(config_mod, "PLAN_JSON", tmp_path / "plan.json")
    monkeypatch.setattr(config_mod, "FAVS_JSON", tmp_path / "favs.json")
    # ai cache path
    import bilibili_fav_classifier.ai as ai_mod
    monkeypatch.setattr(ai_mod.paths, "AI_RESULTS_JSON",
                        tmp_path / "ai_results.json")
    return tmp_path


class TestResultsSummary:
    def test_unavailable_without_plan(self, data_dir):
        out = results_summary()
        assert out["available"] is False
        assert out["total"] == 0

    def test_merges_plan_favs_and_ai(self, data_dir):
        (data_dir / "plan.json").write_text(json.dumps({
            "move": False,
            "groups": {
                "音乐": [{"id": 1, "bvid": "BV1"}],
                "体育": [{"id": 2, "bvid": "BV2"}],
            },
        }, ensure_ascii=False), encoding="utf-8")
        (data_dir / "favs.json").write_text(json.dumps({
            "videos": [
                {"bvid": "BV1", "title": "原始标题1"},
                {"bvid": "BV2", "title": "原始标题2"},
            ],
        }, ensure_ascii=False), encoding="utf-8")
        (data_dir / "ai_results.json").write_text(json.dumps({
            "BV1": {"folder": "音乐", "clean_title": "干净标题",
                    "summary": "一句话摘要"},
        }, ensure_ascii=False), encoding="utf-8")

        out = results_summary()
        assert out["available"] is True
        assert out["total"] == 2
        assert out["move"] is False
        assert out["ai_count"] == 1
        item1 = out["groups"]["音乐"][0]
        assert item1["title"] == "原始标题1"
        assert item1["clean_title"] == "干净标题"
        assert item1["summary"] == "一句话摘要"
        assert item1["ai"] is True
        item2 = out["groups"]["体育"][0]
        assert item2["ai"] is False
        assert item2["clean_title"] == ""

    def test_corrupted_plan_returns_unavailable(self, data_dir):
        (data_dir / "plan.json").write_text("{bad json", encoding="utf-8")
        assert results_summary()["available"] is False

    def test_missing_favs_still_works(self, data_dir):
        (data_dir / "plan.json").write_text(json.dumps({
            "move": True, "groups": {"音乐": [{"id": 1, "bvid": "BV1"}]},
        }, ensure_ascii=False), encoding="utf-8")
        out = results_summary()
        assert out["available"] is True
        assert out["groups"]["音乐"][0]["title"] == ""


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
