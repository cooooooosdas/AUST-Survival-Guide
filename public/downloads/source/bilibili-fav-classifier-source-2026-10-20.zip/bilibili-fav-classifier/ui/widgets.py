"""Reusable UI widgets: Mascot, Card, Toast, LogBox, StepIndicator."""
from __future__ import annotations

import random
import tkinter as tk

import customtkinter as ctk

from ui import theme as T


# ── Mascot (cat TV) ───────────────────────────────────────────────

def _round_rect(canvas: tk.Canvas, x1, y1, x2, y2, r, **kw):
    """Draw a rounded rectangle on a Canvas via smooth polygon."""
    points = [
        x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
        x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2,
        x1, y2, x1, y2 - r, x1, y1 + r, x1, y1,
    ]
    return canvas.create_polygon(points, smooth=True, **kw)


class Mascot(tk.Canvas):
    """Cute cat-TV mascot drawn with vector primitives (no image assets).

    Eyes blink at random intervals (4–7s) — the single "alive" detail
    that keeps the tool friendly without being noisy.
    """

    def __init__(self, master, size: int = 36, bg: str = T.SURFACE):
        super().__init__(
            master, width=size, height=size, bg=bg,
            highlightthickness=0, bd=0,
        )
        self._size = size
        self._blink_job = None
        self._draw()
        self._schedule_blink()

    def _u(self, v: float) -> float:
        """Scale a 40-unit design grid to the actual size."""
        return v * self._size / 40.0

    def _draw(self):
        s = self._size
        if s >= 24:
            # ears
            self.create_polygon(
                self._u(11), self._u(9), self._u(7), self._u(2), self._u(16), self._u(6),
                fill=T.PRIMARY, outline="",
            )
            self.create_polygon(
                self._u(29), self._u(9), self._u(33), self._u(2), self._u(24), self._u(6),
                fill=T.PRIMARY, outline="",
            )
        # body
        _round_rect(self, self._u(3), self._u(8), self._u(37), self._u(34),
                    self._u(9), fill=T.PRIMARY, outline="")
        # screen
        _round_rect(self, self._u(8), self._u(13), self._u(32), self._u(29),
                    self._u(6), fill=T.BG, outline="")
        # eyes (ovals + hidden blink lines)
        eye_r = max(1.2, self._u(1.7))
        cy = self._u(20)
        self._eye_l = self.create_oval(
            self._u(15.5) - eye_r, cy - eye_r, self._u(15.5) + eye_r, cy + eye_r,
            fill=T.TEXT, outline="",
        )
        self._eye_r = self.create_oval(
            self._u(24.5) - eye_r, cy - eye_r, self._u(24.5) + eye_r, cy + eye_r,
            fill=T.TEXT, outline="",
        )
        self._blink_l = self.create_line(
            self._u(14), cy, self._u(17), cy, fill=T.TEXT,
            width=max(1, int(self._u(1.3))), state="hidden", capstyle="round",
        )
        self._blink_r = self.create_line(
            self._u(23), cy, self._u(26), cy, fill=T.TEXT,
            width=max(1, int(self._u(1.3))), state="hidden", capstyle="round",
        )
        # smile
        self.create_line(
            self._u(18), self._u(24.4), self._u(20), self._u(25.6),
            self._u(22), self._u(24.4),
            fill=T.TEXT, width=max(1, int(self._u(1.2))), smooth=True,
            capstyle="round",
        )
        # blush
        b = max(1.4, self._u(2.1))
        self.create_oval(self._u(12) - b, self._u(24) - b,
                         self._u(12) + b, self._u(24) + b,
                         fill=T.BLUSH, outline="")
        self.create_oval(self._u(28) - b, self._u(24) - b,
                         self._u(28) + b, self._u(24) + b,
                         fill=T.BLUSH, outline="")

    def _schedule_blink(self):
        delay = random.randint(4000, 7000)
        self._blink_job = self.after(delay, self._blink)

    def _blink(self):
        try:
            self.itemconfigure(self._eye_l, state="hidden")
            self.itemconfigure(self._eye_r, state="hidden")
            self.itemconfigure(self._blink_l, state="normal")
            self.itemconfigure(self._blink_r, state="normal")
            self.after(130, self._unblink)
        except tk.TclError:
            return

    def _unblink(self):
        try:
            self.itemconfigure(self._blink_l, state="hidden")
            self.itemconfigure(self._blink_r, state="hidden")
            self.itemconfigure(self._eye_l, state="normal")
            self.itemconfigure(self._eye_r, state="normal")
            self._schedule_blink()
        except tk.TclError:
            return

    def destroy(self):
        if self._blink_job is not None:
            try:
                self.after_cancel(self._blink_job)
            except tk.TclError:
                pass
        super().destroy()


# ── Card ──────────────────────────────────────────────────────────

class PageHeader(ctk.CTkFrame):
    """Page title + one-line description, shared by all pages."""

    def __init__(self, master, title: str, subtitle: str = "", right=None):
        # height=1 disables CTkFrame's default 200x200 request, so the
        # header collapses to its content instead of leaving a 200px gap.
        super().__init__(master, fg_color="transparent", height=1)
        col = ctk.CTkFrame(self, fg_color="transparent", height=1, width=1)
        col.pack(side="left", fill="x", expand=True)
        ctk.CTkLabel(
            col, text=title, font=T.font(19, "bold"), text_color=T.TEXT, anchor="w",
        ).pack(anchor="w")
        if subtitle:
            ctk.CTkLabel(
                col, text=subtitle, font=T.font(10), text_color=T.TEXT_DIM, anchor="w",
            ).pack(anchor="w", pady=(3, 0))
        self.right_slot = None
        if right is not None:
            self.right_slot = ctk.CTkFrame(
                self, fg_color="transparent", height=1, width=1,
            )
            self.right_slot.pack(side="right", padx=(12, 0))
            right(self.right_slot)


class EmptyState(ctk.CTkFrame):
    """Centered mascot + hint for empty lists."""

    def __init__(self, master, text: str, bg: str = T.BG, size: int = 64):
        super().__init__(master, fg_color="transparent")
        Mascot(self, size=size, bg=bg).pack(pady=(0, 12))
        ctk.CTkLabel(
            self, text=text, font=T.font(12), text_color=T.TEXT_DIM,
            justify="center",
        ).pack()


class Card(ctk.CTkFrame):
    def __init__(self, master, title: str | None = None, **kwargs):
        kwargs.setdefault("fg_color", T.SURFACE)
        kwargs.setdefault("corner_radius", T.RADIUS_CARD)
        kwargs.setdefault("border_width", 1)
        kwargs.setdefault("border_color", T.BORDER)
        super().__init__(master, **kwargs)
        if title is not None:
            ctk.CTkLabel(
                self, text=title,
                font=T.font(11, "bold"), text_color=T.TEXT_DIM, anchor="w",
            ).pack(fill="x", padx=20, pady=(15, 4))


def bind_recursive(widget, sequence: str = "<Button-1>", handler=None, cursor: str | None = None):
    """Bind an event to a widget and every descendant.

    customtkinter wraps real Tk widgets, so a frame's children never
    inherit the parent's bindings — clicking the label inside a header
    would otherwise not toggle the card.
    """
    if handler is None:
        return
    try:
        widget.bind(sequence, handler)
    except Exception:
        pass
    if cursor:
        try:
            widget.configure(cursor=cursor)
        except Exception:
            pass
    for child in widget.winfo_children():
        bind_recursive(child, sequence, handler, cursor)


class Segmented(ctk.CTkSegmentedButton):
    """CTkSegmentedButton with a contrasting text color on the selection.

    The stock widget paints every segment with one `text_color`, which
    makes the selected segment unreadable on a mint background — so we
    repaint the selected button's label in ON_PRIMARY.
    """

    def __init__(self, master, selected_text_color: str = T.ON_PRIMARY, **kwargs):
        self._selected_text_color = selected_text_color
        kwargs.setdefault("selected_color", T.PRIMARY)
        kwargs.setdefault("selected_hover_color", T.PRIMARY_HOVER)
        kwargs.setdefault("text_color", T.TEXT)
        super().__init__(master, **kwargs)

    def set(self, value, from_button_callback: bool = False):
        super().set(value, from_button_callback)
        self._sync_text_colors()

    def _sync_text_colors(self):
        current = self.get()
        base = self.cget("text_color")
        for value, button in getattr(self, "_buttons_dict", {}).items():
            try:
                button.configure(
                    text_color=self._selected_text_color if value == current else base
                )
            except Exception:
                pass


# ── Toast ─────────────────────────────────────────────────────────

class Toast:
    """Transient overlay message on the main window."""

    def __init__(self, window: ctk.CTk):
        self.window = window
        self._toast = None

    def show(self, msg: str, kind: str = "success"):
        """kind: 'success' | 'error' | 'warning'"""
        color = {
            "success": T.SUCCESS, "error": T.DANGER, "warning": T.WARNING,
        }.get(kind, T.SUCCESS)
        if self._toast is not None:
            try:
                self._toast.destroy()
            except Exception:
                pass
        toast = ctk.CTkToplevel(self.window)
        toast.overrideredirect(True)
        toast.attributes("-topmost", True)
        toast.configure(fg_color=color)
        toast.attributes("-alpha", 0.0)
        self._toast = toast
        ctk.CTkLabel(
            toast, text=msg, font=T.font(13, "bold"),
            text_color=T.ON_PRIMARY, padx=30, pady=14,
        ).pack()
        self.window.update_idletasks()
        x = self.window.winfo_x() + (self.window.winfo_width() - toast.winfo_width()) // 2
        y = self.window.winfo_y() + 84
        toast.geometry(f"+{x}+{y}")
        self._fade(toast, 0.0, True)

    def _fade(self, toast, alpha, fade_in):
        try:
            if fade_in:
                if alpha < 1.0:
                    toast.attributes("-alpha", min(alpha + 0.1, 1.0))
                    self.window.after(16, lambda: self._fade(toast, alpha + 0.1, True))
                else:
                    self.window.after(1700, lambda: self._fade(toast, 1.0, False))
            else:
                if alpha > 0:
                    toast.attributes("-alpha", max(alpha - 0.08, 0.0))
                    self.window.after(16, lambda: self._fade(toast, alpha - 0.08, False))
                else:
                    toast.destroy()
                    if self._toast is toast:
                        self._toast = None
        except Exception:
            pass


# ── Log ───────────────────────────────────────────────────────────

class LogBox:
    """Read-only colored log viewer."""

    def __init__(self, master):
        self.box = ctk.CTkTextbox(
            master,
            font=T.font(12, family=T.FONT_MONO),
            text_color=T.TEXT, fg_color=T.LOG_BG,
            border_width=1, border_color=T.BORDER,
            corner_radius=10, wrap="word",
        )
        for name, color in (
            ("success", T.SUCCESS), ("error", T.DANGER), ("warning", T.WARNING),
            ("step", T.PRIMARY), ("dim", T.TEXT_DIM), ("info", T.TEXT_MID),
        ):
            self.box.tag_config(name, foreground=color)
        self.box.configure(state="disabled")

    def pack(self, **kwargs):
        self.box.pack(**kwargs)

    def append(self, msg: str, tag: str = ""):
        self.box.configure(state="normal")
        if tag:
            self.box.insert("end", msg + "\n", tag)
        else:
            self.box.insert("end", msg + "\n")
        self.box.see("end")
        self.box.configure(state="disabled")

    def append_smart(self, msg: str):
        tag = ""
        if msg.startswith("✓"):
            tag = "success"
        elif msg.startswith("❌"):
            tag = "error"
        elif msg.startswith("⚠"):
            tag = "warning"
        elif msg.startswith("━"):
            tag = "dim"
        elif msg.startswith(("步骤", "🚀", "👁")):
            tag = "step"
        elif msg.startswith("    "):
            tag = "info"
        self.append(msg, tag)

    def clear(self):
        self.box.configure(state="normal")
        self.box.delete("1.0", "end")
        self.box.configure(state="disabled")


# ── Step indicator ────────────────────────────────────────────────

class StepIndicator(ctk.CTkFrame):
    """Horizontal 4-step progress indicator."""

    def __init__(self, master, steps: list[str]):
        super().__init__(master, fg_color="transparent")
        self._n = len(steps)
        self.circles: list[ctk.CTkLabel] = []
        self.lines: list[ctk.CTkFrame] = []
        for i, name in enumerate(steps):
            circle = ctk.CTkLabel(
                self, text="○", width=34, height=34, corner_radius=17,
                fg_color=T.SURFACE_2, text_color=T.TEXT_DIM,
                font=T.font(15, "bold"),
            )
            circle.pack(side="left")
            self.circles.append(circle)
            ctk.CTkLabel(
                self, text=name, font=T.font(11, "bold"), text_color=T.TEXT_DIM,
            ).pack(side="left", padx=(7, 0))
            if i < self._n - 1:
                line = ctk.CTkFrame(self, fg_color=T.SURFACE_2, height=2, width=44)
                line.pack(side="left", fill="x", expand=True, padx=10)
                self.lines.append(line)

    def set_step(self, step_idx: int):
        for i, circle in enumerate(self.circles):
            if i < step_idx:
                circle.configure(text="✓", fg_color=T.SUCCESS, text_color=T.ON_PRIMARY)
            elif i == step_idx:
                circle.configure(text="●", fg_color=T.PRIMARY, text_color=T.ON_PRIMARY)
            else:
                circle.configure(text="○", fg_color=T.SURFACE_2, text_color=T.TEXT_DIM)
        for i, line in enumerate(self.lines):
            line.configure(fg_color=T.SUCCESS if i < step_idx else T.SURFACE_2)
