"""Rules page: edit UP主 → folder seed mappings.

One compact card with a row per folder (label + inline input) instead of
13 stacked cards — keeps 13 categories readable without endless scroll.
"""
from __future__ import annotations

import customtkinter as ctk

from bilibili_fav_classifier.config import load_seed_mappings, save_seed_mappings
from bilibili_fav_classifier.rules import ALL_FOLDERS
from ui import theme as T
from ui.widgets import Card, PageHeader


class RulesPage(ctk.CTkFrame):
    def __init__(self, master, app):
        super().__init__(master, fg_color="transparent")
        self.app = app
        self.entries: dict[str, ctk.CTkEntry] = {}

        def _save_btn(slot):
            ctk.CTkButton(
                slot, text="保存映射", command=self._save,
                font=T.font(11, "bold"), fg_color=T.PRIMARY,
                hover_color=T.PRIMARY_HOVER, text_color=T.ON_PRIMARY,
                width=94, height=34, corner_radius=T.RADIUS_INPUT,
            ).pack()

        PageHeader(
            self, "UP主规则",
            "优先级最高：这里配置的 UP 主，其视频永远归入对应收藏夹",
            right=_save_btn,
        ).pack(fill="x", pady=(2, 14))

        scroll = ctk.CTkScrollableFrame(
            self, fg_color="transparent",
            scrollbar_button_color=T.SURFACE_2,
            scrollbar_button_hover_color=T.BORDER,
        )
        scroll.pack(fill="both", expand=True)

        card = Card(scroll)
        card.pack(fill="x", pady=(0, 10))

        ctk.CTkLabel(
            card,
            text="每行填写 UP 主名称，多个用逗号分隔（也支持中文逗号）",
            font=T.font(9), text_color=T.TEXT_DIM, anchor="w",
        ).pack(fill="x", padx=18, pady=(14, 10))

        mappings = load_seed_mappings()
        for idx, folder in enumerate(ALL_FOLDERS):
            if idx:
                ctk.CTkFrame(card, fg_color=T.BORDER, height=1).pack(
                    fill="x", padx=18
                )
            row = ctk.CTkFrame(card, fg_color="transparent")
            row.pack(fill="x", padx=18, pady=7)

            ctk.CTkLabel(
                row, text=folder, font=T.font(11, "bold"),
                text_color=T.TEXT_MID, width=104, anchor="w",
            ).pack(side="left")

            entry = ctk.CTkEntry(
                row, font=T.font(11), fg_color=T.LOG_BG,
                border_color=T.BORDER, text_color=T.TEXT, height=34,
                corner_radius=T.RADIUS_INPUT,
                placeholder_text="未配置",
            )
            entry.pack(side="left", fill="x", expand=True, padx=(10, 0))
            ups = mappings.get(folder, [])
            if ups:
                entry.insert(0, ", ".join(ups))
            self.entries[folder] = entry

        ctk.CTkLabel(card, text="", height=8).pack()

        tip = Card(scroll, title="小提示")
        tip.pack(fill="x", pady=(0, 10))
        ctk.CTkLabel(
            tip,
            text="不知道配什么？先跑一次分类，结果页里「其他」分类的 UP 主就是最值得加进映射的。\n"
                 "也可以直接用「混合」或「AI 全量」模式，让 DeepSeek 帮你判断。",
            font=T.font(10), text_color=T.TEXT_DIM, anchor="w",
            justify="left", wraplength=580,
        ).pack(fill="x", padx=18, pady=(0, 14))

    def _save(self):
        mappings: dict[str, list[str]] = {}
        for folder, entry in self.entries.items():
            raw = entry.get().strip()
            if raw:
                ups = [u.strip() for u in raw.replace("，", ",").split(",")]
                mappings[folder] = [u for u in ups if u]
            else:
                mappings[folder] = []
        save_seed_mappings(mappings)
        total = sum(len(v) for v in mappings.values())
        self.app.toast.show(f"✓ 已保存 {total} 个 UP 主映射")
