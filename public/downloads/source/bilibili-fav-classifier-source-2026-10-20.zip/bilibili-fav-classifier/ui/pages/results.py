"""Results page: browse the latest classification result.

Folders are collapsible blocks; AI-organized videos show their cleaned
title and one-line summary with an AI badge.
"""
from __future__ import annotations

import customtkinter as ctk

from bilibili_fav_classifier.controller import results_summary
from ui import theme as T
from ui.widgets import Card, EmptyState, PageHeader, bind_recursive

PREVIEW_LIMIT = 8  # items rendered per folder until expanded


class ResultsPage(ctk.CTkFrame):
    def __init__(self, master, app):
        super().__init__(master, fg_color="transparent")
        self.app = app
        self._expanded: dict[str, bool] = {}

        def _refresh_btn(slot):
            ctk.CTkButton(
                slot, text="刷新", command=self.refresh,
                font=T.font(11, "bold"), fg_color="transparent",
                hover_color=T.SURFACE_2, text_color=T.TEXT_MID,
                width=66, height=32, corner_radius=T.RADIUS_INPUT,
                border_width=1, border_color=T.BORDER,
            ).pack()

        PageHeader(
            self, "分类结果",
            "点击收藏夹展开 · AI 整理过的视频会显示清理标题与摘要",
            right=_refresh_btn,
        ).pack(fill="x", pady=(2, 14))

        self.info_label = ctk.CTkLabel(
            self, text="", font=T.font(10), text_color=T.TEXT_DIM, anchor="w",
        )
        self.info_label.pack(fill="x", pady=(0, 10))

        self.scroll = ctk.CTkScrollableFrame(
            self, fg_color="transparent",
            scrollbar_button_color=T.SURFACE_2,
            scrollbar_button_hover_color=T.BORDER,
        )
        self.scroll.pack(fill="both", expand=True)

    def refresh(self):
        for w in self.scroll.winfo_children():
            w.destroy()
        data = results_summary()

        if not data["available"]:
            self.info_label.configure(text="")
            empty = EmptyState(
                self.scroll,
                "还没有分类结果\n先在「运行」页执行一次分类",
                bg=T.BG, size=72,
            )
            empty.pack(pady=70)
            return

        ai_note = f" · AI 整理 {data['ai_count']}" if data["ai_count"] else ""
        move_note = " · 预览（未移动任何视频）" if not data["move"] else ""
        self.info_label.configure(
            text=f"共 {data['total']} 个视频 · {len(data['groups'])} 个收藏夹{ai_note}{move_note}"
        )

        for folder, items in sorted(data["groups"].items(), key=lambda x: -len(x[1])):
            self._folder_block(folder, items)

    def _folder_block(self, folder: str, items: list[dict]):
        card = Card(self.scroll)
        card.pack(fill="x", pady=(0, 10))

        head = ctk.CTkFrame(card, fg_color="transparent")
        head.pack(fill="x", padx=18, pady=(13, 11))

        ctk.CTkLabel(
            head, text=folder, font=T.font(13, "bold"), text_color=T.TEXT,
        ).pack(side="left")
        ctk.CTkLabel(
            head, text=str(len(items)), font=T.font(10, "bold"),
            text_color=T.TEXT, fg_color=T.SURFACE_2,
            corner_radius=9, width=34, height=20,
        ).pack(side="right")
        chevron = ctk.CTkLabel(
            head, text="▾", font=T.font(11), text_color=T.TEXT_DIM,
        )
        chevron.pack(side="right", padx=(0, 8))

        body = ctk.CTkFrame(card, fg_color="transparent")

        shown = items[:PREVIEW_LIMIT]
        for idx, it in enumerate(shown):
            self._item_row(body, it, is_last=(idx == len(shown) - 1 and len(items) <= PREVIEW_LIMIT))
        if len(items) > PREVIEW_LIMIT:
            ctk.CTkLabel(
                body, text=f"… 还有 {len(items) - PREVIEW_LIMIT} 个视频（移动视频后在 B站查看完整列表）",
                font=T.font(9), text_color=T.TEXT_DIM, anchor="w",
            ).pack(fill="x", padx=18, pady=(2, 12))
        else:
            ctk.CTkLabel(body, text="", height=6).pack()

        is_open = self._expanded.get(folder, False)
        if is_open:
            body.pack(fill="x")

        def _toggle(_e=None):
            if body.winfo_manager():
                body.pack_forget()
                chevron.configure(text="▸")
                self._expanded[folder] = False
            else:
                body.pack(fill="x")
                chevron.configure(text="▾")
                self._expanded[folder] = True

        bind_recursive(head, "<Button-1>", _toggle, cursor="hand2")
        card.toggle = _toggle  # programmatic access (tests / deep links)

    def _item_row(self, parent, it: dict, is_last: bool = False):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=18, pady=(0, 8))

        if not is_last:
            sep = ctk.CTkFrame(parent, fg_color=T.BORDER, height=1)
            sep.pack(fill="x", padx=18, pady=(0, 8))

        if it.get("ai") and it.get("clean_title"):
            top = ctk.CTkFrame(row, fg_color="transparent")
            top.pack(fill="x")
            ctk.CTkLabel(
                top, text="AI", font=T.font(9, "bold"),
                text_color=T.ON_PRIMARY, fg_color=T.PRIMARY,
                corner_radius=5, width=28, height=18,
            ).pack(side="left", padx=(0, 7))
            ctk.CTkLabel(
                top, text=it["clean_title"], font=T.font(12, "bold"),
                text_color=T.PRIMARY, anchor="w", wraplength=520, justify="left",
            ).pack(side="left", fill="x", expand=True)

        ctk.CTkLabel(
            row, text=it.get("title") or it.get("bvid", ""),
            font=T.font(11), text_color=T.TEXT_MID, anchor="w",
            wraplength=560, justify="left",
        ).pack(fill="x")
        if it.get("summary"):
            ctk.CTkLabel(
                row, text=it["summary"], font=T.font(10),
                text_color=T.TEXT_DIM, anchor="w",
                wraplength=560, justify="left",
            ).pack(fill="x", pady=(2, 0))
