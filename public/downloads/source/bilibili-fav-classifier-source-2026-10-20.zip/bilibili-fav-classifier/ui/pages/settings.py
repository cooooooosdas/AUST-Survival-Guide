"""Settings page: classify mode, DeepSeek API key, LAN server."""
from __future__ import annotations

import threading

import customtkinter as ctk

from bilibili_fav_classifier.ai import DeepSeekClient
from bilibili_fav_classifier.config import CLASSIFY_MODES, load_config, save_config
from ui import theme as T
from ui.widgets import Card, PageHeader, Segmented

MODE_LABELS = {"local": "本地规则", "hybrid": "混合模式", "ai": "AI 全量"}
MODE_HINTS = {
    "local": "零成本、离线可用。使用内置规则引擎分类。",
    "hybrid": "本地规则先分类，仅无法判断的「其他」交给 DeepSeek（省 token）。",
    "ai": "所有视频交给 DeepSeek 分类、清理标题并生成摘要；失败自动回退本地规则。",
}


class SettingsPage(ctk.CTkFrame):
    def __init__(self, master, app):
        super().__init__(master, fg_color="transparent")
        self.app = app

        PageHeader(
            self, "设置",
            "分类模式、AI 整理与手机端访问 — 所有配置只保存在本机",
        ).pack(fill="x", pady=(2, 14))

        scroll = ctk.CTkScrollableFrame(
            self, fg_color="transparent",
            scrollbar_button_color=T.SURFACE_2,
            scrollbar_button_hover_color=T.BORDER,
        )
        scroll.pack(fill="both", expand=True)
        cfg = load_config()

        # ── 分类模式 ──
        mode_card = Card(scroll, title="分类引擎")
        mode_card.pack(fill="x", pady=(0, 12))
        seg = Segmented(
            mode_card, values=[MODE_LABELS[m] for m in CLASSIFY_MODES],
            font=T.font(12, "bold"), fg_color=T.LOG_BG,
            unselected_color=T.LOG_BG, unselected_hover_color=T.SURFACE_2,
            corner_radius=T.RADIUS_INPUT, height=36,
            command=self._on_mode_change,
        )
        seg.set(MODE_LABELS.get(cfg.get("CLASSIFY_MODE", "local"), "本地规则"))
        seg.pack(fill="x", padx=18, pady=(4, 8))
        self.mode_hint = ctk.CTkLabel(
            mode_card, text=MODE_HINTS.get(cfg.get("CLASSIFY_MODE", "local"), ""),
            font=T.font(10), text_color=T.TEXT_DIM, anchor="w",
            wraplength=560, justify="left",
        )
        self.mode_hint.pack(fill="x", padx=18, pady=(0, 14))

        # ── DeepSeek ──
        ai_card = Card(scroll, title="DeepSeek AI")
        ai_card.pack(fill="x", pady=(0, 12))

        ctk.CTkLabel(
            ai_card, text="API Key", font=T.font(10, "bold"),
            text_color=T.TEXT_MID, anchor="w",
        ).pack(fill="x", padx=18, pady=(2, 5))
        key_row = ctk.CTkFrame(ai_card, fg_color="transparent")
        key_row.pack(fill="x", padx=18)
        self.key_entry = ctk.CTkEntry(
            key_row, font=T.font(12, family=T.FONT_MONO), fg_color=T.LOG_BG,
            border_color=T.BORDER, text_color=T.TEXT, height=38,
            corner_radius=T.RADIUS_INPUT, placeholder_text="sk-...",
        )
        self.key_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        ctk.CTkButton(
            key_row, text="👁", width=38, height=38, corner_radius=T.RADIUS_INPUT,
            fg_color="transparent", hover_color=T.SURFACE_2,
            text_color=T.TEXT_DIM, command=self._toggle_key_visible,
        ).pack(side="left")

        self.key_status = ctk.CTkLabel(
            ai_card, text="", font=T.font(10), text_color=T.TEXT_DIM, anchor="w",
            justify="left", wraplength=560,
        )
        self.key_status.pack(fill="x", padx=18, pady=(7, 0))
        if cfg.get("DEEPSEEK_API_KEY"):
            self.key_status.configure(
                text=f"✓ 已保存 · {_mask(cfg['DEEPSEEK_API_KEY'])}",
                text_color=T.SUCCESS,
            )

        btn_row = ctk.CTkFrame(ai_card, fg_color="transparent")
        btn_row.pack(fill="x", padx=18, pady=(11, 6))
        self.verify_btn = ctk.CTkButton(
            btn_row, text="验证 Key", command=self._verify_key,
            font=T.font(11, "bold"), fg_color="transparent", hover_color=T.SURFACE_2,
            text_color=T.TEXT_MID, height=36, corner_radius=T.RADIUS_INPUT,
            border_width=1, border_color=T.BORDER,
        )
        self.verify_btn.pack(side="left", fill="x", expand=True, padx=(0, 8))
        ctk.CTkButton(
            btn_row, text="保存 Key", command=self._save_key,
            font=T.font(11, "bold"), fg_color=T.PRIMARY, hover_color=T.PRIMARY_HOVER,
            text_color=T.ON_PRIMARY, height=36, corner_radius=T.RADIUS_INPUT,
        ).pack(side="left", fill="x", expand=True)

        ctk.CTkLabel(
            ai_card,
            text="在 platform.deepseek.com 申请。Key 仅写入本机 config.json，接口永不回传完整 Key。",
            font=T.font(9), text_color=T.TEXT_DIM, anchor="w",
            wraplength=560, justify="left",
        ).pack(fill="x", padx=18, pady=(0, 14))

        # ── 局域网服务器（手机端）──
        srv_card = Card(scroll, title="手机端 · 局域网")
        srv_card.pack(fill="x", pady=(0, 12))

        row1 = ctk.CTkFrame(srv_card, fg_color="transparent")
        row1.pack(fill="x", padx=18, pady=(3, 8))
        self.server_switch = ctk.CTkSwitch(
            row1, text="启用手机端访问", font=T.font(12), text_color=T.TEXT,
            progress_color=T.PRIMARY, button_color=T.TEXT,
            button_hover_color=T.TEXT, command=self._on_server_toggle,
        )
        self.server_switch.pack(side="left")
        if cfg.get("SERVER_ENABLED", True):
            self.server_switch.select()

        port_row = ctk.CTkFrame(srv_card, fg_color="transparent")
        port_row.pack(fill="x", padx=18, pady=(0, 8))
        ctk.CTkLabel(
            port_row, text="端口", font=T.font(10), text_color=T.TEXT_DIM,
        ).pack(side="left", padx=(0, 8))
        self.port_entry = ctk.CTkEntry(
            port_row, width=86, height=32, font=T.font(11, family=T.FONT_MONO),
            fg_color=T.LOG_BG, border_color=T.BORDER, text_color=T.TEXT,
            corner_radius=T.RADIUS_INPUT,
        )
        self.port_entry.insert(0, str(cfg.get("SERVER_PORT", 8765)))
        self.port_entry.pack(side="left")
        ctk.CTkButton(
            port_row, text="应用并重启", command=self._restart_server,
            font=T.font(10, "bold"), fg_color="transparent",
            hover_color=T.SURFACE_2, text_color=T.TEXT_MID,
            height=32, corner_radius=T.RADIUS_INPUT,
            border_width=1, border_color=T.BORDER,
        ).pack(side="left", padx=(10, 0))

        self.server_status = ctk.CTkLabel(
            srv_card, text="", font=T.font(11), text_color=T.TEXT_DIM,
            anchor="w", justify="left", wraplength=560,
        )
        self.server_status.pack(fill="x", padx=18, pady=(0, 14))
        self._update_server_status()

        # ── 数据 ──
        data_card = Card(scroll, title="数据")
        data_card.pack(fill="x", pady=(0, 12))
        ctk.CTkButton(
            data_card, text="📂  打开数据文件夹", command=self._open_data_dir,
            font=T.font(11, "bold"), fg_color="transparent",
            hover_color=T.SURFACE_2, text_color=T.TEXT_MID,
            height=36, corner_radius=T.RADIUS_INPUT,
            border_width=1, border_color=T.BORDER,
        ).pack(fill="x", padx=18, pady=(4, 14))

    # ── mode ──

    def _on_mode_change(self, label: str):
        mode = {v: k for k, v in MODE_LABELS.items()}[label]
        save_config({"CLASSIFY_MODE": mode})
        self.mode_hint.configure(text=MODE_HINTS[mode])
        self.app.toast.show(f"已切换为「{label}」")

    # ── api key ──

    def _toggle_key_visible(self):
        self.key_entry.configure(
            show="" if self.key_entry.cget("show") == "*" else "*"
        )

    def _save_key(self):
        key = self.key_entry.get().strip()
        if not key:
            self.app.toast.show("请输入 API Key", "warning")
            return
        save_config({"DEEPSEEK_API_KEY": key})
        self.key_entry.delete(0, "end")
        self.key_status.configure(
            text=f"✓ 已保存 · {_mask(key)}", text_color=T.SUCCESS,
        )
        self.app.toast.show("API Key 已保存")

    def _verify_key(self):
        key = self.key_entry.get().strip() or load_config().get("DEEPSEEK_API_KEY", "")
        if not key:
            self.app.toast.show("请先输入或保存 API Key", "warning")
            return
        self.verify_btn.configure(state="disabled", text="验证中…")
        self.key_status.configure(text="正在连接 DeepSeek…", text_color=T.TEXT_MID)

        def _work():
            ok, msg = DeepSeekClient(key).verify_key()
            self.after(0, lambda: self._verify_done(ok, msg))

        threading.Thread(target=_work, daemon=True).start()

    def _verify_done(self, ok: bool, msg: str):
        self.verify_btn.configure(state="normal", text="验证 Key")
        self.key_status.configure(
            text=("✓ " if ok else "✗ ") + msg,
            text_color=T.SUCCESS if ok else T.DANGER,
        )
        self.app.toast.show(msg, "success" if ok else "error")

    # ── server ──

    def _on_server_toggle(self):
        enabled = bool(self.server_switch.get())
        save_config({"SERVER_ENABLED": enabled})
        self.app.apply_server_config()
        self._update_server_status()

    def _restart_server(self):
        try:
            port = int(self.port_entry.get().strip())
            if not (1024 <= port <= 65535):
                raise ValueError
        except ValueError:
            self.app.toast.show("端口号无效（1024-65535）", "error")
            return
        save_config({"SERVER_PORT": port,
                     "SERVER_ENABLED": bool(self.server_switch.get())})
        self.app.apply_server_config()
        self._update_server_status()

    def _update_server_status(self):
        url = self.app.server_url()
        if url:
            self.server_status.configure(
                text=f"✓ 手机浏览器打开  {url}\n   手机需与电脑连接同一 Wi-Fi",
                text_color=T.SUCCESS,
            )
        else:
            self.server_status.configure(
                text="手机端服务未启用", text_color=T.TEXT_DIM,
            )

    # ── data ──

    def _open_data_dir(self):
        self.app.open_data_dir()


def _mask(key: str) -> str:
    return f"{key[:6]}...{key[-4:]}" if len(key) > 10 else "已保存"
