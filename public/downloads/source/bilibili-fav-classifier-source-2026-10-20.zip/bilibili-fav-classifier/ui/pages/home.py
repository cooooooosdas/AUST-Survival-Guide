"""Home page: pipeline run control (steps, status, progress, logs)."""
from __future__ import annotations

import math

import customtkinter as ctk

from bilibili_fav_classifier.config import load_config
from ui import theme as T
from ui.widgets import Card, LogBox, PageHeader, StepIndicator

STEPS = ["拉取", "补充", "分类", "应用"]


class HomePage(ctk.CTkFrame):
    def __init__(self, master, app):
        super().__init__(master, fg_color="transparent")
        self.app = app
        self._pulse = 0.0
        self._target = 0.0
        self._current = 0.0

        PageHeader(
            self, "运行",
            "扫码登录后自动完成拉取、补标签、分类与整理 — 全程可停止",
        ).pack(fill="x", pady=(2, 16))

        # ── Step indicator ──
        step_card = Card(self)
        step_card.pack(fill="x", pady=(0, 12))
        self.steps = StepIndicator(step_card, STEPS)
        self.steps.pack(padx=18, pady=(16, 16))

        # ── Status ──
        status_card = Card(self)
        status_card.pack(fill="x", pady=(0, 12))
        self.status_label = ctk.CTkLabel(
            status_card, text="●  就绪", font=T.font(13, "bold"),
            text_color=T.TEXT_MID, anchor="w",
        )
        self.status_label.pack(fill="x", padx=20, pady=(16, 8))
        self.progress_bar = ctk.CTkProgressBar(
            status_card, progress_color=T.PRIMARY, fg_color=T.LOG_BG,
            height=8, corner_radius=4, border_width=1, border_color=T.BORDER,
        )
        self.progress_bar.set(0)
        self.progress_bar.pack(fill="x", padx=20, pady=(0, 5))
        self.progress_detail = ctk.CTkLabel(
            status_card, text="", font=T.font(10),
            text_color=T.TEXT_DIM, anchor="w",
        )
        self.progress_detail.pack(fill="x", padx=20, pady=(0, 14))

        # ── Log ──
        log_card = Card(self, title="运行日志")
        log_card.pack(fill="both", expand=True, pady=(0, 12))
        self.log = LogBox(log_card)
        self.log.pack(fill="both", expand=True, padx=12, pady=(2, 14))

        # ── Actions ──
        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill="x", pady=(0, 2))

        self.start_btn = ctk.CTkButton(
            btn_frame, text="▶  开始一键分类", command=self._on_start,
            font=T.font(14, "bold"), fg_color=T.PRIMARY, hover_color=T.PRIMARY_HOVER,
            text_color=T.ON_PRIMARY, height=48, corner_radius=T.RADIUS_BTN,
        )
        self.start_btn.pack(side="left", fill="x", expand=True, padx=(0, 8))

        self.preview_btn = ctk.CTkButton(
            btn_frame, text="👁  预览", command=self._on_preview,
            font=T.font(12, "bold"), fg_color="transparent",
            hover_color=T.SURFACE_2, text_color=T.TEXT_MID,
            height=48, width=104, corner_radius=T.RADIUS_BTN,
            border_width=1, border_color=T.BORDER,
        )
        self.preview_btn.pack(side="left", padx=(0, 8))

        self.stop_btn = ctk.CTkButton(
            btn_frame, text="■  停止", command=self._on_stop,
            font=T.font(12, "bold"), fg_color="transparent",
            hover_color="#3A2326", text_color=T.TEXT_DIM,
            height=48, width=92, corner_radius=T.RADIUS_BTN,
            border_width=1, border_color=T.BORDER, state="disabled",
        )
        self.stop_btn.pack(side="left")

        self._tick()

    # ── public API (called by App) ─────────────────────────────

    def on_log(self, msg: str):
        self.log.append_smart(msg)

    def on_progress(self, pct: int, msg: str, step: int, detail: str):
        self._target = pct / 100
        self.status_label.configure(text=f"●  {msg}", text_color=T.PRIMARY)
        self.steps.set_step(step)
        if detail:
            self.progress_detail.configure(text=detail)

    def on_done(self, status: str):
        self.start_btn.configure(state="normal")
        self.preview_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled", text_color=T.TEXT_DIM)
        if status == "success":
            self.status_label.configure(text="●  全部完成", text_color=T.SUCCESS)
            self.steps.set_step(4)
            self.app.toast.show("🎉  分类完成！")
            self.app.refresh_results()
        elif status == "stopped":
            self.status_label.configure(text="●  已停止", text_color=T.WARNING)
        else:
            self.status_label.configure(text="●  运行出错", text_color=T.DANGER)
            self.app.toast.show("运行出错，请查看日志", "error")

    def init_logs(self):
        """Write the startup banner once (idempotent — safe to call twice)."""
        if getattr(self, "_logs_initialized", False):
            return
        self._logs_initialized = True
        cfg = load_config()
        if cfg.get("USER_MID"):
            self.log.append(f"已配置用户 · MID {cfg['USER_MID']}", "info")
        else:
            self.log.append("首次使用 · 点击「开始」扫码登录", "info")
        mode = cfg.get("CLASSIFY_MODE", "local")
        mode_label = {"local": "本地规则", "hybrid": "混合", "ai": "AI 全量"}.get(mode, mode)
        self.log.append(f"分类模式 · {mode_label}", "dim")
        self.log.append("准备就绪", "success")

    # ── internals ──────────────────────────────────────────────

    def _on_start(self):
        if self.app.controller.running:
            return
        self.log.append("━" * 46, "dim")
        self.log.append("🚀 启动分类流程...", "step")
        ok, msg = self.app.controller.start(move=True)
        if ok:
            self._lock_buttons()
        else:
            self.app.toast.show(msg, "warning")

    def _on_preview(self):
        """Classify without moving anything (dry-run)."""
        if self.app.controller.running:
            return
        self.log.append("━" * 46, "dim")
        self.log.append("👁 预览模式 · 只分类不移动", "step")
        ok, msg = self.app.controller.start(move=False, do_apply=False)
        if ok:
            self._lock_buttons()
        else:
            self.app.toast.show(msg, "warning")

    def _lock_buttons(self):
        self.start_btn.configure(state="disabled")
        self.preview_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal", text_color=T.DANGER)

    def _on_stop(self):
        ok, msg = self.app.controller.stop()
        if ok:
            self.log.append(f"⏹ {msg}", "warning")

    def _tick(self):
        """Smooth progress interpolation + breathing status dot."""
        if abs(self._current - self._target) > 0.002:
            self._current += (self._target - self._current) * 0.12
            self.progress_bar.set(self._current)
        elif self._current != self._target:
            self._current = self._target
            self.progress_bar.set(self._current)

        if self.app.controller.running:
            self._pulse += 0.06
            t = 0.5 + 0.5 * math.sin(self._pulse)
            color = T.lerp_color(T.PRIMARY, T.SUCCESS, t * 0.5)
            if self.status_label.cget("text").startswith("●"):
                self.status_label.configure(text_color=color)
        self.after(16, self._tick)
