"""Design tokens shared by all desktop UI pages — Mint Studio (方案 A).

Keep in sync with bilibili_fav_classifier/web/index.html (:root vars)
so both ends share one visual language.

Tokens and contrast audit live in docs/design-spec.md.
"""
import customtkinter as ctk

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# ── Color ─────────────────────────────────────────────────────────
BG = "#0E1A1B"
SURFACE = "#16292B"
SURFACE_2 = "#203A3D"
BORDER = "#26484B"

PRIMARY = "#6FE3C0"
PRIMARY_HOVER = "#58D3B0"
ON_PRIMARY = "#062220"

SUCCESS = "#9BE89A"
WARNING = "#FFD08A"
DANGER = "#FF9B9B"
BLUSH = "#FF9ECB"

TEXT = "#E6F4F1"
TEXT_MID = "#A8C6C1"
TEXT_DIM = "#7FA39D"

LOG_BG = "#0A1415"

# Backward-compatible aliases (older pages referenced these names)
CARD_BG = SURFACE
CARD_BG_HOVER = SURFACE_2
ACCENT = PRIMARY
ACCENT_SOFT = SURFACE_2
DIVIDER = BORDER

# ── Radius / spacing ──────────────────────────────────────────────
RADIUS_CARD = 16
RADIUS_BTN = 12
RADIUS_INPUT = 10

SPACE_1 = 4
SPACE_2 = 8
SPACE_3 = 12
SPACE_4 = 16
SPACE_6 = 24

# ── Type ──────────────────────────────────────────────────────────
FONT_UI = "Microsoft YaHei UI"
FONT_MONO = "Cascadia Mono"


def font(size=13, weight="normal", family=FONT_UI) -> ctk.CTkFont:
    return ctk.CTkFont(family=family, size=size, weight=weight)


def hex_to_rgb(h: str) -> tuple[int, int, int]:
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def lerp_color(c1: str, c2: str, t: float) -> str:
    """Interpolate between two hex colors. t in [0, 1]."""
    r1, g1, b1 = hex_to_rgb(c1)
    r2, g2, b2 = hex_to_rgb(c2)
    return "#{:02x}{:02x}{:02x}".format(
        int(r1 + (r2 - r1) * t),
        int(g1 + (g2 - g1) * t),
        int(b1 + (b2 - b1) * t),
    )
