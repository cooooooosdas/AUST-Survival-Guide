"""Desktop application window: sidebar navigation + four pages.

Pages share one PipelineController (also used by the LAN server), so
the desktop GUI and the mobile web UI observe identical state.
"""
from __future__ import annotations

import ctypes
import os
import queue
import subprocess
import sys
from pathlib import Path

import customtkinter as ctk

from bilibili_fav_classifier import paths
from bilibili_fav_classifier.config import load_config
from bilibili_fav_classifier.controller import PipelineController
from bilibili_fav_classifier.server import LanServer
from ui import theme as T
from ui.pages.home import HomePage
from ui.pages.results import ResultsPage
from ui.pages.rules import RulesPage
from ui.pages.settings import SettingsPage
from ui.widgets import Mascot, Toast

NAV = [
    ("run", "▶", "运行"),
    ("results", "▤", "结果"),
    ("rules", "✦", "规则"),
    ("settings", "⚙", "设置"),
]


def _apply_dark_titlebar(window) -> None:
    """Windows 10/11: paint the native title bar dark to match the app."""
    if sys.platform != "win32":
        return
    try:
        window.update_idletasks()
        hwnd = ctypes.windll.user32.GetParent(window.winfo_id())
        value = ctypes.c_int(1)
        for attr in (20, 19):  # DWMWA_USE_IMMERSIVE_DARK_MODE (new/old)
            ctypes.windll.dwmapi.DwmSetWindowAttribute(
                hwnd, attr, ctypes.byref(value), ctypes.sizeof(value)
            )
    except Exception:
        pass


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("收藏夹智能分类")
        self.geometry("920x780")
        self.minsize(780, 660)
        self.configure(fg_color=T.BG)
        self._set_icon()
        _apply_dark_titlebar(self)

        self.event_q: queue.Queue = queue.Queue()
        self.controller = PipelineController(
            on_event=lambda k, p: self.event_q.put((k, p))
        )
        self.server: LanServer | None = None
        self.toast = Toast(self)

        self._build_layout()
        self._show_page("run")
        self.apply_server_config()
        self._poll_events()
        self.pages["run"].init_logs()
        self._fade_in(0.0)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _set_icon(self):
        icon = paths.package_dir().parent / "assets" / "app_icon.ico"
        if icon.exists():
            try:
                self.iconbitmap(str(icon))
            except Exception:
                pass

    # ── layout ─────────────────────────────────────────────────

    def _build_layout(self):
        # Sidebar
        sidebar = ctk.CTkFrame(
            self, fg_color=T.SURFACE, width=192, corner_radius=0,
            border_width=0,
        )
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        brand = ctk.CTkFrame(sidebar, fg_color="transparent")
        brand.pack(fill="x", padx=18, pady=(24, 18))
        self.mascot = Mascot(brand, size=40, bg=T.SURFACE)
        self.mascot.pack(side="left")
        text_col = ctk.CTkFrame(brand, fg_color="transparent")
        text_col.pack(side="left", padx=(10, 0))
        ctk.CTkLabel(
            text_col, text="收藏夹分类",
            font=T.font(14, "bold"), text_color=T.TEXT, anchor="w",
        ).pack(anchor="w")
        ctk.CTkLabel(
            text_col, text="本地 · AI 整理",
            font=T.font(9), text_color=T.TEXT_DIM, anchor="w",
        ).pack(anchor="w", pady=(1, 0))

        ctk.CTkFrame(sidebar, fg_color=T.BORDER, height=1).pack(
            fill="x", padx=18, pady=(0, 14)
        )

        self.nav_buttons: dict[str, ctk.CTkButton] = {}
        for key, icon, label in NAV:
            btn = ctk.CTkButton(
                sidebar, text=f"  {icon}    {label}",
                command=lambda k=key: self._show_page(k),
                font=T.font(12, "bold"), anchor="w",
                fg_color="transparent", text_color=T.TEXT_MID,
                hover_color=T.SURFACE_2, height=42, corner_radius=10,
            )
            btn.pack(fill="x", padx=12, pady=3)
            self.nav_buttons[key] = btn

        foot = ctk.CTkFrame(sidebar, fg_color="transparent")
        foot.pack(side="bottom", fill="x", padx=18, pady=16)
        ctk.CTkLabel(
            foot, text="🔒 数据仅存储在本地",
            font=T.font(9), text_color=T.TEXT_DIM, anchor="w",
        ).pack(anchor="w")
        ctk.CTkLabel(
            foot, text="v2.1 · 无需联网也能用",
            font=T.font(9), text_color=T.TEXT_DIM, anchor="w",
        ).pack(anchor="w", pady=(2, 0))

        # Content area
        self.content = ctk.CTkFrame(self, fg_color="transparent")
        self.content.pack(side="left", fill="both", expand=True,
                          padx=26, pady=22)

        self.pages = {
            "run": HomePage(self.content, self),
            "results": ResultsPage(self.content, self),
            "rules": RulesPage(self.content, self),
            "settings": SettingsPage(self.content, self),
        }
        for page in self.pages.values():
            page.place(relwidth=1, relheight=1)

    def _show_page(self, key: str):
        self.pages[key].tkraise()
        for k, btn in self.nav_buttons.items():
            if k == key:
                btn.configure(fg_color=T.SURFACE_2, text_color=T.PRIMARY)
            else:
                btn.configure(fg_color="transparent", text_color=T.TEXT_MID)
        if key == "results":
            self.pages["results"].refresh()

    # ── event pump ─────────────────────────────────────────────

    def _poll_events(self):
        while True:
            try:
                kind, payload = self.event_q.get_nowait()
            except queue.Empty:
                break
            home = self.pages["run"]
            if kind == "log":
                home.on_log(payload)
            elif kind == "progress":
                home.on_progress(*payload)
            elif kind == "done":
                home.on_done(payload)
        self.after(100, self._poll_events)

    # ── server lifecycle ───────────────────────────────────────

    def apply_server_config(self):
        """(Re)start or stop the LAN server per current config."""
        cfg = load_config()
        if self.server is not None:
            self.server.stop()
            self.server = None
        if cfg.get("SERVER_ENABLED", True):
            self.server = LanServer(self.controller,
                                    port=cfg.get("SERVER_PORT", 8765))
            ok, msg = self.server.start()
            if not ok:
                self.pages["run"].on_log(f"⚠ 手机端服务启动失败: {msg}")
                self.server = None
        settings_page = self.pages.get("settings")
        if settings_page is not None:
            settings_page._update_server_status()

    def server_url(self) -> str | None:
        return self.server.url if self.server else None

    # ── misc ───────────────────────────────────────────────────

    def refresh_results(self):
        self.pages["results"].refresh()

    def open_data_dir(self):
        if sys.platform == "win32":
            os.startfile(str(paths.DATA_DIR))  # noqa: S606 - local folder
        else:
            subprocess.Popen(["xdg-open", str(paths.DATA_DIR)])

    def _fade_in(self, alpha: float):
        if alpha < 1.0:
            self.attributes("-alpha", alpha)
            self.after(12, lambda: self._fade_in(min(alpha + 0.06, 1.0)))
        else:
            self.attributes("-alpha", 1.0)

    def _on_close(self):
        if self.server is not None:
            self.server.stop()
        self.destroy()


def main():
    app = App()
    app.mainloop()
