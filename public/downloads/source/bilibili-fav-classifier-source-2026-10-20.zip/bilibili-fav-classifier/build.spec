# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_submodules, collect_data_files

hiddenimports = [
    "playwright",
    "playwright.sync_api",
    "playwright.async_api",
    "tkinter",
    "PIL",
    "PIL._tkinter_finder",
    "customtkinter",
    "ui",
    "ui.app",
    "ui.theme",
    "ui.widgets",
    "ui.pages",
    "ui.pages.home",
    "ui.pages.results",
    "ui.pages.rules",
    "ui.pages.settings",
]

datas = [
    ("bilibili_fav_classifier/config_template.json", "."),
    ("bilibili_fav_classifier/seed_mappings_template.json", "."),
    ("bilibili_fav_classifier/web", "bilibili_fav_classifier/web"),
    ("assets/app_icon.ico", "assets"),
]

a = Analysis(
    ["launcher.py"],
    pathex=[],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=None,
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="bilibili-fav-classifier",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon="assets/app_icon.ico",
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    name="bilibili-fav-classifier",
)
