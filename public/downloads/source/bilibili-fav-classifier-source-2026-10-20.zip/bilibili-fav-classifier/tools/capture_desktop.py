"""Dev-only: render the desktop UI with demo data and screenshot each page.

Uses a throwaway data directory so the real config/plan files are
never touched. Run with the GUI venv python.
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# ── Redirect data files to a temp dir BEFORE importing config ─────
DEMO = Path(tempfile.mkdtemp(prefix="bfc_shots_"))
from bilibili_fav_classifier import paths  # noqa: E402

for name in dir(paths):
    if name.endswith("_JSON"):
        setattr(paths, name, DEMO / getattr(paths, name).name)
paths.DATA_DIR = DEMO

DEMO.mkdir(parents=True, exist_ok=True)
(DEMO / "config.json").write_text(json.dumps({
    "USER_MID": "12345678", "DEFAULT_FAV_ID": 0,
    "CLASSIFY_MODE": "hybrid", "DEEPSEEK_API_KEY": "sk-demo-1234567890abcdef",
    "SERVER_ENABLED": False, "SERVER_PORT": 8765,
}, ensure_ascii=False), encoding="utf-8")

GROUPS = {
    "编程开发": [
        ("BV1a1", "【完整版】Python 从零到一，3 小时搞懂爬虫与自动化"),
        ("BV1a2", "Rust 所有权机制到底难在哪？一次讲透借用检查"),
        ("BV1a3", "手撸一个 Web 框架：从 HTTP 协议到路由实现"),
        ("BV1a4", "Git 高级技巧：rebase / cherry-pick / reflog 实战"),
        ("BV1a5", "Docker 部署踩坑合集，这 8 个坑我替你踩过了"),
        ("BV1a6", "Vim 三个月使用体验：我的 30 个插件配置"),
        ("BV1a7", "从 0 写一个简易数据库——B+ 树索引实现"),
        ("BV1a8", "正则表达式速成，看完就能上手改别人的规则"),
        ("BV1a9", "TypeScript 类型体操入门：从泛型到条件类型"),
        ("BV1b1", "编译原理速通：两周手写一个玩具编译器"),
    ],
    "美食探店": [
        ("BV2a1", "在成都吃了 7 天，这 5 家苍蝇馆子值得专门去"),
        ("BV2a2", "一人食 · 15 分钟快手番茄牛腩面"),
        ("BV2a3", "探店 | 人均 40 的日式咖喱，米饭可以免费续"),
    ],
    "知识科普": [
        ("BV3a1", "为什么天空是蓝色的？瑞利散射到底在说什么"),
        ("BV3a2", "从 1G 到 5G：通信技术七十年简史"),
        ("BV3a3", "睡眠科学：REM 周期与记忆巩固的关系"),
    ],
    "音乐现场": [
        ("BV4a1", "【4K】这张现场专辑我循环了一整年"),
        ("BV4a2", "钢琴改编 | 把电子乐弹成古典是什么感觉"),
    ],
    "其他": [
        ("BV5a1", "随手记录：周末逛了趟旧书市场"),
        ("BV5a2", "没有分区的小众宝藏频道合集"),
    ],
}
AI = {
    "BV1a1": ("Python 爬虫与自动化 3 小时速通", "从环境搭建到实战爬虫，覆盖 requests 与异步抓取。"),
    "BV1a2": ("Rust 借用检查机制详解", "用图解方式解释所有权、生命周期与借用规则的冲突场景。"),
    "BV3a1": ("天空为何呈蓝色：瑞利散射", "用散射截面公式解释波长与颜色的关系。"),
    "BV3a3": ("睡眠周期与记忆巩固", "梳理 REM / 慢波睡眠对记忆编码的作用。"),
}

videos, plan_groups, ai_map = [], {}, {}
for folder, items in GROUPS.items():
    plan_groups[folder] = []
    for bvid, title in items:
        videos.append({"bvid": bvid, "title": title, "id": len(videos) + 1})
        plan_groups[folder].append({"id": len(videos), "bvid": bvid})
        if bvid in AI:
            clean, summary = AI[bvid]
            ai_map[bvid] = {"folder": folder, "clean_title": clean, "summary": summary}

(DEMO / "favs.json").write_text(json.dumps(
    {"videos": videos}, ensure_ascii=False), encoding="utf-8")
(DEMO / "plan.json").write_text(json.dumps(
    {"move": True, "groups": plan_groups}, ensure_ascii=False), encoding="utf-8")
(DEMO / "ai_results.json").write_text(json.dumps(
    ai_map, ensure_ascii=False), encoding="utf-8")

# ── Patch already-imported config constants ───────────────────────
from bilibili_fav_classifier import config  # noqa: E402

config.CONFIG_FILE = DEMO / "config.json"
config.FAVS_JSON = DEMO / "favs.json"
config.PLAN_JSON = DEMO / "plan.json"
config.APPLY_LOG_JSON = DEMO / "apply_log.json"
config.ENRICH_CACHE_JSON = DEMO / "enrich_cache.json"
config.SEED_FILE = ROOT / "seed_mappings.json"

import ctypes  # noqa: E402
import time  # noqa: E402
from ctypes import wintypes  # noqa: E402

from PIL import Image  # noqa: E402

OUT = ROOT / "docs" / "screenshots"
OUT.mkdir(parents=True, exist_ok=True)

_user32 = ctypes.windll.user32
_gdi32 = ctypes.windll.gdi32


class _BMIH(ctypes.Structure):
    _fields_ = [
        ("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG),
        ("biHeight", wintypes.LONG), ("biPlanes", wintypes.WORD),
        ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
        ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
        ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
        ("biClrImportant", wintypes.DWORD),
    ]


def _hwnd_of(widget) -> int:
    """Return the real toplevel HWND owning `widget` (frame, not client)."""
    hwnd = _user32.GetParent(widget.winfo_id())
    while True:
        parent = _user32.GetParent(hwnd)
        if not parent:
            return hwnd
        hwnd = parent


def _grab_window(hwnd: int) -> Image.Image:
    """Render a window into a bitmap via PrintWindow (works when occluded)."""
    rect = wintypes.RECT()
    _user32.GetWindowRect(hwnd, ctypes.byref(rect))
    w, h = rect.right - rect.left, rect.bottom - rect.top
    hdc_win = _user32.GetWindowDC(hwnd)
    hdc_mem = _gdi32.CreateCompatibleDC(hdc_win)
    bmp = _gdi32.CreateCompatibleBitmap(hdc_win, w, h)
    _gdi32.SelectObject(hdc_mem, bmp)
    _user32.PrintWindow(hwnd, hdc_mem, 2)  # PW_RENDERFULLCONTENT

    bi = _BMIH()
    bi.biSize = ctypes.sizeof(_BMIH)
    bi.biWidth, bi.biHeight = w, -h  # negative = top-down rows
    bi.biPlanes, bi.biBitCount, bi.biCompression = 1, 32, 0
    buf = ctypes.create_string_buffer(w * h * 4)
    _gdi32.GetDIBits(hdc_mem, bmp, 0, h, buf, ctypes.byref(bi), 0)
    img = Image.frombuffer("RGBA", (w, h), buf, "raw", "BGRA", 0, 1).convert("RGB")
    _gdi32.DeleteObject(bmp)
    _gdi32.DeleteDC(hdc_mem)
    _user32.ReleaseDC(hwnd, hdc_win)
    return img


def _capture(app, name: str):
    app.update_idletasks()
    app.update()
    time.sleep(0.5)
    app.update()
    img = _grab_window(_hwnd_of(app))
    img.save(OUT / f"{name}.png")
    print(f"saved {name}.png {img.width}x{img.height}")


def main():
    from ui.app import App

    app = App()
    app.attributes("-alpha", 1.0)
    app.geometry("+60+40")
    app.update()

    app._show_page("run")
    app.pages["run"].init_logs()
    _capture(app, "desktop_home")

    app._show_page("results")
    app.pages["results"].refresh()
    blocks = app.pages["results"].scroll.winfo_children()
    if blocks and hasattr(blocks[0], "toggle"):
        blocks[0].toggle()  # open the first folder for the shot
    _capture(app, "desktop_results")

    app._show_page("rules")
    _capture(app, "desktop_rules")

    app._show_page("settings")
    _capture(app, "desktop_settings")

    app.destroy()
    print("demo dir:", DEMO)


if __name__ == "__main__":
    main()
