"""Dev-only: screenshot the mobile web UI at phone viewport.

Starts a real LanServer against a throwaway demo data dir, so the
pictures show the same state a phone would see.
"""
from __future__ import annotations

import json
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

DEMO = Path(tempfile.mkdtemp(prefix="bfc_shots_m_"))
from bilibili_fav_classifier import paths  # noqa: E402

for name in dir(paths):
    if name.endswith("_JSON"):
        setattr(paths, name, DEMO / getattr(paths, name).name)
paths.DATA_DIR = DEMO
DEMO.mkdir(parents=True, exist_ok=True)

(DEMO / "config.json").write_text(json.dumps({
    "USER_MID": "12345678", "CLASSIFY_MODE": "hybrid",
    "DEEPSEEK_API_KEY": "sk-demo-1234567890abcdef",
    "SERVER_ENABLED": True, "SERVER_PORT": 8899,
}, ensure_ascii=False), encoding="utf-8")

GROUPS = {
    "编程开发": [
        ("BV1a1", "【完整版】Python 从零到一，3 小时搞懂爬虫与自动化"),
        ("BV1a2", "Rust 所有权机制到底难在哪？一次讲透借用检查"),
        ("BV1a3", "手撸一个 Web 框架：从 HTTP 协议到路由实现"),
        ("BV1a4", "Git 高级技巧：rebase / cherry-pick / reflog 实战"),
        ("BV1a5", "Docker 部署踩坑合集，这 8 个坑我替你踩过了"),
        ("BV1a6", "Vim 三个月使用体验：我的 30 个插件配置"),
        ("BV1a7", "从 0 写一个简易数据库——B+ 树索引实现"),
        ("BV1a8", "正则表达式速成，看完就能上手改别人的规则"),
        ("BV1a9", "TypeScript 类型体操入门：从泛型到条件类型"),
        ("BV1b1", "编译原理速通：两周手写一个玩具编译器"),
    ],
    "美食探店": [
        ("BV2a1", "在成都吃了 7 天，这 5 家苍蝇馆子值得专门去"),
        ("BV2a2", "一人食 · 15 分钟快手番茄牛腩面"),
        ("BV2a3", "探店 | 人均 40 的日式咖喱，米饭可以免费续"),
    ],
    "知识科普": [
        ("BV3a1", "为什么天空是蓝色的？瑞利散射到底在说什么"),
        ("BV3a2", "从 1G 到 5G：通信技术七十年简史"),
        ("BV3a3", "睡眠科学：REM 周期与记忆巩固的关系"),
    ],
    "音乐现场": [
        ("BV4a1", "【4K】这张现场专辑我循环了一整年"),
        ("BV4a2", "钢琴改编 | 把电子乐弹成古典是什么感觉"),
    ],
    "其他": [
        ("BV5a1", "随手记录：周末逛了趟旧书市场"),
        ("BV5a2", "没有分区的小众宝藏频道合集"),
    ],
}
AI = {
    "BV1a1": ("Python 爬虫与自动化 3 小时速通", "从环境搭建到实战爬虫，覆盖 requests 与异步抓取。"),
    "BV1a2": ("Rust 借用检查机制详解", "用图解方式解释所有权、生命周期与借用规则的冲突场景。"),
    "BV3a1": ("天空为何呈蓝色：瑞利散射", "用散射截面公式解释波长与颜色的关系。"),
    "BV3a3": ("睡眠周期与记忆巩固", "梳理 REM / 慢波睡眠对记忆编码的作用。"),
}

videos, plan_groups, ai_map = [], {}, {}
for folder, items in GROUPS.items():
    plan_groups[folder] = []
    for bvid, title in items:
        videos.append({"bvid": bvid, "title": title, "id": len(videos) + 1})
        plan_groups[folder].append({"id": len(videos), "bvid": bvid})
        if bvid in AI:
            clean, summary = AI[bvid]
            ai_map[bvid] = {"folder": folder, "clean_title": clean, "summary": summary}

(DEMO / "favs.json").write_text(json.dumps({"videos": videos}, ensure_ascii=False),
                               encoding="utf-8")
(DEMO / "plan.json").write_text(json.dumps({"move": True, "groups": plan_groups},
                                           ensure_ascii=False), encoding="utf-8")
(DEMO / "ai_results.json").write_text(json.dumps(ai_map, ensure_ascii=False),
                                      encoding="utf-8")

from bilibili_fav_classifier import config  # noqa: E402

config.CONFIG_FILE = DEMO / "config.json"
config.FAVS_JSON = DEMO / "favs.json"
config.PLAN_JSON = DEMO / "plan.json"
config.SEED_FILE = ROOT / "seed_mappings.json"

from bilibili_fav_classifier.controller import PipelineController  # noqa: E402
from bilibili_fav_classifier.server import LanServer  # noqa: E402

OUT = ROOT / "docs" / "screenshots"
OUT.mkdir(parents=True, exist_ok=True)
CHROME = Path(r"C:\Users\胡希\AppData\Local\ms-playwright\chromium-1243"
              r"\chrome-win64\chrome.exe")


def main():
    from playwright.sync_api import sync_playwright

    controller = PipelineController()
    server = LanServer(controller, port=8899)
    ok, msg = server.start()
    print("server:", ok, msg, server.url)
    if not ok:
        return
    url = server.url

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(executable_path=str(CHROME))
            page = browser.new_page(
                viewport={"width": 390, "height": 844},
                device_scale_factor=2, is_mobile=True, has_touch=True,
                locale="zh-CN",
            )
            page.goto(url, wait_until="networkidle")
            time.sleep(0.8)
            page.screenshot(path=str(OUT / "mobile_run.png"))
            print("saved mobile_run.png")

            page.click("nav button:nth-child(2)")
            page.wait_for_timeout(900)
            page.screenshot(path=str(OUT / "mobile_results.png"))
            print("saved mobile_results.png")

            page.click("nav button:nth-child(3)")
            page.wait_for_timeout(900)
            page.screenshot(path=str(OUT / "mobile_settings.png"))
            print("saved mobile_settings.png")
            browser.close()
    finally:
        server.stop()


if __name__ == "__main__":
    main()
