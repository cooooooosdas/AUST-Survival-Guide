"""DeepSeek AI integration: classify, clean titles, summarize.

Zero new dependencies — talks to the OpenAI-compatible DeepSeek API
via requests. All failures raise AIError subclasses so callers can
fall back to the local rule engine gracefully:

    AIAuthError      invalid/expired API key (401/403)
    AIRateLimitError rate limited (429)
    AINetworkError   no network / timeout / DNS
    AIResponseError  5xx, malformed JSON, unexpected shape

AI results are cached in ai_results.json:
    {bvid: {"folder", "clean_title", "summary", "ts"}}
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import requests

from bilibili_fav_classifier import paths
from bilibili_fav_classifier.rules import ALL_FOLDERS

DEFAULT_BASE_URL = "https://api.deepseek.com"
DEFAULT_MODEL = "deepseek-chat"
BATCH_SIZE = 20           # videos per API call
REQUEST_TIMEOUT = 60
MAX_RETRIES = 2           # retries for transient failures (not auth)
RETRY_BACKOFF = 5         # seconds


# ── Errors ───────────────────────────────────────────────────────

class AIError(Exception):
    """Base class for AI call failures."""


class AIAuthError(AIError):
    """API key invalid or expired."""


class AIRateLimitError(AIError):
    """Rate limited by the API."""


class AINetworkError(AIError):
    """Network unreachable / timeout / DNS failure."""


class AIResponseError(AIError):
    """Unexpected HTTP status or malformed response."""


# ── Client ───────────────────────────────────────────────────────

class DeepSeekClient:
    """Minimal OpenAI-compatible client for DeepSeek."""

    def __init__(self, api_key: str, model: str = DEFAULT_MODEL,
                 base_url: str = DEFAULT_BASE_URL, timeout: int = REQUEST_TIMEOUT):
        self.api_key = api_key
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def chat(self, messages: list[dict], max_tokens: int = 4096,
             json_mode: bool = False) -> str:
        """Single chat completion. Returns assistant content string.

        Raises AIError subclasses on any failure.
        """
        payload: dict = {
            "model": self.model,
            "messages": messages,
            "temperature": 0.2,
            "max_tokens": max_tokens,
            "stream": False,
        }
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
        try:
            r = requests.post(
                f"{self.base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json=payload,
                timeout=self.timeout,
            )
        except (requests.exceptions.Timeout,
                requests.exceptions.ConnectionError) as exc:
            raise AINetworkError(f"网络连接失败: {exc}") from None
        except requests.exceptions.RequestException as exc:
            raise AINetworkError(f"请求失败: {exc}") from None

        if r.status_code in (401, 403):
            raise AIAuthError("API Key 无效或已过期 (HTTP %d)" % r.status_code)
        if r.status_code == 429:
            raise AIRateLimitError("API 请求频率超限 (HTTP 429)")
        if r.status_code == 402:
            raise AIAuthError("DeepSeek 账户余额不足 (HTTP 402)")
        if r.status_code != 200:
            raise AIResponseError(f"API 返回异常状态 (HTTP {r.status_code})")

        try:
            data = r.json()
            return data["choices"][0]["message"]["content"]
        except (ValueError, KeyError, IndexError, TypeError) as exc:
            raise AIResponseError(f"API 响应格式异常: {exc}") from None

    def verify_key(self) -> tuple[bool, str]:
        """Cheap key check. Returns (ok, message)."""
        if not self.api_key:
            return False, "未填写 API Key"
        try:
            self.chat([{"role": "user", "content": "hi"}], max_tokens=1)
            return True, "API Key 验证成功"
        except AIAuthError as exc:
            return False, str(exc)
        except AIRateLimitError as exc:
            return False, str(exc)
        except AINetworkError as exc:
            return False, f"网络异常: {exc}"
        except AIResponseError as exc:
            return False, str(exc)
        except Exception as exc:  # defensive: never crash the settings page
            return False, f"未知错误: {exc}"


# ── Prompt ───────────────────────────────────────────────────────

_SYSTEM_PROMPT = """你是一个视频收藏整理助手。用户会给你一批 B 站视频的信息（标题、UP主、分区、标签）。
请为每个视频完成三件事：
1. folder: 从以下分类中选出最合适的一个（必须原样返回，不得自创分类）：
   {folders}
   如果实在无法判断，返回 "其他"。
2. clean_title: 清理后的标题 —— 去除营销词、emoji、多余标点、合集后缀等，保留核心内容，不超过 30 字。
3. summary: 一句话内容摘要（不超过 50 字），说明这个视频讲什么、有什么用。

只返回 JSON，格式为：
{{"results": [{{"bvid": "...", "folder": "...", "clean_title": "...", "summary": "..."}}]}}
""".replace("{folders}", "、".join(ALL_FOLDERS))


def _build_user_prompt(batch: list[dict]) -> str:
    items = [
        {
            "bvid": v.get("bvid", ""),
            "title": v.get("title", ""),
            "upper": v.get("upper", ""),
            "tname": v.get("tname", ""),
            "tags": v.get("tags") or [],
        }
        for v in batch
    ]
    return "请整理以下视频：\n" + json.dumps(items, ensure_ascii=False)


def _parse_results(content: str) -> list[dict]:
    """Parse the model's JSON response. Raises AIResponseError."""
    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        # Tolerate markdown fences despite json_mode
        stripped = content.strip()
        if stripped.startswith("```"):
            stripped = stripped.strip("`")
            stripped = stripped.split("\n", 1)[-1]
        try:
            data = json.loads(stripped)
        except json.JSONDecodeError as exc:
            raise AIResponseError(f"AI 返回的内容不是合法 JSON: {exc}") from None
    results = data.get("results") if isinstance(data, dict) else None
    if not isinstance(results, list):
        raise AIResponseError("AI 响应缺少 results 数组")
    return [r for r in results if isinstance(r, dict) and r.get("bvid")]


# ── Batch classification ─────────────────────────────────────────

def ai_classify_videos(
    videos: list[dict],
    client: DeepSeekClient,
    progress_cb=None,
    stop_event=None,
) -> tuple[dict[str, dict], list[str]]:
    """Classify videos via DeepSeek in batches.

    Returns (ai_map, errors):
        ai_map: {bvid: {"folder", "clean_title", "summary"}}
                folder is guaranteed ∈ ALL_FOLDERS ∪ {"其他"}.
        errors: human-readable failure messages (per batch).

    Batch failures are isolated: one failing batch does not abort the
    rest; failed videos are simply absent from ai_map so callers can
    fall back to local rules for them.
    """
    ai_map: dict[str, dict] = {}
    errors: list[str] = []
    valid_folders = set(ALL_FOLDERS) | {"其他"}

    batches = [videos[i:i + BATCH_SIZE] for i in range(0, len(videos), BATCH_SIZE)]
    for bi, batch in enumerate(batches):
        if stop_event is not None and stop_event.is_set():
            errors.append("用户停止")
            break
        if progress_cb:
            done = bi * BATCH_SIZE
            pct = int(done / len(videos) * 100) if videos else 100
            progress_cb(pct, "AI 整理中...", f"批次 {bi + 1}/{len(batches)}")

        messages = [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user", "content": _build_user_prompt(batch)},
        ]
        content = None
        for attempt in range(MAX_RETRIES + 1):
            try:
                content = client.chat(messages, json_mode=True)
                break
            except AIAuthError as exc:
                # Auth errors are fatal: retrying won't help
                errors.append(str(exc))
                if progress_cb:
                    progress_cb(100, "AI 鉴权失败", "")
                return ai_map, errors
            except (AINetworkError, AIRateLimitError, AIResponseError) as exc:
                if attempt < MAX_RETRIES:
                    time.sleep(RETRY_BACKOFF)
                else:
                    errors.append(f"批次 {bi + 1} 失败: {exc}")
        if content is None:
            continue

        try:
            results = _parse_results(content)
        except AIResponseError as exc:
            errors.append(f"批次 {bi + 1} 响应解析失败: {exc}")
            continue

        for r in results:
            folder = r.get("folder", "")
            if folder not in valid_folders:
                folder = "其他"
            ai_map[r["bvid"]] = {
                "folder": folder,
                "clean_title": str(r.get("clean_title", ""))[:60],
                "summary": str(r.get("summary", ""))[:120],
            }

    if progress_cb:
        progress_cb(100, "AI 整理完成", f"{len(ai_map)}/{len(videos)} 个视频")
    return ai_map, errors


# ── Result cache ─────────────────────────────────────────────────

def load_ai_results(path: Path | None = None) -> dict[str, dict]:
    p = Path(path) if path is not None else paths.AI_RESULTS_JSON
    if p.exists():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_ai_results(results: dict[str, dict], path: Path | None = None) -> Path:
    p = Path(path) if path is not None else paths.AI_RESULTS_JSON
    p.write_text(
        json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return p


def merge_ai_results(new: dict[str, dict], path: Path | None = None) -> dict[str, dict]:
    """Merge new AI results into the on-disk cache and persist."""
    cached = load_ai_results(path)
    cached.update(new)
    for r in cached.values():
        r.setdefault("ts", int(time.time()))
    save_ai_results(cached, path)
    return cached


# ── ClassifyResult integration ───────────────────────────────────

def apply_ai_results(result, ai_map: dict[str, dict]):
    """Re-file videos in a ClassifyResult according to AI decisions.

    Videos whose bvid appears in ai_map are moved to the AI-chosen
    folder and counted under the "ai" layer. Others keep their local
    classification (local fallback for AI failures).
    """
    from collections import defaultdict

    from bilibili_fav_classifier.classify_core import ClassifyResult

    new_groups: dict[str, list[dict]] = defaultdict(list)
    layer_counts: dict[str, int] = defaultdict(int)

    for folder, vids in result.groups.items():
        for v in vids:
            bvid = v.get("bvid", "")
            ai = ai_map.get(bvid)
            if ai:
                new_folder = ai["folder"]
                layer_counts["ai"] += 1
            else:
                new_folder = folder
                # recover original layer count: recompute cheaply by
                # keeping folders from the local result
                layer_counts["local"] += 1
            new_groups[new_folder].append(v)

    total = sum(len(v) for v in new_groups.values())
    return ClassifyResult(
        groups=dict(new_groups),
        layer_counts={
            "ai": layer_counts.get("ai", 0),
            "local": layer_counts.get("local", 0),
        },
        unmatched_ups=result.unmatched_ups,
        duplicate_ups=result.duplicate_ups,
        total=total,
    )
