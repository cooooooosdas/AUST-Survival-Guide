"""PipelineController: shared runtime state for all front-ends.

The desktop GUI and the LAN web server both drive the pipeline through
this controller, so both ends see identical state and behavior:

- start()/stop() control the single running pipeline
- events (log/progress/done) are appended to a ring buffer
- status() returns a JSON-serializable snapshot for polling UIs
"""
from __future__ import annotations

import threading
from collections import deque
from typing import Callable

from bilibili_fav_classifier.config import load_config
from bilibili_fav_classifier.pipeline import Pipeline

LOG_BUFFER_SIZE = 500

STEP_NAMES = ["拉取", "补充", "分类", "应用"]


class PipelineController:
    """Thread-safe owner of the currently running pipeline."""

    def __init__(self, on_event: Callable[[str, object], None] | None = None):
        self._lock = threading.Lock()
        self._pipeline: Pipeline | None = None
        self._running = False
        self._status_text = "就绪"
        self._progress = 0
        self._step = -1
        self._detail = ""
        self._last_done: str | None = None
        self._logs: deque[str] = deque(maxlen=LOG_BUFFER_SIZE)
        self._log_seq = 0
        self._on_event = on_event  # optional extra listener (e.g. GUI queue)

    # ── Control ────────────────────────────────────────────────

    def start(self, move: bool = True, do_apply: bool = True) -> tuple[bool, str]:
        """Start the pipeline. Returns (started, message)."""
        with self._lock:
            if self._running:
                return False, "任务正在运行中"
            self._running = True
            self._status_text = "运行中"
            self._progress = 0
            self._step = -1
            self._detail = ""
            self._last_done = None
            self._pipeline = Pipeline(
                self._handle_event, move=move, do_apply=do_apply,
            )
        threading.Thread(target=self._pipeline.run, daemon=True).start()
        return True, "已启动"

    def stop(self) -> tuple[bool, str]:
        with self._lock:
            if not self._running or self._pipeline is None:
                return False, "当前没有运行中的任务"
            self._pipeline.stop()
        return True, "正在停止..."

    # ── Event handling (called from the pipeline thread) ───────

    def _handle_event(self, kind: str, payload) -> None:
        with self._lock:
            if kind == "log":
                self._logs.append(str(payload))
                self._log_seq += 1
            elif kind == "progress":
                pct, msg, step, detail = payload
                self._progress = pct
                self._status_text = msg
                self._step = step
                self._detail = detail
            elif kind == "done":
                self._running = False
                self._last_done = str(payload)
                self._status_text = {
                    "success": "全部完成",
                    "stopped": "已停止",
                    "error": "运行出错",
                }.get(str(payload), str(payload))
        if self._on_event is not None:
            self._on_event(kind, payload)

    # ── Read APIs (JSON-serializable) ──────────────────────────

    def status(self) -> dict:
        with self._lock:
            return {
                "running": self._running,
                "status": self._status_text,
                "progress": self._progress,
                "step": self._step,
                "step_names": STEP_NAMES,
                "detail": self._detail,
                "last_done": self._last_done,
            }

    def logs_since(self, index: int = 0) -> dict:
        """Incremental log fetch. Returns {logs, next}."""
        with self._lock:
            logs = list(self._logs)
            total = self._log_seq
        first = total - len(logs)  # seq number of logs[0]
        if index < first:
            index = first
        start = index - first
        return {"logs": logs[start:], "next": total}

    @property
    def running(self) -> bool:
        with self._lock:
            return self._running


def results_summary() -> dict:
    """Latest classification results for the results page (both ends).

    Merges plan.json groups with ai_results.json metadata and
    favs.json titles so UIs can render folder → videos with optional
    AI clean titles and summaries.
    """
    from bilibili_fav_classifier.ai import load_ai_results
    from bilibili_fav_classifier.plan import PlanError, load_favs, load_plan

    out: dict = {"available": False, "groups": {}, "total": 0,
                 "move": False, "ai_count": 0}
    try:
        plan = load_plan()
    except PlanError:
        return out

    titles: dict[str, str] = {}
    try:
        favs = load_favs()
        for v in favs.get("videos", []):
            if v.get("bvid"):
                titles[v["bvid"]] = v.get("title", "")
    except PlanError:
        pass

    ai_map = load_ai_results()
    groups: dict[str, list[dict]] = {}
    total = 0
    for folder, vids in plan.get("groups", {}).items():
        items = []
        for v in vids:
            bvid = v.get("bvid", "")
            ai = ai_map.get(bvid, {})
            items.append({
                "bvid": bvid,
                "title": titles.get(bvid, ""),
                "clean_title": ai.get("clean_title", ""),
                "summary": ai.get("summary", ""),
                "ai": bool(ai),
            })
        groups[folder] = items
        total += len(items)

    out.update({
        "available": True,
        "groups": groups,
        "total": total,
        "move": bool(plan.get("move")),
        "ai_count": sum(1 for items in groups.values() for i in items if i["ai"]),
    })
    return out
