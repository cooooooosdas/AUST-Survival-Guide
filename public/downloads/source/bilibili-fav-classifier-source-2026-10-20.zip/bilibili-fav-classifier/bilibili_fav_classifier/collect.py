"""Async browser automation: collect all videos from the default favorite folder.

Entry point: collect() — launches Playwright, logs in via QR, scrapes favorites.
User IDs are auto-detected from the API and persisted to config.json.
"""
from __future__ import annotations

import asyncio
import html
import json
import os
from collections import defaultdict
from pathlib import Path

from playwright.async_api import async_playwright

from bilibili_fav_classifier import paths
from bilibili_fav_classifier.config import API_BASE, save_user_config
from bilibili_fav_classifier.session import save_cookies

# ── Tunables ─────────────────────────────────────────────────────

LOGIN_TIMEOUT_SEC = 180        # QR-code login wait
PAGE_LIMIT = 200               # 200 pages * 20 items = 4000 videos max
PAGE_SIZE = 20
PAGE_INTERVAL_MS = 800         # delay between paged API calls
PAGE_LOAD_WAIT_SEC = 3         # wait after opening space.bilibili.com

CHROME_CANDIDATES = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]

BROWSER_ARGS = [
    "--disable-web-security",
    "--disable-features=IsolateOrigins,site-per-process",
    "--no-sandbox",
    "--disable-gpu",
]


def _find_chrome() -> str | None:
    for p in CHROME_CANDIDATES:
        if Path(p).exists():
            return p
    return None


def find_bundled_browser() -> str | None:
    """Find Chromium executable in bundled Playwright browsers dir."""
    browsers_dir = paths.bundled_browsers_dir()
    if not browsers_dir.is_dir():
        return None
    for root, _dirs, files in os.walk(browsers_dir):
        for fname in files:
            if fname in ("chrome.exe", "chromium.exe"):
                return os.path.join(root, fname)
    return None


def setup_frozen_env() -> None:
    """Point Playwright at bundled browsers in frozen builds."""
    if not paths.is_frozen():
        return
    browsers_path = paths.bundled_browsers_dir()
    if browsers_path.is_dir():
        os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(browsers_path)


async def wait_for_login(page, timeout: int = LOGIN_TIMEOUT_SEC):
    """Poll until the user is logged in, return their mid."""
    print("==> 请在浏览器中扫码登录 B站 (若已登录会自动跳过)...")
    for _ in range(timeout // 2):
        mid = await page.evaluate('''async () => {
            try {
                const r = await fetch("https://api.bilibili.com/x/web-interface/nav");
                const j = await r.json();
                return j.data?.isLogin ? j.data.mid : null;
            } catch (e) { return null; }
        }''')
        if mid:
            return mid
        await asyncio.sleep(2)
    return None


async def collect(chrome_path: str | None = None, output_dir: Path | None = None,
                  progress_cb=None):
    """Launch browser, log in, scrape all videos from default favorite folder.

    User MID and default fav ID are auto-detected from the API on first run
    and persisted to config.json for subsequent runs.

    Args:
        chrome_path: Path to Chrome/Chromium executable. Auto-detected if None.
        output_dir: Directory for output files. Defaults to paths.DATA_DIR.
        progress_cb: Optional callback(pct, msg, detail) for progress updates.
    """
    browser_path = chrome_path or find_bundled_browser() or _find_chrome()
    out = Path(output_dir) if output_dir else paths.DATA_DIR
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=False, executable_path=browser_path, args=BROWSER_ARGS,
        )
        context = await browser.new_context()
        page = await context.new_page()
        await page.goto("https://space.bilibili.com/", wait_until="domcontentloaded")
        await asyncio.sleep(PAGE_LOAD_WAIT_SEC)

        mid = await wait_for_login(page)
        if not mid:
            print("==> 登录超时, 请重新运行 collect")
            await context.close()
            await browser.close()
            return
        print(f"==> 登录用户 mid={mid}")
        await save_cookies(context)
        if progress_cb:
            progress_cb(10, "登录成功", f"mid={mid}")

        # Fetch folders list using the logged-in user's mid
        # (params passed via evaluate arg, not string interpolation)
        folders = await page.evaluate('''async ({apiBase, mid}) => {
            try {
                const r = await fetch(
                    apiBase + "/x/v3/fav/folder/created/list-all"
                    + "?up_mid=" + mid + "&platform=web"
                );
                const j = await r.json();
                return j.data?.list || [];
            } catch (e) { return []; }
        }''', {"apiBase": API_BASE, "mid": mid})
        print(f"==> 你的收藏夹 ({len(folders)} 个):")
        for f in folders:
            print(
                f"    - {f.get('title')}"
                f"  (id={f.get('id')}, 数量={f.get('media_count')})"
            )

        default = next(
            (f for f in folders if "默认" in (f.get("title") or "")), None
        )
        default_id = default.get("id") if default else 0
        print(f"==> 默认收藏夹: {default.get('title') if default else '默认'}"
              f" (id={default_id})")

        # Persist user config for future runs (merges; keeps API keys)
        save_user_config(str(mid), default_id)
        print("==> 用户配置已保存到 config.json")

        if not default_id:
            print("==> 未找到默认收藏夹, 退出")
            await context.close()
            await browser.close()
            return

        print("==> 正在拉取默认收藏夹的全部视频...")
        if progress_cb:
            progress_cb(15, "开始拉取视频...", "准备获取收藏夹列表")

        all_items = await page.evaluate('''async ({apiBase, mediaId, pageLimit, pageSize, intervalMs}) => {
            const all = [];
            for (let pn = 1; pn <= pageLimit; pn++) {
                try {
                    const r = await fetch(
                        apiBase + "/x/v3/fav/resource/list"
                        + "?media_id=" + mediaId + "&pn=" + pn
                        + "&ps=" + pageSize + "&platform=web&order=mtime"
                    );
                    const j = await r.json();
                    if (j.code !== 0) { all.push({error:true,code:j.code,page:pn}); break; }
                    const medias = j.data?.medias || [];
                    all.push(...medias);
                    if (!j.data?.has_more || medias.length === 0) break;
                    await new Promise(res => setTimeout(res, intervalMs));
                } catch (e) {
                    all.push({error:true,code:-1,page:pn});
                    break;
                }
            }
            return all;
        }''', {
            "apiBase": API_BASE, "mediaId": default_id,
            "pageLimit": PAGE_LIMIT, "pageSize": PAGE_SIZE,
            "intervalMs": PAGE_INTERVAL_MS,
        })

        items = [it for it in all_items if not it.get("error")]
        errors = [it for it in all_items if it.get("error")]
        for e in errors:
            print(f"    [warn] 第{e.get('page')}页 code={e.get('code')}")
        print(f"==> 共拉取 {len(items)} 条视频")
        if progress_cb:
            progress_cb(80, "拉取完成", f"已获取 {len(items)} 条视频")

        videos = []
        for it in items:
            upper = it.get("upper") or {}
            videos.append({
                "id": it.get("id"),
                "bvid": it.get("bvid"),
                "title": html.unescape(
                    (it.get("title") or "")
                    .replace('<em class="keyword">', "")
                    .replace("</em>", "")
                ),
                "upper": upper.get("name", ""),
                "upper_mid": upper.get("mid"),
                "tname": it.get("tname", ""),
                "tags": it.get("tag", []),
            })

        favs_path = out / "favs.json"
        favs_path.write_text(
            json.dumps(
                {
                    "mid": mid,
                    "default_media_id": default_id,
                    "count": len(videos),
                    "videos": videos,
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        print(f"==> 已保存到 {favs_path}")

        up_map: dict[str, list[str]] = defaultdict(list)
        for v in videos:
            up = v.get("upper") or "未知UP"
            up_map[up].append(v.get("title", ""))
        uppers = [
            {"upper": up, "count": len(ts), "samples": ts[:5]}
            for up, ts in up_map.items()
        ]
        uppers.sort(key=lambda x: x["count"], reverse=True)
        summary_path = out / "up_summary.json"
        summary_path.write_text(
            json.dumps({"total": len(videos), "uppers": uppers}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        print(f"==> 已生成 {summary_path} ({len(uppers)} 个UP主)")
        print("==> 下一步: 运行 enrich_meta 补充标签/分区, 再 autoclassify")
        if progress_cb:
            progress_cb(100, "收藏夹拉取完成", f"共 {len(videos)} 个视频")
        await context.close()
        await browser.close()
