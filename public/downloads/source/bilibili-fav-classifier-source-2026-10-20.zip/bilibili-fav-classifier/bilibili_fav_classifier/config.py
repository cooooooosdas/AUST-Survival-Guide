"""User configuration management for bilibili-fav-classifier.

config.json schema (all keys optional, backward compatible with v1.x):
    USER_MID          : str   Bilibili user id (auto-detected on collect)
    DEFAULT_FAV_ID    : int   default favorite folder id
    CLASSIFY_MODE     : str   "local" | "ai" | "hybrid"  (default "local")
    DEEPSEEK_API_KEY  : str   DeepSeek API key (user-provided)
    DEEPSEEK_MODEL    : str   default "deepseek-chat"
    SERVER_ENABLED    : bool  LAN server for mobile access (default true)
    SERVER_PORT       : int   default 8765

No module-level state is derived from files at import time; callers
always read fresh values via load_config().
"""
from __future__ import annotations

import json

from bilibili_fav_classifier import paths

# ── Path constants (re-exported; tests monkeypatch these names) ──

ROOT = paths.DATA_DIR  # backward-compatible alias
CONFIG_FILE = paths.CONFIG_JSON
COOKIES_PATH = paths.COOKIES_JSON
FAVS_JSON = paths.FAVS_JSON
PLAN_JSON = paths.PLAN_JSON
APPLY_LOG_JSON = paths.APPLY_LOG_JSON
ENRICH_CACHE_JSON = paths.ENRICH_CACHE_JSON
AUTO_CLASSIFY_JSON = paths.AUTO_CLASSIFY_JSON
SEED_FILE = paths.SEED_MAPPINGS_JSON

BATCH_SIZE = 50
API_BASE = "https://api.bilibili.com"

# ── Config schema ────────────────────────────────────────────────

CLASSIFY_MODES = ("local", "ai", "hybrid")

DEFAULT_CONFIG: dict = {
    "USER_MID": "",
    "DEFAULT_FAV_ID": 0,
    "CLASSIFY_MODE": "local",
    "DEEPSEEK_API_KEY": "",
    "DEEPSEEK_MODEL": "deepseek-chat",
    "SERVER_ENABLED": True,
    "SERVER_PORT": 8765,
}


def load_config() -> dict:
    """Load config.json merged over DEFAULT_CONFIG. Never raises."""
    cfg = dict(DEFAULT_CONFIG)
    if CONFIG_FILE.exists():
        try:
            raw = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                cfg.update(raw)
        except (json.JSONDecodeError, OSError) as exc:
            print(f"警告: {CONFIG_FILE} 格式错误 ({exc})，使用默认配置")
    if cfg.get("CLASSIFY_MODE") not in CLASSIFY_MODES:
        cfg["CLASSIFY_MODE"] = "local"
    return cfg


def save_config(updates: dict) -> dict:
    """Merge updates into config.json and persist. Returns the new config.

    Only known keys plus USER_MID/DEFAULT_FAV_ID are written; unknown
    keys in updates are ignored to keep the file schema clean.
    """
    cfg = load_config()
    for key, value in updates.items():
        if key in DEFAULT_CONFIG:
            cfg[key] = value
    if cfg.get("CLASSIFY_MODE") not in CLASSIFY_MODES:
        cfg["CLASSIFY_MODE"] = "local"
    CONFIG_FILE.write_text(
        json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return cfg


# ── Backward-compatible helpers (v1.x API) ───────────────────────

def load_user_config() -> dict:
    """Alias of load_config() kept for backward compatibility."""
    return load_config()


def save_user_config(user_mid: str, default_fav_id: int):
    """Persist identity fields (called by collect after login).

    Merges into existing config so API keys etc. are preserved.
    """
    save_config({"USER_MID": str(user_mid), "DEFAULT_FAV_ID": default_fav_id})


# ── Convenience accessors ────────────────────────────────────────

def get_classify_mode() -> str:
    return load_config()["CLASSIFY_MODE"]


def get_deepseek_key() -> str:
    return load_config().get("DEEPSEEK_API_KEY", "") or ""


# ── Seed mappings (UP主 → folder) ────────────────────────────────

def load_seed_mappings() -> dict[str, list[str]]:
    """Load UP主 → folder mapping from seed_mappings.json."""
    if SEED_FILE.exists():
        try:
            data = json.loads(SEED_FILE.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (json.JSONDecodeError, OSError) as exc:
            print(f"警告: {SEED_FILE} 读取失败 ({exc})，使用空映射")
            return {}
    return {}


def save_seed_mappings(mappings: dict[str, list[str]]):
    """Persist seed mappings to disk."""
    SEED_FILE.write_text(
        json.dumps(mappings, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"==> 种子映射已保存到 {SEED_FILE}")
