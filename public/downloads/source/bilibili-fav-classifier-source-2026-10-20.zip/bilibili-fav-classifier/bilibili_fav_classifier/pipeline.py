"""Unified pipeline orchestration: collect → enrich → classify → apply.

Used identically by the CLI, the desktop GUI, and the LAN web server,
so all three front-ends share the same semantics:

Error semantics (single terminal event, no state overwrite):
- collect fails    → pipeline aborts with "error" (nothing to classify)
- enrich fails     → logged as warning, pipeline continues (tags are an
                     optional accuracy boost; v1.2.1 regression guard)
- classify fails   → pipeline aborts with "error"
- apply fails      → terminal status "error"
- user stop        → terminal status "stopped"
- all ok           → terminal status "success" (emitted exactly once)

Events are delivered via a callback: on_event(kind, payload) where
kind ∈ {"log", "progress", "done"}.
"""
from __future__ import annotations

import asyncio
import json
import threading
import traceback
from dataclasses import dataclass
from typing import Callable

from bilibili_fav_classifier.apply import apply
from bilibili_fav_classifier.classify_core import ClassifyResult, autoclassify
from bilibili_fav_classifier.collect import collect, find_bundled_browser
from bilibili_fav_classifier.config import (
    AUTO_CLASSIFY_JSON,
    load_config,
    load_seed_mappings,
)
from bilibili_fav_classifier.enrich import enrich_meta
from bilibili_fav_classifier.plan import PlanError, build_plan, load_favs, save_plan
from bilibili_fav_classifier.session import Session

EventCallback = Callable[[str, object], None]

STEPS = ("collect", "enrich", "classify", "apply")

# Progress range allocated to each step: (start%, end%)
STEP_PROGRESS = {
    "collect": (5, 25),
    "enrich": (30, 50),
    "classify": (55, 75),
    "apply": (80, 100),
}


@dataclass
class PipelineOutcome:
    status: str                       # "success" | "error" | "stopped"
    result: ClassifyResult | None = None
    error: str = ""


class Pipeline:
    """Runs the four-step pipeline with stop support and event callbacks."""

    def __init__(self, on_event: EventCallback, move: bool = True,
                 only_folder: str | None = None, do_apply: bool = True):
        self.on_event = on_event
        self.move = move
        self.only_folder = only_folder
        self.do_apply = do_apply
        self._stop = threading.Event()
        self.result: ClassifyResult | None = None

    # ── Control ────────────────────────────────────────────────

    def stop(self) -> None:
        self._stop.set()

    @property
    def stopped(self) -> bool:
        return self._stop.is_set()

    # ── Event helpers ──────────────────────────────────────────

    def log(self, msg: str) -> None:
        self.on_event("log", msg)

    def progress(self, pct: int, msg: str, step: int = -1, detail: str = "") -> None:
        self.on_event("progress", (pct, msg, step, detail))

    def _step_progress(self, step_name: str, step_idx: int):
        lo, hi = STEP_PROGRESS[step_name]
        span = hi - lo

        def _cb(pct, msg, detail=""):
            self.progress(lo + int(pct * span / 100), msg, step_idx, detail)

        return _cb

    # ── Main entry ─────────────────────────────────────────────

    def run(self) -> PipelineOutcome:
        """Run the full pipeline. Emits exactly one terminal 'done' event."""
        outcome = self._run_guarded()
        self.on_event("done", outcome.status)
        return outcome

    def _run_guarded(self) -> PipelineOutcome:
        try:
            return self._run()
        except Exception as exc:  # last-resort guard
            self.log(f"\n❌ 未预期的错误: {exc}")
            self.log(traceback.format_exc())
            return PipelineOutcome("error", self.result, str(exc))

    def _run(self) -> PipelineOutcome:
        # Step 1: collect (fatal on failure — nothing downstream without it)
        if not self._step_collect():
            return PipelineOutcome("error", error="collect failed")
        if self._stop.is_set():
            return PipelineOutcome("stopped")

        # Step 2: enrich (non-fatal on failure — tags only boost accuracy)
        try:
            self._step_enrich()
        except Exception as exc:
            self.log(f"⚠ 标签补充失败（将继续使用现有数据分类）: {exc}")
        if self._stop.is_set():
            return PipelineOutcome("stopped")

        # Step 3: classify (fatal on failure)
        if not self._step_classify():
            return PipelineOutcome("error", error="classify failed")
        if self._stop.is_set():
            return PipelineOutcome("stopped")

        # Step 4: apply
        if self.do_apply:
            if not self._step_apply():
                return PipelineOutcome("error", self.result, "apply failed")
            if self._stop.is_set():
                return PipelineOutcome("stopped", self.result)

        self.progress(100, "全部完成!", 3)
        self.log("━" * 50)
        self.log("🎉 全部完成!")
        return PipelineOutcome("success", self.result)

    # ── Steps ──────────────────────────────────────────────────

    def _step_collect(self) -> bool:
        self.log("━" * 50)
        self.log("步骤 1/4: 扫码登录并拉取收藏夹")
        self.progress(5, "启动浏览器...", 0)

        try:
            asyncio.run(collect(find_bundled_browser(),
                                progress_cb=self._step_progress("collect", 0)))
        except Exception as exc:
            self.log(f"❌ 拉取失败: {exc}")
            return False

        if self._stop.is_set():
            return True
        try:
            favs = load_favs()
        except PlanError as exc:
            self.log(f"❌ {exc}")
            return False

        count = favs.get("count", len(favs.get("videos", [])))
        self.log(f"✓ 已拉取 {count} 个视频")
        self.progress(25, "收藏夹拉取完成", 0, f"共 {count} 个视频")

        cfg = load_config()
        self.log(f"✓ MID: {cfg.get('USER_MID', '?')}")
        self.log(f"✓ 默认收藏夹 ID: {cfg.get('DEFAULT_FAV_ID', '?')}")
        return True

    def _step_enrich(self) -> None:
        """Non-fatal step: failures degrade accuracy but don't abort."""
        self.log("━" * 50)
        self.log("步骤 2/4: 补充视频标签和分区")
        self.progress(30, "分析视频元数据...", 1)

        try:
            session = Session.load()
        except Exception as exc:
            self.log(f"⚠ 登录会话加载失败，跳过标签补充: {exc}")
            return

        try:
            enrich_meta(
                session=session,
                progress_cb=self._step_progress("enrich", 1),
                stop_event=self._stop,
            )
        except Exception as exc:
            self.log(f"⚠ 标签补充失败（将继续使用现有数据分类）: {exc}")
            return

        self.progress(50, "标签补充完成", 1)
        self.log("✓ 标签/分区补充完成")

    def _step_classify(self) -> bool:
        cfg = load_config()
        mode = cfg.get("CLASSIFY_MODE", "local")
        mode_label = {"local": "本地规则", "ai": "DeepSeek AI", "hybrid": "本地+AI 混合"}[mode]
        self.log("━" * 50)
        self.log(f"步骤 3/4: 智能分类（模式: {mode_label}）")
        self.progress(55, "分析分类...", 2, "加载数据中...")

        try:
            favs = load_favs()
        except PlanError as exc:
            self.log(f"❌ {exc}")
            return False

        seed_map = load_seed_mappings()
        videos = favs.get("videos", [])
        total = len(videos)
        self.progress(60, "正在分类...", 2, f"共 {total} 个视频，匹配分类规则...")

        # Local pass always runs first: it is the baseline, and in
        # hybrid mode it decides which videos need the AI at all.
        try:
            result = autoclassify(favs, seed_map)
        except Exception as exc:
            self.log(f"❌ 分类失败: {exc}")
            return False

        if mode in ("ai", "hybrid"):
            result = self._ai_classify(result, videos, cfg, mode)

        self.result = result

        plan = build_plan(result, move=self.move)
        save_plan(plan)
        if result.unmatched_ups:
            AUTO_CLASSIFY_JSON.write_text(
                json.dumps(result.unmatched_ups, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

        folder_count = len(result.groups)
        self.progress(75, "分类完成", 2, f"{total} 个视频 → {folder_count} 个文件夹")
        self.log(f"✓ {total} 个视频 -> {folder_count} 个文件夹")
        for folder, vids in sorted(result.groups.items(), key=lambda x: -len(x[1])):
            self.log(f"    {folder}: {len(vids)}")
        if result.unmatched_ups and mode == "local":
            self.log(
                f"⚠ '其他'共 {result.layer_counts.get('fallback', 0)} 个视频"
                f" ({len(result.unmatched_ups)} 个未映射UP主)"
            )
        if result.duplicate_ups:
            dup_list = ", ".join(sorted(result.duplicate_ups.keys())[:5])
            suffix = f"... (共 {len(result.duplicate_ups)} 个)" if len(result.duplicate_ups) > 5 else ""
            self.log(f"⚠ 重复UP映射: {dup_list}{suffix}")
        return True

    def _ai_classify(self, result, videos: list[dict], cfg: dict, mode: str):
        """Run DeepSeek classification and merge into the local result.

        - mode "ai":     all videos go through AI; failures keep local
        - mode "hybrid": only videos the local engine filed under "其他"
                         are sent to AI (saves tokens)
        Never raises: any failure degrades to the local result.
        """
        from bilibili_fav_classifier.ai import (
            DeepSeekClient,
            ai_classify_videos,
            apply_ai_results,
            merge_ai_results,
        )

        api_key = cfg.get("DEEPSEEK_API_KEY", "")
        if not api_key:
            self.log("⚠ 未配置 DeepSeek API Key，已回退为本地分类（设置页可填写）")
            return result

        if mode == "hybrid":
            fallback_bvids = {
                v.get("bvid") for v in result.groups.get("其他", [])
            }
            targets = [v for v in videos if v.get("bvid") in fallback_bvids]
            self.log(f"ℹ 混合模式: 仅 {len(targets)} 个「其他」视频交由 AI 处理")
        else:
            targets = videos

        if not targets:
            self.log("✓ 无需 AI 处理")
            return result

        client = DeepSeekClient(
            api_key,
            model=cfg.get("DEEPSEEK_MODEL") or "deepseek-chat",
        )
        try:
            ai_map, errors = ai_classify_videos(
                targets, client,
                progress_cb=self._step_progress("classify", 2),
                stop_event=self._stop,
            )
        except Exception as exc:  # defensive: never let AI break the pipeline
            self.log(f"⚠ AI 整理异常，已回退本地分类: {exc}")
            return result

        for err in errors:
            self.log(f"⚠ {err}")
        if not ai_map:
            self.log("⚠ AI 未返回有效结果，使用本地分类结果")
            return result

        merge_ai_results(ai_map)
        merged = apply_ai_results(result, ai_map)
        ai_n = merged.layer_counts.get("ai", 0)
        local_n = merged.layer_counts.get("local", 0)
        self.log(f"✓ AI 整理完成: {ai_n} 个由 AI 分类, {local_n} 个保持本地结果")
        return merged

    def _step_apply(self) -> bool:
        self.log("━" * 50)
        self.log("步骤 4/4: 应用分类计划" + ("" if self.move else "（预览模式）"))
        self.progress(80, "执行分类...", 3)

        try:
            session = Session.load()
        except Exception as exc:
            self.log(f"❌ 登录会话加载失败: {exc}")
            return False
        cfg = load_config()

        try:
            apply(
                session.http(), session.csrf,
                user_mid=session.mid,
                default_fav_id=cfg.get("DEFAULT_FAV_ID", 0),
                only_folder=self.only_folder,
                progress_cb=self._step_progress("apply", 3),
                stop_event=self._stop,
            )
        except Exception as exc:
            self.log(f"❌ 执行失败: {exc}")
            return False
        return True


def run_in_thread(pipeline: Pipeline) -> threading.Thread:
    """Start a pipeline in a daemon thread; returns the thread."""
    t = threading.Thread(target=pipeline.run, daemon=True)
    t.start()
    return t


# ── Backward-compatible shim ─────────────────────────────────────


class PipelineRunner:
    """Adapter with the v1.x PipelineRunner interface (queue-based).

    New code should use Pipeline directly. This shim exists so the
    legacy launcher keeps working during the transition.
    """

    def __init__(self, log_q, progress_cb, move: bool = True,
                 do_apply: bool = True):
        import queue as _queue
        self.q: _queue.Queue = log_q
        self._user_progress = progress_cb

        def _on_event(kind, payload):
            if kind == "progress":
                pct, msg, step, detail = payload
                self._user_progress(pct, msg, step, detail)
            else:
                self.q.put((kind, payload))

        self._pipeline = Pipeline(
            _on_event, move=move, do_apply=do_apply,
        )

    def log(self, msg: str):
        self.q.put(("log", msg))

    def stop(self):
        self._pipeline.stop()

    def run(self):
        self._pipeline.run()
