"""Classification plan I/O: build, save, load plan.json.

Single source of truth for the plan file format:
    {
        "move": bool,                      # false = dry-run preview
        "groups": {folder: [{"id": int, "bvid": str}, ...]}
    }
"""
from __future__ import annotations

import json
from pathlib import Path

from bilibili_fav_classifier import config
from bilibili_fav_classifier.classify_core import ClassifyResult


class PlanError(Exception):
    """Raised when plan.json is missing, corrupted, or malformed."""


def build_plan(result: ClassifyResult, move: bool = True) -> dict:
    """Build a plan dict from a ClassifyResult."""
    return {
        "move": move,
        "groups": {
            folder: [{"id": v.get("id"), "bvid": v.get("bvid")} for v in vids]
            for folder, vids in result.groups.items()
        },
    }


def save_plan(plan: dict, path: Path | None = None) -> Path:
    """Write plan to disk, return the path written."""
    plan_file = Path(path) if path is not None else config.PLAN_JSON
    plan_file.write_text(
        json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return plan_file


def load_plan(path: Path | None = None) -> dict:
    """Load and validate plan.json. Raises PlanError on any problem."""
    plan_file = Path(path) if path is not None else config.PLAN_JSON
    if not plan_file.exists():
        raise PlanError(f"未找到 {plan_file}，请先运行分类生成计划")
    try:
        plan = json.loads(plan_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        raise PlanError(f"计划文件损坏: {exc}") from None
    if not isinstance(plan, dict) or not isinstance(plan.get("groups"), dict):
        raise PlanError(f"计划文件格式不正确: {plan_file}")
    # Safe default: missing "move" means preview (never silently move).
    plan.setdefault("move", False)
    return plan


def load_favs(path: Path | None = None) -> dict:
    """Load favs.json with uniform error handling. Raises PlanError."""
    favs_file = Path(path) if path is not None else config.FAVS_JSON
    if not favs_file.exists():
        raise PlanError(f"未找到 {favs_file}，请先运行 collect 拉取收藏夹")
    try:
        data = json.loads(favs_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        raise PlanError(f"收藏夹数据文件损坏: {exc}") from None
    if not isinstance(data, dict) or not isinstance(data.get("videos"), list):
        raise PlanError(f"收藏夹数据格式不正确: {favs_file}")
    return data
