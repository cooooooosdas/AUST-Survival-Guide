"""LAN web server for mobile access (zero-dependency, stdlib only).

Run from the desktop app (or standalone) so a phone on the same network
can watch progress, trigger runs, and manage settings through a
mobile-first web UI. Both ends share PipelineController + config, so
behavior and data structures are identical to the desktop app.

API:
    GET  /                     mobile web UI
    GET  /api/status           pipeline status snapshot
    GET  /api/logs?since=N     incremental logs
    GET  /api/results          latest classification results
    GET  /api/config           current settings (API key masked)
    POST /api/config           save settings {key: value}
    POST /api/verify_key       {"key": "..."} -> {ok, message}
    POST /api/start            {"move": true, "do_apply": true}
    POST /api/stop
    GET  /api/seed_mappings    UP -> folder mappings
    POST /api/seed_mappings    save mappings
"""
from __future__ import annotations

import json
import socket
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from bilibili_fav_classifier import paths
from bilibili_fav_classifier.config import (
    CLASSIFY_MODES,
    load_config,
    load_seed_mappings,
    save_config,
    save_seed_mappings,
)
from bilibili_fav_classifier.controller import PipelineController, results_summary

WEB_DIR = Path(__file__).parent / "web"

# Config keys that may be written through the API
_WRITABLE_KEYS = {
    "CLASSIFY_MODE", "DEEPSEEK_API_KEY", "DEEPSEEK_MODEL",
    "SERVER_ENABLED", "SERVER_PORT",
}


def lan_ip() -> str:
    """Best-effort LAN IP discovery."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"


def _masked_config() -> dict:
    cfg = load_config()
    key = cfg.get("DEEPSEEK_API_KEY", "")
    cfg["DEEPSEEK_API_KEY_MASKED"] = (
        f"{key[:6]}...{key[-4:]}" if len(key) > 10 else ("已保存" if key else "")
    )
    cfg.pop("DEEPSEEK_API_KEY", None)
    cfg["has_api_key"] = bool(key)
    return cfg


class _Handler(BaseHTTPRequestHandler):
    controller: PipelineController = None  # injected by serve()

    # ── plumbing ───────────────────────────────────────────────

    def log_message(self, fmt, *args):  # silence default stderr logging
        pass

    def _send_json(self, obj, status: int = 200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, html: bytes):
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(html)))
        self.end_headers()
        self.wfile.write(html)

    def _read_body(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length", 0))
        except ValueError:
            return {}
        if length <= 0 or length > 1_000_000:
            return {}
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            return {}

    # ── GET ────────────────────────────────────────────────────

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path == "/":
            index = WEB_DIR / "index.html"
            if index.exists():
                self._send_html(index.read_bytes())
            else:
                self._send_json({"error": "web ui missing"}, 404)
        elif path == "/api/status":
            self._send_json(self.controller.status())
        elif path == "/api/logs":
            since = 0
            if "?" in self.path:
                for part in self.path.split("?", 1)[1].split("&"):
                    if part.startswith("since="):
                        try:
                            since = int(part[6:])
                        except ValueError:
                            pass
            self._send_json(self.controller.logs_since(since))
        elif path == "/api/results":
            self._send_json(results_summary())
        elif path == "/api/config":
            self._send_json(_masked_config())
        elif path == "/api/seed_mappings":
            self._send_json(load_seed_mappings())
        else:
            self._send_json({"error": "not found"}, 404)

    # ── POST ───────────────────────────────────────────────────

    def do_POST(self):
        path = self.path.split("?", 1)[0]
        body = self._read_body()

        if path == "/api/start":
            ok, msg = self.controller.start(
                move=bool(body.get("move", True)),
                do_apply=bool(body.get("do_apply", True)),
            )
            self._send_json({"ok": ok, "message": msg},
                            200 if ok else 409)

        elif path == "/api/stop":
            ok, msg = self.controller.stop()
            self._send_json({"ok": ok, "message": msg})

        elif path == "/api/config":
            updates = {k: v for k, v in body.items() if k in _WRITABLE_KEYS}
            if "CLASSIFY_MODE" in updates and \
                    updates["CLASSIFY_MODE"] not in CLASSIFY_MODES:
                self._send_json({"ok": False, "message": "无效的分类模式"}, 400)
                return
            if "SERVER_PORT" in updates:
                try:
                    port = int(updates["SERVER_PORT"])
                    if not (1024 <= port <= 65535):
                        raise ValueError
                    updates["SERVER_PORT"] = port
                except (TypeError, ValueError):
                    self._send_json({"ok": False, "message": "端口号无效"}, 400)
                    return
            save_config(updates)
            self._send_json({"ok": True, "message": "设置已保存",
                             "config": _masked_config()})

        elif path == "/api/verify_key":
            from bilibili_fav_classifier.ai import DeepSeekClient

            key = body.get("key", "") or load_config().get("DEEPSEEK_API_KEY", "")
            ok, msg = DeepSeekClient(key).verify_key()
            self._send_json({"ok": ok, "message": msg})

        elif path == "/api/seed_mappings":
            if not isinstance(body, dict):
                self._send_json({"ok": False, "message": "格式错误"}, 400)
                return
            cleaned = {
                str(k): [str(u) for u in v]
                for k, v in body.items() if isinstance(v, list)
            }
            save_seed_mappings(cleaned)
            self._send_json({"ok": True, "message": "映射已保存"})

        else:
            self._send_json({"error": "not found"}, 404)


class LanServer:
    """Threaded LAN server bound to a shared PipelineController."""

    def __init__(self, controller: PipelineController, port: int = 8765,
                 host: str = "0.0.0.0"):
        self.controller = controller
        self.port = port
        self.host = host
        self._httpd: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None

    @property
    def url(self) -> str:
        return f"http://{lan_ip()}:{self.port}"

    def start(self) -> tuple[bool, str]:
        if self._httpd is not None:
            return False, "服务器已在运行"
        handler = type("BoundHandler", (_Handler,),
                       {"controller": self.controller})
        try:
            self._httpd = ThreadingHTTPServer((self.host, self.port), handler)
        except OSError as exc:
            self._httpd = None
            return False, f"端口 {self.port} 不可用: {exc}"
        # Resolve the real port (useful when constructed with port=0)
        self.port = self._httpd.server_address[1]
        self._thread = threading.Thread(
            target=self._httpd.serve_forever, daemon=True,
        )
        self._thread.start()
        return True, self.url

    def stop(self) -> None:
        if self._httpd is not None:
            self._httpd.shutdown()
            self._httpd.server_close()
            self._httpd = None
