"""Centralized filesystem paths for bilibili-fav-classifier.

Single source of truth for where data lives:
- Frozen (PyInstaller exe): alongside the executable.
- Development: the project root (parent of this package), so runtime
  data never pollutes the source package directory.
"""
from __future__ import annotations

import sys
from pathlib import Path

APP_NAME = "bilibili-fav-classifier"


def is_frozen() -> bool:
    """True when running as a PyInstaller-frozen executable."""
    return getattr(sys, "frozen", False)


def package_dir() -> Path:
    """Directory containing this package (source code location)."""
    return Path(__file__).resolve().parent


def project_root() -> Path:
    """Project root directory (parent of the package)."""
    return package_dir().parent


def base_dir() -> Path:
    """Directory that anchors user data: exe dir when frozen, project root in dev."""
    if is_frozen():
        return Path(sys.executable).parent
    return project_root()


# ── Data files (all under base_dir) ──────────────────────────────

DATA_DIR = base_dir()

CONFIG_JSON = DATA_DIR / "config.json"
COOKIES_JSON = DATA_DIR / "cookies.json"
FAVS_JSON = DATA_DIR / "favs.json"
PLAN_JSON = DATA_DIR / "plan.json"
APPLY_LOG_JSON = DATA_DIR / "apply_log.json"
ENRICH_CACHE_JSON = DATA_DIR / "enrich_cache.json"
AUTO_CLASSIFY_JSON = DATA_DIR / "auto_classified.json"
SEED_MAPPINGS_JSON = DATA_DIR / "seed_mappings.json"
UP_SUMMARY_JSON = DATA_DIR / "up_summary.json"
AI_RESULTS_JSON = DATA_DIR / "ai_results.json"

# ── Package resources (templates shipped with the code) ──────────

CONFIG_TEMPLATE = package_dir() / "config_template.json"
SEED_MAPPINGS_TEMPLATE = package_dir() / "seed_mappings_template.json"


def bundled_browsers_dir() -> Path:
    """Playwright browsers bundled next to the exe (frozen builds)."""
    return base_dir() / "ms-playwright"


def migrate_legacy_data() -> list[str]:
    """Move data files from the legacy location (inside the package dir)
    to DATA_DIR. Returns list of moved file names.

    Legacy dev-mode ROOT was the package directory itself, so older runs
    left config/favs/etc. inside bilibili_fav_classifier/.
    """
    legacy_dir = package_dir()
    if legacy_dir == DATA_DIR:
        return []
    moved: list[str] = []
    legacy_names = (
        "config.json", "cookies.json", "favs.json", "plan.json",
        "apply_log.json", "enrich_cache.json", "auto_classified.json",
        "seed_mappings.json", "up_summary.json", "ai_results.json",
    )
    for name in legacy_names:
        src = legacy_dir / name
        dst = DATA_DIR / name
        if src.exists() and not dst.exists():
            try:
                src.replace(dst)
                moved.append(name)
            except OSError:
                pass
    return moved
