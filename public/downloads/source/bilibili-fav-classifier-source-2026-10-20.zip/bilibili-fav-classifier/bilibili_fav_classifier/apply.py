"""Apply classification plan: create folders and move videos.

Uses injectable HTTP client (from session module) for testability.

Safety model:
- plan["move"] is False (or missing)  ->  dry-run preview: no create/move
  API calls at all, only reports what would happen.
- plan["move"] is True                ->  real execution.
- Videos without a numeric resource id are skipped and counted (the
  move API requires numeric ids; BVIDs would be rejected anyway).
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from bilibili_fav_classifier.config import (
    API_BASE,
    APPLY_LOG_JSON,
    BATCH_SIZE,
)
from bilibili_fav_classifier.plan import PlanError, load_plan
from bilibili_fav_classifier.session import HttpClient

# Rate-limit pacing (seconds)
SLEEP_AFTER_CREATE = 2.0
SLEEP_BETWEEN_BATCHES = 1.5
SLEEP_BETWEEN_FOLDERS = 2.0
WAF_COOLDOWN = 60


def _load_folders(http: HttpClient, user_mid: str, default_fav_id: int) -> tuple[dict[str, int], int]:
    """Return (name_to_id, default_id) from Bilibili API."""
    data = http.get(
        f"{API_BASE}/x/v3/fav/folder/created/list-all"
        f"?up_mid={user_mid}&platform=web"
    )
    folders = data.get("data", {}).get("list", []) or []
    name_to_id = {f.get("title"): f.get("id") for f in folders if f.get("id")}
    default = next(
        (f for f in folders if "默认" in (f.get("title") or "")), None
    )
    default_id = default.get("id") if default else default_fav_id
    return name_to_id, default_id


def _batch_move(
    http: HttpClient, csrf: str, user_mid: str,
    src_media_id: int | str, tar_media_id: int | str,
    resources: list[str],
) -> dict:
    """Batch move videos via /x/v3/fav/resource/move API."""
    data = {
        "resources": ",".join(f"{r}:2" for r in resources),
        "src_media_id": str(src_media_id),
        "tar_media_id": str(tar_media_id),
        "mid": user_mid,
        "platform": "web",
        "csrf": csrf,
    }
    return http.post(f"{API_BASE}/x/v3/fav/resource/move", data)


def _valid_ids(batch: list[dict]) -> tuple[list[str], int]:
    """Extract numeric resource ids; returns (ids, skipped_count).

    The move API requires numeric resource ids (`{id}:2`). Entries whose
    id is missing or non-numeric are skipped instead of poisoning the
    whole batch with an invalid `BVxxxx:2` resource string.
    """
    ids: list[str] = []
    skipped = 0
    for v in batch:
        vid = v.get("id")
        if isinstance(vid, int) or (isinstance(vid, str) and vid.isdigit()):
            ids.append(str(vid))
        else:
            skipped += 1
    return ids, skipped


def apply(
    http: HttpClient, csrf: str,
    user_mid: str = "", default_fav_id: int = 0,
    only_folder: str | None = None,
    plan_path=None,
    log_path=None,
    progress_cb=None,
    stop_event=None,
) -> list[dict]:
    """Execute the classification plan: create folders and move videos.

    Args:
        http: Injected HTTP client (swap for tests).
        csrf: CSRF token from cookies.
        user_mid: User's Bilibili MID.
        default_fav_id: Default favorite folder ID.
        only_folder: If set, only process this folder.
        plan_path: Override plan.json path (for testing).
        log_path: Override apply_log.json path (for testing).
        progress_cb: Optional callback(pct, msg, detail) for progress updates.
        stop_event: Optional threading.Event; checked between batches.

    Returns:
        The apply log (list of per-folder result dicts).
    """
    try:
        plan = load_plan(plan_path)
    except PlanError as exc:
        print(f"错误: {exc}")
        return []

    do_move = bool(plan.get("move", False))  # safe default: preview
    groups = plan["groups"]
    total = sum(len(v) for k, v in groups.items() if k != "其他")
    mode_label = "执行" if do_move else "预览(不移动)"
    print(f"==> 计划: {len(groups)} 个文件夹, 共 {total} 个视频, 模式={mode_label}")

    log: list[dict] = []
    name_to_id: dict[str, int] = {}
    default_id = default_fav_id
    CREATE_URL = f"{API_BASE}/x/v3/fav/folder/add"

    if do_move:
        name_to_id, default_id = _load_folders(http, user_mid, default_fav_id)

    stopped = False
    for folder_name, bvids in groups.items():
        if stop_event is not None and stop_event.is_set():
            stopped = True
            break
        if only_folder and folder_name != only_folder:
            continue
        if folder_name == "其他":
            print(f"\n==> 跳过 '其他' (共 {len(bvids)} 个)")
            log.append({"folder": folder_name, "skipped": True, "count": len(bvids)})
            continue

        total_vids = len(bvids)
        ok = fail = skipped = 0

        if not do_move:
            # ── Dry-run preview: report only, no API calls ──
            exists = folder_name in name_to_id
            print(f"\n==> [预览] {folder_name}: {total_vids} 个视频"
                  f" ({'已有收藏夹' if exists else '将新建收藏夹'})")
            if progress_cb:
                progress_cb(50, "预览分类计划...", f"{folder_name} ({total_vids} 个)")
            log.append({
                "folder": folder_name, "preview": True,
                "total": total_vids, "would_create": not exists,
            })
            continue

        # ── Real execution ──
        if folder_name in name_to_id:
            fid = name_to_id[folder_name]
            print(f"\n==> 收藏夹已存在: {folder_name} (id={fid})")
        else:
            print(f"\n==> 创建收藏夹: {folder_name}")
            if progress_cb:
                progress_cb(5, "创建收藏夹...", folder_name)
            r = http.post(CREATE_URL, {
                "title": folder_name, "intro": "", "privacy": 0, "cover": "", "csrf": csrf,
            })
            if r.get("code") != 0:
                print(f"    创建失败: {r}")
                log.append({"folder": folder_name, "error": "create failed", "resp": r})
                continue
            fid = r.get("data", {}).get("id")
            if not fid:
                print("    创建响应异常: 缺少文件夹ID")
                log.append({"folder": folder_name, "error": "create response missing id", "resp": r})
                continue
            name_to_id[folder_name] = fid
            print(f"    创建成功 id={fid}")
            if progress_cb:
                progress_cb(10, "收藏夹已创建", folder_name)
            time.sleep(SLEEP_AFTER_CREATE)

        if progress_cb:
            progress_cb(15, "移动视频...", f"{folder_name} ({total_vids} 个)")
        for batch_start in range(0, total_vids, BATCH_SIZE):
            if stop_event is not None and stop_event.is_set():
                stopped = True
                break
            batch = bvids[batch_start:batch_start + BATCH_SIZE]
            rids, bad = _valid_ids(batch)
            skipped += bad
            if bad:
                print(f"    [{folder_name}] 跳过 {bad} 个无有效ID的视频")
            if not rids:
                continue
            if progress_cb:
                batch_pct = 15 + int(batch_start / total_vids * 70) if total_vids else 15
                progress_cb(batch_pct, "移动视频...", f"{folder_name}: {batch_start}/{total_vids}")
            result = _batch_move(http, csrf, user_mid, default_id, fid, rids)

            if result.get("_waf_html"):
                print(
                    f"    [{folder_name}] 批次 {batch_start // BATCH_SIZE + 1}"
                    f" WAF限流, 冷却{WAF_COOLDOWN}秒...",
                    flush=True,
                )
                time.sleep(WAF_COOLDOWN)
                result = _batch_move(http, csrf, user_mid, default_id, fid, rids)
                if result.get("_waf_html"):
                    print(
                        f"    [{folder_name}] 批次 {batch_start // BATCH_SIZE + 1}"
                        f" 冷却后仍限流, 跳过",
                        flush=True,
                    )
                    fail += len(rids)
                    continue

            if result.get("_error"):
                print(
                    f"    [{folder_name}] 批次 {batch_start // BATCH_SIZE + 1}"
                    f": 网络错误 {str(result.get('_msg', ''))[:60]}",
                    flush=True,
                )
                fail += len(rids)
                log.append({"folder": folder_name, "batch": batch_start, "error": result})
                time.sleep(SLEEP_BETWEEN_BATCHES)
                continue

            code = result.get("code", -1)
            if code == 0:
                ok += len(rids)
                print(
                    f"    [{folder_name}] 批次 {batch_start // BATCH_SIZE + 1}"
                    f": {len(rids)}/{len(rids)} (累计 {ok}/{total_vids})",
                    flush=True,
                )
            else:
                print(
                    f"    [{folder_name}] 批次 {batch_start // BATCH_SIZE + 1}"
                    f": 失败 code={code} {str(result.get('message', ''))[:60]}",
                    flush=True,
                )
                fail += len(rids)
                log.append({"folder": folder_name, "batch": batch_start, "error": result})

            time.sleep(SLEEP_BETWEEN_BATCHES)

        print(f"==> {folder_name}: 移动 {ok}/{total_vids} 成功 (失败{fail}"
              + (f", 跳过{skipped})" if skipped else ")"))
        if progress_cb:
            progress_cb(85, "移动视频...", f"{folder_name}: {ok}/{total_vids}")
        log.append({
            "folder": folder_name, "id": fid,
            "moved": ok, "total": total_vids, "failed": fail, "skipped": skipped,
        })
        time.sleep(SLEEP_BETWEEN_FOLDERS)

    log_file = Path(log_path) if log_path is not None else APPLY_LOG_JSON
    log_file.write_text(
        json.dumps(log, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    total_ok = sum(e.get("moved", 0) for e in log if isinstance(e, dict))
    total_fail = sum(e.get("failed", 0) for e in log if isinstance(e, dict))
    if stopped:
        print(f"\n==> 已停止! 部分日志: {log_file}")
    else:
        print(f"\n==> 完成! 日志: {log_file}")
    if do_move:
        print(f"==> 总计移动: {total_ok}/{total} 个视频 (失败 {total_fail})")
    return log
