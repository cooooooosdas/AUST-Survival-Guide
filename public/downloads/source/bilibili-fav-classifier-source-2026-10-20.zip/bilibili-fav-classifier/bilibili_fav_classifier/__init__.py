"""B站收藏夹智能分类工具.

Pipeline: collect → enrich_meta → autoclassify → apply

CLI usage:
    python -m bilibili_fav_classifier collect
    python -m bilibili_fav_classifier enrich_meta
    python -m bilibili_fav_classifier autoclassify
    python -m bilibili_fav_classifier apply [folder_name]
    python -m bilibili_fav_classifier run          # full pipeline
"""
from __future__ import annotations

import asyncio
import json
import sys

from bilibili_fav_classifier.classify_core import ClassifyResult, autoclassify
from bilibili_fav_classifier.collect import collect as _collect
from bilibili_fav_classifier.config import (
    AUTO_CLASSIFY_JSON,
    PLAN_JSON,
    load_config,
    load_seed_mappings,
)
from bilibili_fav_classifier.enrich import enrich_meta
from bilibili_fav_classifier.plan import PlanError, build_plan, load_favs, save_plan
from bilibili_fav_classifier.session import Session


def _print_classify_result(result: ClassifyResult) -> None:
    """Print classification statistics from ClassifyResult."""
    print(f"\n==> 已生成 {PLAN_JSON}: {len(result.groups)} 个文件夹, 共 {result.total} 个视频")
    print("\n==> 分类命中统计:")
    print(f"    UP主映射:    {result.layer_counts.get('up', 0)}")
    print(f"    标签匹配:    {result.layer_counts.get('tag', 0)}")
    print(f"    分区匹配:    {result.layer_counts.get('partition', 0)}")
    print(f"    关键词匹配:  {result.layer_counts.get('keyword', 0)}")
    print(f"    归入'其他':  {result.layer_counts.get('fallback', 0)} 个视频")
    if result.unmatched_ups:
        print(f"    (含 {len(result.unmatched_ups)} 个未映射UP主)")
    print()
    for f, vids in sorted(result.groups.items(), key=lambda x: -len(x[1])):
        print(f"    - {f}: {len(vids)}")
    if result.unmatched_ups:
        sample = list(result.unmatched_ups.keys())[:10]
        suffix = "..." if len(result.unmatched_ups) > 10 else ""
        print(f"\n==> 归入'其他'的UP主: {sample}{suffix}")
        print("    (在 seed_mappings.json 中添加映射可减少'其他')")
    print("\n==> 请检查 plan.json, 确认后运行 apply")


def _cmd_autoclassify() -> None:
    try:
        favs = load_favs()
    except PlanError as exc:
        print(f"==> {exc}")
        return
    seed_map = load_seed_mappings()
    result = autoclassify(favs, seed_map)

    if result.unmatched_ups:
        AUTO_CLASSIFY_JSON.write_text(
            json.dumps(result.unmatched_ups, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        print(f"==> 未匹配UP ({len(result.unmatched_ups)} 个) 已保存到 auto_classified.json")

    save_plan(build_plan(result, move=True))
    _print_classify_result(result)


def _cmd_apply(folder: str | None) -> None:
    from bilibili_fav_classifier.apply import apply as _apply

    session = Session.load()
    cfg = load_config()
    _apply(
        session.http(), session.csrf,
        user_mid=session.mid, default_fav_id=cfg.get("DEFAULT_FAV_ID", 0),
        only_folder=folder,
    )


def _cmd_run() -> None:
    """Full pipeline with console output."""
    from bilibili_fav_classifier.pipeline import Pipeline

    def _on_event(kind, payload):
        if kind == "log":
            print(payload)
        elif kind == "progress":
            pct, msg, _step, detail = payload
            print(f"    [{pct:3d}%] {msg} {detail}")
        elif kind == "done":
            print(f"==> 流水线结束: {payload}")

    Pipeline(_on_event).run()


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return

    cmd = sys.argv[1]
    if cmd == "collect":
        asyncio.run(_collect())
    elif cmd == "enrich_meta":
        enrich_meta()
    elif cmd == "autoclassify":
        _cmd_autoclassify()
    elif cmd == "apply":
        _cmd_apply(sys.argv[2] if len(sys.argv) > 2 else None)
    elif cmd == "run":
        _cmd_run()
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
